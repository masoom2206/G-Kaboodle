<?php

namespace Drupal\aetl;

/**
 * Class used to differentiate between known and unknown exception states.
 */
class AetlException extends \Exception {}
