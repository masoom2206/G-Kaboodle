<?php
/** 
* Controller file for Aetl Drupal 8 module. 
* Place this file in src/Controller folder inside the Aetl module folder
**/
namespace Drupal\aetl\Controller;
use Drupal\Core\Controller\ControllerBase;
use Aws\Exception\AwsException;
use Drupal\Core\Link;
use Drupal\Core\Url;
use Drupal\Component\Render\FormattableMarkup;
use Drupal\Component\Serialization\Json;

class PagesController extends ControllerBase {
  public function pipelineslist() {
    $config = \Drupal::config('aetl.settings')->get();
    $messenger = \Drupal::messenger();
    if ($errors = \Drupal::service('aetl')->validate($config)) {
      foreach ($errors as $error) {
        $messenger->addMessage((string)$error, $messenger::TYPE_ERROR);
      }
      $messenger->addMessage('Unable to validate your aetl configuration settings. Please configure aetl File System from the admin/config/media/aetl page and try again.', $messenger::TYPE_ERROR);
      return;
    } 
    $transcoder_client = \Drupal::service('aetl')->getAmazonETClient($config);
    $rows = [];
    try {
      $result = $transcoder_client->listPipelines([])->toArray();
      foreach ($result['Pipelines'] as $pipeline) {
        $url_link_edit = Url::fromRoute('aetl.pipelinesedit', ['pid' => $pipeline['Id']]);
        $url_edit = $url_link_edit->toString();
        $url_edit = new FormattableMarkup('<a href=":link">@name</a>', [':link' =>  $url_edit, '@name' => 'Edit']);
        $url_link_delete = Url::fromRoute('aetl.pipelinesedelete', ['pid' => $pipeline['Id']]);
        $url_delete = $url_link_delete->toString();
        $url_delete = new FormattableMarkup('<a href=":link">@name</a>', [':link' =>  $url_delete, '@name' => 'Delete']);
        $mainLink = t('@edit | @delete', array('@edit' => $url_edit, '@delete' => $url_delete));
        $output['data'] = [
          'id' => $pipeline['Id'],
          'name' => $pipeline['Name'],
          'status' => $pipeline['Status'],
          'inputbucket' => $pipeline['InputBucket'],
          'outputbucket' => $pipeline['OutputBucket'],
          'action' =>  $mainLink
        ];
        $rows[] = $output;
      }
    }
    catch (AwsException $e) {
      // output error message if fails
      echo $e->getMessage() . "\n";
    }
    $header = [
      'id' => t('Id'),
      'name' => t('Name'),
      'status' => t('Status'),
      'inputbucket' => t('Input Bucket'),
      'outputbucket' => t('Output Bucket'),
      'action' => t('Action'),
    ];
    $url_link_add = Url::fromRoute('aetl.pipelinesadd', ['pid' => $pipeline['Id']])->toString();
    $build = [
      'table' => [
        '#prefix' => '<h1>Pipeline List</h1><br/><a href="'.$url_link_add.'" class="button button--primary" role="button">Add New Pipeline</a><br/>',
        '#theme' => 'table',
        '#header' => $header,
        '#rows' => $rows,
      ],
    ];
    return $build;
  }

  public function jobslist($pipeline) {
    print $pipeline;
    $config = \Drupal::config('aetl.settings')->get();
    $messenger = \Drupal::messenger();
    if ($errors = \Drupal::service('aetl')->validate($config)) {
      foreach ($errors as $error) {
        $messenger->addMessage((string)$error, $messenger::TYPE_ERROR);
      }
      $messenger->addMessage('Unable to validate your aetl configuration settings. Please configure aetl File System from the admin/config/media/aetl page and try again.', $messenger::TYPE_ERROR);
      return;
    } 
    $transcoder_client = \Drupal::service('aetl')->getAmazonETClient($config);
    $rows = [];
    try {
      $result = $transcoder_client->listPipelines([])->toArray();
      foreach ($result['Pipelines'] as $pipeline) {
        try {
          $pipelinejobs = $transcoder_client -> listJobsByPipeline([
              'PipelineId' =>$pipeline['Id'], 
          ])->toArray();
          foreach ($pipelinejobs['Jobs'] as $job) {
            $output['data'] = [
              'id' => $job['Id'],
              'pipelineid' => $job['PipelineId'],
              'status' => $job['Status'],
              'inputs' => $job['Inputs'],
              'outputs' => $job['Outputs'],
              'outputkeyprefix' => $job['OutputKeyPrefix'],
            ];
            $rows[] = $output;
          }
        } catch (AwsException $e) {
            // output error message if fails
            echo $e->getMessage() . "\n";
        }
        
      }
    }
    catch (AwsException $e) {
      // output error message if fails
      echo $e->getMessage() . "\n";
    }
    $header = [
      'id' => t('Job Id'),
      'pipelineid' => t('PipelineId'),
      'status' => t('Status'),
      'inputs' => t('Inputs'),
      'outputs' => t('Outputs'),
      'outputkeyprefix' => t('OutputKeyPrefix'),
    ];
    $build = [
      'table' => [
        '#prefix' => '<h1>Jobs List</h1>',
        '#theme' => 'table',
        '#attributes' => [
          'data-striping' => 0
        ],
        '#header' => $header,
        '#rows' => $rows,
      ],
    ];
    return $build;
  }

  public function presetslist() {
    $config = \Drupal::config('aetl.settings')->get();
    $messenger = \Drupal::messenger();
    if ($errors = \Drupal::service('aetl')->validate($config)) {
      foreach ($errors as $error) {
        $messenger->addMessage((string)$error, $messenger::TYPE_ERROR);
      }
      $messenger->addMessage('Unable to validate your aetl configuration settings. Please configure aetl File System from the admin/config/media/aetl page and try again.', $messenger::TYPE_ERROR);
      return;
    } 
    $transcoder_client = \Drupal::service('aetl')->getAmazonETClient($config);
    $rows = [];
    try {
      $result = $transcoder_client->listPresets([])->toArray();
      foreach ($result['Presets'] as $presets) {
        $output['data'] = [
          'id' => $presets['Id'],
          'name' => $presets['Name'],
          'container' => $presets['Container'],
          'description' => $presets['Description'],
        ];
        $rows[] = $output;
      }
    }
    catch (AwsException $e) {
      // output error message if fails
      echo $e->getMessage() . "\n";
    }
    $header = [
      'id' => t('Preset Id'),
      'name' => t('Name'),
      'container' => t('Container'),
      'description' => t('Description'),
    ];
    $build = [
      'table' => [
        '#prefix' => '<h1>Preset List</h1>',
        '#theme' => 'table',
        '#attributes' => [
          'data-striping' => 0
        ],
        '#header' => $header,
        '#rows' => $rows,
      ],
    ];
    return $build;
  }

  function jobdetailsbyid($job_id) {
    $config = \Drupal::config('aetl.settings')->get();
    $messenger = \Drupal::messenger();
    if ($errors = \Drupal::service('aetl')->validate($config)) {
      foreach ($errors as $error) {
        $messenger->addMessage((string)$error, $messenger::TYPE_ERROR);
      }
      $messenger->addMessage('Unable to validate your aetl configuration settings. Please configure aetl File System from the admin/config/media/aetl page and try again.', $messenger::TYPE_ERROR);
      return;
    } 
    $transcoder_client = \Drupal::service('aetl')->getAmazonETClient($config);
    try {
      $jobbyid = $transcoder_client->readJob(array(
          // Id is required
          'Id' => $job_id,
      ))->toArray();
      $dataoutput = '';
      if ($jobbyid) { 
        foreach ($jobbyid['Job']['Outputs'] as $key => $value) {
          $dataoutput .= '<li><b>Outputs ' . $key . ': </b>' . $value['Key'] .' (Status : ' . $value['Status']  . ')</li>';
        }
        $jobsdetails = '<ul>
                      <li><b>Id: </b>' . $jobbyid['Job']['Id'] . '</li>
                      <li><b>Input: </b>' . $jobbyid['Job']['Input']['Key'] . '</li>
                       ' . $dataoutput . '
                      </ul>';
      }
    } 
    catch (AwsException $e) {
      // output error message if fails
      echo $e->getMessage() . "\n";
    }
    return array(
      '#type' => 'markup',
      '#markup' => $this->t($jobsdetails),);
  }

  function jobsiddetails($pipeline_id) {
    $config = \Drupal::config('aetl.settings')->get();
    $messenger = \Drupal::messenger();
    if ($errors = \Drupal::service('aetl')->validate($config)) {
      foreach ($errors as $error) {
        $messenger->addMessage((string)$error, $messenger::TYPE_ERROR);
      }
      $messenger->addMessage('Unable to validate your aetl configuration settings. Please configure aetl File System from the admin/config/media/aetl page and try again.', $messenger::TYPE_ERROR);
      return;
    } 
    $transcoder_client = \Drupal::service('aetl')->getAmazonETClient($config);
    $rows = [];
    if ($pipeline_id == 'all' || $pipeline_id == '') {
      try {
        $result = $transcoder_client->listPipelines([])->toArray();
        foreach ($result['Pipelines'] as $pipeline) {
          try {
            $pipelinejobs = $transcoder_client -> listJobsByPipeline([
              'PipelineId' =>$pipeline['Id'], 
            ])->toArray();
            foreach ($pipelinejobs['Jobs'] as $job) {
              $url_link_view = Url::fromRoute('aetl.jobbyid', ['job_id' => $job['Id']]);
              $url_view = $url_link_view->toString();
              $url_view = new FormattableMarkup('<a href=":link">@name</a>', [':link' =>  $url_view, '@name' => 'View']);
              $menu = t('@view', array('@view' => $url_view));
              $output['data'] = [
                'id' => $job['Id'],
                'pipelineid' => $job['PipelineId'],
                'status' => $job['Status'],
                'outputkeyprefix' => $job['OutputKeyPrefix'],
                'oprations' => $menu
              ];
              $rows[] = $output;
            }
          } 
          catch (AwsException $e) {
            // output error message if fails
            echo $e->getMessage() . "\n";
          }
          
        }
      } 
      catch (AwsException $e) {
        // output error message if fails
        echo $e->getMessage() . "\n";
      }
    }
    else {
      try {
        $pipelinejobs = $transcoder_client -> listJobsByPipeline([
          'PipelineId' => $pipeline_id, 
        ])->toArray();
        foreach ($pipelinejobs['Jobs'] as $job) {
          $url_link_view = Url::fromRoute('aetl.jobbyid', ['job_id' => $job['Id']]);
          $url_view = $url_link_view->toString();
          $url_view = new FormattableMarkup('<a href=":link">@name</a>', [':link' =>  $url_view, '@name' => 'View']);
          $menu = t('@view', array('@view' => $url_view));
          $output['data'] = [
            'id' => $job['Id'],
            'pipelineid' => $job['PipelineId'],
            'status' => $job['Status'],
            'outputkeyprefix' => $job['OutputKeyPrefix'],
            'oprations' => $menu
          ];
          $rows[] = $output;
        }
      }
      catch (AwsException $e) {
        // output error message if fails
        echo $e->getMessage() . "\n";
      }
    }
    $url_link_add = Url::fromRoute('aetl.jobadd')->toString();
    $header = [
      'id' => t('Job Id'),
      'pipelineid' => t('PipelineId'),
      'status' => t('Status'),
      'outputkeyprefix' => t('OutputKeyPrefix'),
      'oprations' => ('Operations')
    ];
    $build = [
      'table' => [
        '#prefix' => '<h1>Jobs List</h1><br/><a href="'.$url_link_add.'" class="button button--primary" role="button">Create a New Transcoding Job</a><br/>',
        '#theme' => 'table',
        '#attributes' => [
          'data-striping' => 0
        ],
        '#header' => $header,
        '#rows' => $rows,
      ],
    ];
    return $build;
  }
}