/**
 * @file
 * Attaches behaviors for the onboarding module.
 *
 */
(function ($, Drupal) {
  var initialized;
  Drupal.behaviors.dashboardBehavior = {
    attach: function (context, settings) {
      if (!initialized) {
				initialized = true;
				
				//to mark the item COMPLETED
				jQuery("#mark-completed").click(function(){
					jQuery(this).attr('disabled', 'disabled');
					jQuery(this).after('<div class="ajax-progress ajax-progress-throbber"><div class="throbber">&nbsp;</div></div>');
					var nid = jQuery(this).data("nid");
					var uid = jQuery(this).data("uid");
					jQuery.ajax({
						url: "/dashboard/mark-completed",
						data:{"uid":uid, "nid":nid},
						type: "POST",
						success:function(data){
              window.location.href = data;
						}
					});
				});
				
      }
    }
  };

})(jQuery, Drupal);
