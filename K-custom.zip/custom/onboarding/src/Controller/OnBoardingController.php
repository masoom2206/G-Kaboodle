<?php
 
/**
* @file
* Contains \Drupal\onboarding\Controller\OnBoardingController.php
*
*/
 
namespace Drupal\onboarding\Controller;
use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\Response;

class OnBoardingController extends ControllerBase {
  /**
   * Returns a Onboarding Dashboard page.
   *
   * @return array
   *   A simple renderable array.
   *   for getting-started page.
   */
	public function Onboarding_dashboard($user){
    global $base_url;
    $uid = $user->get('uid')->value;
		
		$status = $this->get_item_status($uid);
		
		$completed_items = count(array_keys($status, "Completed"));
		$percent = ($completed_items/8)*100;
		$percent = $percent.'%';
		
    $data = [
			'uid' => $uid,
			'status' => $status,
			'percent' => $percent,
		];
		$render_data['theme_data'] = array(
        '#theme' => 'onboarding',
        '#data' => $data,
        '#attached' => [
          'library' =>  [
            'onboarding/onboarding.main',
          ],
        ],
      );

    return $render_data;
	}
	
	/**
  * Returns a page title.
  */
  public function getTitle($node) {
    return  $node->getTitle();
  }
	
	/**
  * Returns a detail page.
  */
	public function detail_page($user, $node){
		$user = $user->get('uid')->value;
		
		//get youtube embed link
		$youtube_url = "";
		$youtube_field =  $node->get('field_media')->get(1);
		if ($youtube_field) {
			$url = $youtube_field->entity->get('field_media_video_embed_field')->get(0)->getValue();
			$url = $url['value'];
			preg_match('/[\?\&]v=([^\?\&]+)/', $url, $matches);
			$youtube_url = $matches[1];
		}
		
		//fetch default Branding Preset node of a user
    $branding_nid = \Drupal::database()->select('node_field_data', 'n')
    ->fields('n', ['nid'])
    ->condition('n.uid', $user, '=')
    ->condition('n.type', 'branding_preset', '=')
    ->range(0, 1)
    ->execute()
    ->fetchField();
		
		//update button link
		switch ($node->id()) {
			case 49:
					$update_btn_link = '/user/'.$user.'/edit';
					break;
			case 121:
					$update_btn_link = '/kit/item/social-media/'.$user;
					break;
			case 16:
					$update_btn_link = '/stripe-connect/'.$user;
					break;
			case 120:
					$update_btn_link = '/node/'.$branding_nid;
					break;
			case 122:
					$update_btn_link = '/node/add/metadata_preset';
					break;
			case 123:
					$update_btn_link = '/media/vault/'.$user;
					break;
			case 124:
					$update_btn_link = '/media/kit/'.$user;
					break;
			case 125:
					$update_btn_link = '/km/my-kaboodles/'.$user;
					break;		
			default:
					$update_btn_link = '/';
		}
		
		$status = $this->get_item_status($user);
		
    $data = [
			'user_id' => $user,
			'node_id' => $node->id(),
			'update_btn_link' => $update_btn_link,
			'youtube_url' => $youtube_url,
			'status' => $status,
			'current_node_status' => $status[$node->id()],
		];
		$render_data['theme_data'] = array(
        '#theme' => 'detail_page',
        '#data' => $data,
        '#attached' => [
          'library' =>  [
            'onboarding/onboarding.main',
          ],
        ],
      );

    return $render_data;
	}
	
	
	/**
  * To download PDF guide.
  */
	public function download_pdf_guide($node){
		$pdf_field = $node->get('field_media')->get(0);
		if ($pdf_field) {
			$uri = $pdf_field->entity->get('field_media_file')->entity->uri->value;
			$pdf_url = file_create_url($uri);
		}
		$file_name = 'guide.pdf';
    header('Content-disposition: attachment; filename="'.$file_name.'"');
    header("Content-Type: application/octet-stream");
    readfile($pdf_url);
    exit;
	}
  
	/**
  * To mark item completed.
  */
	public function mark_item_completed(){
		//get your POST parameter
    $nid = \Drupal::request()->get('nid');
    $uid = \Drupal::request()->get('uid');
		
		if(!empty($nid) && !empty($uid)) {
			\Drupal::database()->merge('item_tracking')
				->key([
					'uid' => $uid,
					'nid' => $nid,
				])
				->fields([
					'status' => 1,
				])
				->execute();	
		}
    
    $status = $this->get_item_status($uid);
		$completed_items = count(array_keys($status, "Completed"));
    if($completed_items == 8){
      $url = "/km/my-kaboodles/$uid";
    }
    else{
      $url = "/getting-started/$uid";
    }
		
		return new Response($url);
	}
	
	 /**
   * Fetch each item status.
   */
	public static function get_item_status($uid){
    $query = \Drupal::database()->select('node_field_data', 'n');
		$query->join('node__field_category', 'c', "n.nid = c.entity_id");
		$query->leftJoin('item_tracking', 'i', "n.nid = i.nid AND i.uid = $uid");
    $query->fields('n', ['nid']);
		$query->addExpression("IF(i.status = 1, 'Completed', 'In progress')", 'status');
    $query->condition('n.type', 'knowlege_base_article', '=');
    $query->condition('c.field_category_target_id', 204, '=');
    $result = $query->execute()->fetchAllKeyed();

    return $result;
	}
	
}