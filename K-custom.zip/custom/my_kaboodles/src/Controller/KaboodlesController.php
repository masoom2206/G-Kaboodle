<?php

/**
 * @file
 * Contains \Drupal\my_kaboodles\Controller\KaboodlesController.php
 *
 */

namespace Drupal\my_kaboodles\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Session\AccountInterface;
use Drupal\node\Entity\Node;

use Drupal\user\Entity\User;
use Drupal\media\Entity\Media;
use Drupal\file\Entity\File;
//use Drupal\Core\TypedData\Plugin\DataType;

//use Drupal\Core\Session\AccountProxyInterface;

//use \Drupal\Core\Entity\EntityInterface;
//use \Drupal\Core\Entity\Query\EntityQueryInterface;
//use Drupal\field\FieldConfigInterface;

/**
 * Defines KaboodlesController class.
 */
class KaboodlesController extends ControllerBase
{
  
    /**
    * Display the my-kaboodles page markup.
    *
    * @return array
    */
    public function content(AccountInterface $user, int $kaboodle_archive)
    {
        $me       = \Drupal::currentUser();
        $my_roles = $me->getRoles();
        $uid      = \Drupal::currentUser()->id();
        
        $user_id = $user->get('uid')->value;
        
        if (!empty($user_id) && in_array('administrator', $my_roles)) {
            $uid = $user_id;
        }
          
        $query = \Drupal::entityQuery('node');
        
        $query->condition('status', 1);
        $query->condition('uid', $uid);
        $query->condition('type', 'kaboodle');
        
        if (empty($kaboodle_archive)) {
            $group = $query->orConditionGroup()
                    ->notExists('field_archived')
                    ->condition('field_archived', '0', '=');
            $query->condition($group);
        } else {
            $query->condition('field_archived', 1, '=');
        }
        
        $entity_ids = $query->execute();
        
        if (empty($entity_ids)) {
            return [
                    '#theme'   => 'my_kaboodles_template',
                    '#foo'     => $this->t('no kaboodles - ' . $foo),
                    '#uid'     => $uid,
                    '#archive' => $kaboodle_archive,
                    ];
        }
        
        $data = array();
        $data = \Drupal::entityTypeManager()->getStorage('node')->loadMultiple($entity_ids);
        
        if (empty($data)) {
            return [
                    '#theme' => 'my_kaboodles_template',
                    '#foo'   => $this->t('empty data - ' . $foo),
                    '#uid'   => $uid,
                    '#archive' => $kaboodle_archive,
                    ];
        }
        
        foreach ($data as $row) {
            $out['title'] = $row->get('title')->value;
            
            $nid = $row->id();
            
            $img_val = $row->get('field_cover_image')->referencedEntities();
            $mid     = $img_val[0]->get('mid')->value;
            $media   = Media::load($mid);
            $fid     = $media->getSource()->getSourceFieldValue($media);
            $file    = File::load($fid);
            $url     = $file->url();
            
            $typ_val = $row->get('field_kaboodle_type')->referencedEntities();
            $tname   = $typ_val[0]->get('name')->value;
            
            $icon_id = $typ_val[0]->get('field_icon')->target_id;
            $ifile   = File::load($icon_id);
            $iurl    = $ifile->url();
            
            $out['img']  = $url;
            $out['icon'] = $iurl;
            $out['nid']  = $nid;
            
            $out['tname'] = $tname;
            
            $out['field_kaboodle_type'] = $typ_val;
            
            $ret[] = $out;
        }
        
        
        // TODO SHARED KABOODLES
        // TODO PAGING
        
        
        return [
                '#theme' => 'my_kaboodles_template',
                '#foo'   => $this->t('bar - ' . $foo ),
                '#data'  => $ret,
                '#uid'   => $uid,
                '#archive' => $kaboodle_archive,
                ];
    }

}
