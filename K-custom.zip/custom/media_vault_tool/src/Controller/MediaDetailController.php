<?php
 
/**
* @file
* Contains \Drupal\media_vault_tool\Controller\MediaDetailController.php
*
*/
 
namespace Drupal\media_vault_tool\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\Core\Session\AccountInterface;
use Drupal\node\NodeInterface;
use Drupal\Core\Controller\ControllerBase;
use Drupal\node\Entity\Node;
use Drupal\user\Entity\User;
use Drupal\media\Entity\Media;
use Symfony\Component\HttpFoundation\Request;

class MediaDetailController extends ControllerBase {
  /**
   * The current request.
   *
   * @var \Symfony\Component\HttpFoundation\Request $request
   *   The HTTP request object.
   */
  protected $request;
  
  /**
   * Returns a media vault detail page.
   *
   * @return array
   *   A simple renderable array.
   */
	public function render_media_detail_page(AccountInterface $user, int $media_archive){
    $uid= $user->get('uid')->value;
    $render_data = array();
    $nids_media_list = array();
    $query = \Drupal::entityQuery('node')->condition('uid', $uid)->condition('type', 'media_vault');
    $nids = $query->execute();
    
    $query_media_kit = \Drupal::database()->select('node_field_data', 'n')
    ->fields('n', ['nid', 'title'])
    ->condition('n.uid', $uid, '=')
    ->condition('n.type', 'media_kit', '=');
    
    $nids_media_kit = $query_media_kit->execute()->fetchAll();
/*     if(!empty($nids_media_kit) && isset($nids_media_kit)){
      foreach($nids_media_kit as $media_kit_value){
        $nids_media_list[] = $media_kit_value;
      }
    } */
    foreach($nids as $node_id){
      global $base_url;
      $media_vault_id = $node_id;
      $media_form = 'Media Vault Form';
      $values = 'Media Vault data';
      $data = array('media_form' => $media_form, 'values' => $values);
      $render_data['theme_data'] = array(
        '#theme' => 'media_vault_template',
        '#media_vault_title' => $this->t('Media Vault'),
        '#doubles' => $data,         
        '#attached' => [
          'library' =>  [
            'media_vault_tool/media.vault',
            'media_vault_tool/mvt_plupload',
            'media_vault_tool/react.min',
            'media_vault_tool/react.dom.min',
            'media_vault_tool/axios',
            'media_vault_tool/global',
          ],
        ],
      );
      $render_data['theme_data']['#attached']['drupalSettings']['media']['mediaJS']['media_vault_id'] = $media_vault_id;
      $render_data['theme_data']['#attached']['drupalSettings']['nmk'] = $nids_media_kit;
      
      $render_data['theme_data']['#attached']['drupalSettings']['media_base_url'] = $base_url;
      $render_data['theme_data']['#attached']['drupalSettings']['media_archive'] = $media_archive;
      $render_data['theme_data']['#attached']['drupalSettings']['a'] = $uid;
    }
    return $render_data;
	}
  
  public function update_media_favorite(){
    if(isset($_POST['mid'])) {
      $mid = $_POST['mid'];
      $media = \Drupal::entityTypeManager()->getStorage('media')->load($mid);
      if($media->field_favorite->value == 0){
        $media->set('field_favorite', 1);
        $result = $media->save();
        $favo_text = 'favorite';
      } else {
        $media->set('field_favorite', 0);
        $result = $media->save();
        $favo_text = 'not favorite';
      } 
      $message = drupal_set_message('Media has been marked as '.$favo_text.'.', 'status');
      return $message;
    } 
  }
  
  
  public function getallMediaByfile($mid, $type){
    if($type == 'audio') {
      $medialist = \Drupal::database()->select('node_field_data', 'n');
      $medialist->leftJoin('node__field_vault_audio', 'a', "n.nid = a.entity_id");
      $medialist->condition('a.field_vault_audio_target_id', $mid, '=');
      $medialist->condition('a.bundle', 'media_kit', '=');
      $medialist->fields('n', ['uid','title']);
      $result = $medialist->execute()->fetchAll();
    }  
    if($type == 'image') {   
      $medialist = \Drupal::database()->select('node_field_data', 'n');
      $medialist->leftJoin('node__field_vault_photo', 'p', "n.nid = p.entity_id");
      $medialist->condition('p.field_vault_photo_target_id', $mid, '=');
      $medialist->condition('p.bundle', 'media_kit', '=');
      $medialist->fields('n', ['uid','title']);
      $result = $medialist->execute()->fetchAll();
    }
    if($type == 'text') {
      $medialist = \Drupal::database()->select('node_field_data', 'n');
      $medialist->leftJoin('node__field_vault_file', 't', "n.nid = t.entity_id");
      $medialist->condition('t.field_vault_file_target_id', $mid, '=');
      $medialist->condition('t.bundle', 'media_kit', '=');
      $medialist->fields('n', ['uid','title']);
      $result = $medialist->execute()->fetchAll();
    }
    if($type == 'video') {
      $medialist = \Drupal::database()->select('node_field_data', 'n');
      $medialist->leftJoin('node__field_vault_video', 'v', "n.nid = v.entity_id");
      $medialist->condition('v.field_vault_video_target_id', $mid, '=');
      $medialist->condition('v.bundle', 'media_kit', '=');
      $medialist->fields('n', ['uid','title']);
      $result = $medialist->execute()->fetchAll();
    }
    
    return $result;
  }
  
  public function mediaEditTitle(AccountInterface $user, Media $media) {
    $favurl = \Drupal\Core\Url::fromUserInput('#');
    $id = $media->mid->value;
    if($media->field_favorite->value == 0){
      $class = 'favo-inactive';      
    } else {
      $class = 'favo-active';
    }
    $link_options = [
      'attributes' => [
        'class' => [
          $class,
          'favolink',
        ],
        'id' => $id,
      ],
    ];
    $favurl->setOptions($link_options);
    $favorite = \Drupal::l('', $favurl);
    return ['#markup' => 'Edit '. '"'.$media->label().'"  '.$favorite, '#allowed_tags' => \Drupal\Component\Utility\Xss::getHtmlTagList()];
  }
  
  public function getMediasortingByuid(AccountInterface $user, $type) {
    $uid= $user->get('uid')->value;
    $database = \Drupal::database();
    $query = $database->select('media_field_data', 'md');
		$query->join('media_vault_sorting', 'm', "md.mid = m.mid");
    $query->fields('md', ['mid', 'name']);
    $query->condition('md.uid', $uid, '=');
    $query->condition('md.bundle', $type, '=');
		$query->orderBy('m.sort_number', 'ASC');
    $result = $query->execute()->fetchAll();
 
    $response = $result;
    return new JsonResponse($response);
  }
  
  public function getMediaKitBymid($mid, $type) {
    $database = \Drupal::database();
    if($type == 'audio') {
      $query = $database->select('node_field_data', 'n');
      $query->join('node__field_vault_audio', 'm', "n.nid = m.entity_id");
      $query->fields('n', ['uid', 'title']);
      $query->condition('m.bundle', 'media_kit', '=');
      $query->condition('m.field_vault_audio_target_id', $mid, '=');
      $result = $query->execute()->fetchAll();
    }  
    if($type == 'image') {   
      $query = $database->select('node_field_data', 'n');
      $query->join('node__field_vault_photo', 'm', "n.nid = m.entity_id");
      $query->fields('n', ['uid', 'title']);
      $query->condition('m.bundle', 'media_kit', '=');
      $query->condition('m.field_vault_photo_target_id', $mid, '=');
      $result = $query->execute()->fetchAll();
    }
    if($type == 'text') {
      $query = $database->select('node_field_data', 'n');
      $query->join('node__field_vault_file', 'm', "n.nid = m.entity_id");
      $query->fields('n', ['uid', 'title']);
      $query->condition('m.bundle', 'media_kit', '=');
      $query->condition('m.field_vault_file_target_id', $mid, '=');
      $result = $query->execute()->fetchAll();
    }
    if($type == 'video') {
      $query = $database->select('node_field_data', 'n');
      $query->join('node__field_vault_video', 'm', "n.nid = m.entity_id");
      $query->fields('n', ['uid', 'title']);
      $query->condition('m.bundle', 'media_kit', '=');
      $query->condition('m.field_vault_video_target_id', $mid, '=');
      $result = $query->execute()->fetchAll();
    }
    
    $response = $result;
    return new JsonResponse($response);
  }
  
  public function media_vault_sortable() {
    if(isset($_POST['uid']) && isset($_POST['mid'])) {
      $uid = $_POST['uid'];
      $type = $_POST['type'];
		
      //delete records from "media_vault_sorting" table.
      \Drupal::database()->delete('media_vault_sorting')
          ->condition('uid', $uid, '=')
          ->condition('type', $type, '=')
          ->execute();
            
      // Insert the records to "media_vault_sorting" table.
      $order = 1;
      foreach($_POST['mid'] as $mid){
        $result = \Drupal::database()->insert('media_vault_sorting')
          ->fields([
            'uid',
            'mid',
            'type',
            'sort_number',
          ])
          ->values(array(
            $uid,
            $mid,
            $type,
            $order,
          ))
          ->execute();
        $order ++;	
      }
      $response = $result;
      return new JsonResponse($response);
    }
	}
}