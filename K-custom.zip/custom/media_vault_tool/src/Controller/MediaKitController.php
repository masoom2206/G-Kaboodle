<?php
 
/**
* @file
* Contains \Drupal\media_vault_tool\Controller\MediaKitController.php
*
*/
 
namespace Drupal\media_vault_tool\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\Core\Session\AccountInterface;
use Drupal\node\NodeInterface;
use Drupal\Core\Controller\ControllerBase;
use Drupal\node\Entity\Node;
use Drupal\user\Entity\User;
use Drupal\Core\Access\AccessResult;

class MediaKitController extends ControllerBase {
  /**
   * Returns a media kit page.
   *
   * @return array
   *   A simple renderable array.
   */
	public function render_media_kit_page(AccountInterface $user){
    global $base_url;
    $uid = $user->get('uid')->value;
    
    //fetch media vault of a user
    $database = \Drupal::database();
    $media_vault_id = $database->select('node_field_data', 'n')
    ->fields('n', ['nid'])
    ->condition('n.uid', $uid, '=')
    ->condition('n.type', 'media_vault', '=')
    ->execute()
    ->fetchField();
    
    //fetch default media kit of a user
    $default_media_kit = \Drupal::database()->select('node_field_data', 'n')
    ->fields('n', ['nid', 'title', 'uid'])
    ->condition('n.uid', $uid, '=')
    ->condition('n.type', 'media_kit', '=')
    ->range(0, 1)
    ->execute()
    ->fetchAssoc();
    
    $render_data['theme_data'] = array(
        '#theme' => 'media_kit_template',
        '#data' => $default_media_kit,
        '#attached' => [
          'library' =>  [
            'media_vault_tool/media_kit',
            'media_vault_tool/react.min',
            'media_vault_tool/react.dom.min',
            'media_vault_tool/axios',
            'media_vault_tool/media.vault',
          ],
        ],
      );
    $render_data['theme_data']['#attached']['drupalSettings']['media_vault_id'] = $media_vault_id;  
    $render_data['theme_data']['#attached']['drupalSettings']['media_base_url'] = $base_url;
    $render_data['theme_data']['#attached']['drupalSettings']['default_media_kit_id'] = $default_media_kit['nid'];
    $render_data['theme_data']['#attached']['drupalSettings']['path_userid'] = $uid;
    return $render_data;
	}
  
  public function get_user_media_kits(AccountInterface $user){
    $uid = $user->get('uid')->value;
    
    $database = \Drupal::database();
    $query = $database->select('node_field_data', 'n');
		$query->leftJoin('media_kit_sorting', 'm', "n.nid = m.nid");
    $query->fields('n', ['nid', 'title']);
    $query->condition('n.uid', $uid, '=');
    $query->condition('n.type', 'media_kit', '=');
		$query->orderBy('m.sort_number', 'ASC');
    $result = $query->execute()->fetchAll();
 
    $response = $result;
    return new JsonResponse($response);
  }
  
  public function media_access(AccountInterface $account, $user){
    $roles = $account->getRoles();
    if(in_array('administrator', $roles) || in_array('va_manager', $roles)){
      return AccessResult::allowed();
    }
    else if ($account->id() == $user) {
      return AccessResult::allowed();
    }
    else{
      return AccessResult::forbidden();
    }
  }
	
	public function media_kits_sortable(){
	 if(isset($_POST['uid']) && isset($_POST['nid'])) {
		$uid = $_POST['uid'];
		
		//delete records from "media_kit_sorting" table.
		\Drupal::database()->delete('media_kit_sorting')
				->condition('uid', $uid, '=')
				->execute();
					
		// Insert the records to "media_kit_sorting" table.
		$order = 1;
		foreach($_POST['nid'] as $nid){
			\Drupal::database()->insert('media_kit_sorting')
				->fields([
					'uid',
					'nid',
					'sort_number',
				])
				->values(array(
					$uid,
					$nid,
					$order,
				))
				->execute();
			$order ++;	
		}
		echo "done";
		exit;
	 }
	}
  
}