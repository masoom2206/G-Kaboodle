<?php
namespace Drupal\media_vault_tool\Normalizer;

use Drupal\serialization\Normalizer\ContentEntityNormalizer;
use Drupal\media\Entity;
use Drupal\media\Entity\Media;

/**
 * Converts the media entity object structures to a normalized array.
 * The interface or class that this Normalizer supports.
 */
 
class MediaEntityNormalizer extends ContentEntityNormalizer {
 
  
  /**
   * @var \Drupal\media\Entity\Media $entity 
   */
  public function normalize($entity, $format = NULL, array $context = array()) {
    $attributes = parent::normalize($entity, $format, $context);
    $style = \Drupal::entityTypeManager()->getStorage('image_style')->load('90x90_media_vault_photo');  
    switch ($entity->getEntityTypeId()) {
      case 'media':
        $media_source = $entity->getSource();
        switch ($attributes['bundle'][0]['target_id']) {
          case 'image':
            $media = Media::load($attributes['mid'][0]['value']);
            $style_url = $style->buildUrl($media->field_media_image->entity->getFileUri());
            $attributes['field_media_image'][0]['image_style'] = $style_url;
          break;
     
          case 'video':
            if(!empty($attributes['field_media_image'])){
              $is_thumbnail = true;
              $media = Media::load($attributes['mid'][0]['value']);
              $style_url = $style->buildUrl($media->field_media_image->entity->getFileUri());
            } else {
              $is_thumbnail = false;
              $style_url = $attributes['field_media_video_file'][0]['url'];
            }
            $attributes['field_media_video_file'][0]['is_thumbnail'] = $is_thumbnail;
            $attributes['field_media_video_file'][0]['image_style'] = $style_url;
          break;
        }
      break;
    }
    // Re-sort the array after our new additions
    ksort($attributes);
    
    // Return the $attributes with our new values
    return $attributes;
  }
}