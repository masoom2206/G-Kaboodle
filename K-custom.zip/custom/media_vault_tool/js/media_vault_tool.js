(function ($, Drupal, drupalSettings) {
  var initialized;
  Drupal.behaviors.MediaBehavior = {
    attach: function (context, settings) {
      if (!initialized) {
        initialized = true;
        var media_vault_id = drupalSettings.media.mediaJS.media_vault_id;
        var media_base_url = drupalSettings.media_base_url;
        var media_archive = drupalSettings.media_archive;
        var a = drupalSettings.a;
        var nmk = drupalSettings.nmk;
        var archive_text;
        var selectedRows_audio = [];
        var selectedRows_photo = [];
        var selectedRows_text = [];
        var selectedRows_video = [];
        var txtfilename = [];
        
        //Confirmation Delete Modal 
        let Modal = React.createClass({
          componentDidMount: function() {
              jQuery(this.getDOMNode()).modal('show');
              jQuery(this.getDOMNode()).on('hidden.bs.modal', this.props.handleHideModal);
          },
          render: function() {
            var btnCancel = React.createElement('button', {type: 'button', className: 'btn btn-default', onClick:this.closeModal.bind()},'Cancel');
            var title_msg = 'Archive selected '+ this.props.fileType +'?';
            var button_text = 'Archive';
            if(this.props.arc_status == 1){
              title_msg = 'Restore selected '+ this.props.fileType +'?';
              button_text = 'Restore';
            }
            if(this.props.filemismatch && this.props.arc_status == 0){
              btnCancel = '';
              title_msg = '';
              button_text = 'OK';
            }
            return (
                React.createElement('div', {id: 'modal', className: 'modal fade'},
                  React.createElement('div', {className: 'modal-dialog'},
                    React.createElement('div', {className: 'modal-content'},
                      React.createElement('div', {className: 'modal-header'},
                        React.createElement('h4', {className: 'modal-title'}, title_msg)
                      ),
                      React.createElement('div', {className: 'modal-body'},this.props.delete_modal_msg),
                      React.createElement('div', {className: 'modal-footer'},
                        btnCancel,
                        React.createElement('button', {type: 'button', className: 'btn btn-primary', onClick: this.props.handleArchive},button_text),                        
                      ),
                    )
                  )
                )
              )
          },
          closeModal : function(){
            jQuery('#modal').modal('hide');
          },
          propTypes:{
            handleHideModal: React.PropTypes.func.isRequired
          }
        });
        //VideoPlayer Modal
        let VideoPlayer = React.createClass({
          componentDidMount: function() {
              jQuery(this.getDOMNode()).modal('show');
              jQuery(this.getDOMNode()).on('shown.bs.modal', function () {
                jQuery('.modal-video-playing')[0].play();
              });
              jQuery('.modal-video-playing').on("timeupdate", this.props.seektimeupdate);
              jQuery('.modal-video-playing').on("ended", this.props.videoCompleted);
              jQuery(this.getDOMNode()).on('hidden.bs.modal', this.props.handleHideVideoPlayer);
          },
          render: function() {
            return (
              React.createElement('div', {id: 'modal', className: 'modal fade video-modal'},
                React.createElement('div', {className: 'modal-dialog'},
                  React.createElement('div', {className: 'modal-content'},
                    React.createElement('button', {type: 'Button', className: 'close video-close', 'data-dismiss': 'modal'},
                      React.createElement('i', {className:"fa fa-times"},'')
                    ),
                    React.createElement('div', {className: 'spinner-border'}, ''),
                    React.createElement("video", {className: 'modal-video-playing'}, 
                      React.createElement('source', {src:this.props.fileURL},'')
                    ),
                    React.createElement('div', {className:'control-box'},
                      React.createElement('div', {className: 'upper-box col-xl-12 col-md-12'},
                        React.createElement('div', {className: 'row'}, 
                          React.createElement('div', {className: 'col-md-4'}, 
                            React.createElement('i', {className: 'fa fa-volume-down'},''),
                            React.createElement('input', {type: 'Range', className: 'video-volume-control', value: this.props.volume_level, min: 0, max: 1, step: 0.1, onChange: this.props.VVolControl},''),
                            React.createElement('i', {className: 'fa fa-volume-up'},'')
                          ),
                          React.createElement('div', {className: 'col-md-4 text-center'},
                            React.createElement('i', {className: 'fa fa-backward', onClick: this.props.playnowPrev},''),
                            React.createElement('i', {className: this.props.playnowclass, onClick: this.props.playNowVideo},''),
                            React.createElement('i', {className: 'fa fa-forward', onClick: this.props.playnowNext},'')
                          ),
                          React.createElement('div', {className: 'col-md-3'}, '')
                        )
                      ),
                      React.createElement('div', {className: 'lower-box'},
                        React.createElement('span', {id: 'start'}, this.props.curtimetext),
                        React.createElement('input', {type: 'Range', className: 'time-control',min:'0', max:'100', value: this.props.seekslider_value, step:'1', onChange: this.props.vidSeek},''),
                        React.createElement('span', {id: 'end'}, this.props.durtimetext)
                      )
                    )
                  )
                )
              )
            )
          },
          propTypes:{
            handleHideVideoPlayer: React.PropTypes.func.isRequired,
          }
        });
        
        //Caption form
        /* let captionForm = React.createElement('form',{id:'gallery-caption', style:{display:'none'}},
                React.createElement('label',{htmlFor:'caption-data', style:{display:'none'}}, 'Photo Description'),
                React.createElement('input', { id:'caption-data', placeholder: 'Add a caption to this photo', type: 'text', autoFocus: true,style:{display:'none'}}),
                React.createElement('button', {type: 'submit', className: 'btn btn-primary',style:{display:'none'}}, 'Save')   
              ); */
        //Text Reader Modal
        let textReader = React.createClass({
          componentDidMount: function() {
              jQuery(this.getDOMNode()).modal('show');
              jQuery(this.getDOMNode()).on('hidden.bs.modal', this.props.hideTextReaderModal);
          },
          render: function() {
            return (
                React.createElement('div', {id: 'modal', className: 'modal fade text-reader'},
                  React.createElement('div', {className: 'modal-dialog'},
                    React.createElement('div', {className: 'modal-content'},
                      React.createElement('div', {className: 'modal-body'},
                        React.createElement('iframe', {className: 'text', src: 'https://docs.google.com/gview?url='+this.props.textFileURL+'&embedded=true', width: '100%', height: '500px'})
                      ),
                    )
                  )
                )
              )
          },
          propTypes:{
            hideTextReaderModal: React.PropTypes.func.isRequired
          }
        });

        //Remote video modal player
        let RemoteVideoModal = React.createClass({
          componentDidMount: function() {
              jQuery(this.getDOMNode()).modal('show');
              jQuery(this.getDOMNode()).on('hidden.bs.modal', this.props.handleHideModal);
          },
          render: function() {
            return (
                React.createElement('div', {id: 'modal', className: 'modal fade'},
                  React.createElement('div', {className: 'modal-dialog'},
                    React.createElement('div', {className: 'modal-content'},
                      React.createElement('iframe', {className: 'remote-video-modal', src: '//www.youtube.com/embed/'+this.props.videolink, 'frameborder':'0', width: '600px', height: '400px'}),
                    )
                  )
                )
              )
          },
          propTypes:{
            handleHideModal: React.PropTypes.func.isRequired
          }
        });

        // Sample rate and Rating value component
        var AppTaxo = React.createClass({
          getInitialState: function() {
            return {
              taxoValue: '',
            }
          },
          componentWillMount: function() {
            var th = this;
            this.serverRequest = 
              axios.get(this.props.base_url+'/'+this.props.srate+'?_format=json')
                .then(function(result) { 
                  th.setState({
                    taxoValue: result.data.name[0].value
                  });
                })
          },
          componentWillUnmount: function() {
            //this.serverRequest.abort();
          },
          render: function() {
            return React.createElement('span', {className: ''}, this.state.taxoValue)
          },
        });
        //File extention component
        var AppExtention = React.createClass({
          getInitialState: function() {
            return {
              fileExtension: '',
            }
          },
          componentWillMount: function() {
            var th = this;
            this.serverRequest = 
              axios.get(this.props.base_url+'/entity/file/'+this.props.fid+'?_format=json')
                .then(function(result) { 
                  th.setState({fileExtension: result.data.filename[0].value});
                })
          },
          componentWillUnmount: function() {
            //this.serverRequest.abort();
          },
          render: function() {
            var extName = (this.state.fileExtension).split('.').pop();
            if(Boolean(this.props.get_type_col)){
              if(extName == 'jpg' || extName == 'jpeg'){
                extName = 'JPEG file';
              }else if(extName == 'png'){
                extName = 'PNG image';
              }else if(extName == 'NEF'){
                extName = 'Camera Raw Image';
              }else if(extName == 'svg'){
                extName = 'SVG Image';
              }else if(extName == 'gif'){
                extName = 'GIF image';
              }else if(extName == 'pdf'){
                extName = 'pdf';
              }else if(extName == 'docx'){
                extName = 'Microsoft Word document';
              }else if(extName == 'txt'){
                extName = 'Plain Text file';
              }else if(extName == 'rtf'){
                extName = 'Rich Text Format document';
              }else if(extName == 'wpd'){
                extName = 'WordPerfect document';
              }else if(extName == 'pages'){
                extName = 'Pages document';
              }
            } 
            return React.createElement('span', {}, extName)
          },
        });
        
        //get Media attached to media kit // media kit indicator
        var AppMediaKits = React.createClass({
          getInitialState: function() {
            return {
              mediaKits: '',
            }
          },
          componentWillMount: function() {
            var th = this;
            this.serverRequest =
              axios.get(this.props.base_url+'/media/mediakit/'+this.props.mid+'/'+this.props.fileType+'?_format=json')
              .then(function(response) {
                return response.data;
              })
              .then(function(data) {
                th.setState({mediaKits: data});
              });
            document.addEventListener('mouseover', th.tooltipfn.bind());     
          },
          componentWillUnmount: function() {
            //this.serverRequest.abort();
          },
          tooltipfn: function(event) {
            jQuery('[data-toggle="tooltip"]').tooltip({placement : 'right'});
          },
          render: function() {
            var elem = null;
            if(this.state.mediaKits.length > 0){
              var titlearr = [];
              var kit_uid = this.state.mediaKits[0].uid;
              var tooltip_elem = this.state.mediaKits.map((kitem, kkey) => {
                titlearr.push(kitem.title);
              });
              var tolltip_title = titlearr.join(", ");
              elem = React.createElement('a', {'data-toggle':'tooltip', 'data-placement': 'right', href:'/media/kit/'+kit_uid, 'title': tolltip_title, onmouseover: this.tooltipfn.bind(this)}, React.createElement('span', {className: 'mk-indicator'}))
            }
            return React.createElement('span', {}, elem)
          },
        });
        
        //File size
        var AppFileSize = React.createClass({
          getInitialState: function() {
            return {
              value: '-',
            }
          },
          componentWillMount: function() {
            var th = this;
            this.serverRequest = 
              axios.get(this.props.base_url+'/entity/file/'+this.props.fid+'?_format=json')
                .then(function(result) { 
                  th.setState({value: result.data.filesize[0].value});
                })
          },
          componentWillUnmount: function() {
          },
          render: function() {
            // Convert bytes to kilobytes.
            var units = ['KB','MB','GB','TB','PB','EB','ZB','YB'];
            var bytes = this.state.value;
            if(bytes <= 0){
              bytes = bytes + " bytes";
             }else{
              bytes = bytes / 1024;
              for(i= 0; i< units.length; i++){
                if (bytes.toFixed(2) >= 1024) {
                  bytes = bytes / 1024;
                }
                else {
                  bytes = bytes.toFixed(2);
                  break;
                }
              }
              bytes = bytes +' '+ units[i];
             }
            return React.createElement('span', {className: ''}, bytes)
          },
        });
        //Media Filename
        var AppFileName = React.createClass({
          getInitialState: function() {
            return {
              value: '-',
            }
          },
          componentWillMount: function() {
            var th = this;
            this.serverRequest = 
              axios.get(this.props.base_url+'/entity/file/'+this.props.fid+'?_format=json')
                .then(function(result) { 
                  th.setState({value: result.data.filename[0].value});
                })
          },
          componentWillUnmount: function() {
          },
          render: function() {
            return React.createElement('span', {className: ''}, this.state.value)
          },
        });
        
        //Custom file uploader component
        var FileUploader = React.createClass({
          getInitialState: function() {
            return {
              dragmsg: '',
              delete_modal_msg: '',
              filesizeError: false,
              filemismatch: false,
              filemismatch_modal_status: false,
              DS_modal_msg: '',
              base_url: media_base_url,
              arc_status: media_archive,
            }
          },
          componentDidMount: function(){
            var th = this;
             // Apply plupload
            var total_file_size = 0;
            var err_fType = '';
            var ft = th.props.fileType;
            var ex = th.props.extensions;
            var uploader = new plupload.Uploader({
              runtimes : 'html5,flash,silverlight,html4',
              browse_button : 'pickfiles_'+th.props.fileType, // you can pass an id...
              drop_element : 'media-upload-list_'+th.props.fileType,
              url : '/mvt-handle-uploads/'+th.props.fileType+'/'+media_vault_id,
              unique_names : true,
              dragdrop: true,
              flash_swf_url : '../js/Moxie.swf',
              silverlight_xap_url : '../js/Moxie.xap',
              
              filters : {
                mime_types: [
                  {title : "Media files", extensions : ex}
                ]
              },
              // PreInit events, bound before any internal events
              preinit : {
                Init: function(up, info) {
                  //console.log(1);
                  //console.log(up);
                },

                UploadFile: function(up, file) {
                  // You can override settings before the file is uploaded
                  // up.setOption('url', 'upload.php?id=' + file.id);
                  //up.setOption('multipart_params', {param1 : body});
                }
              },
              init: {
                PostInit: function() {
                  //document.getElementById('media-upload-list').innerHTML = '';

                  document.getElementById('uploadfiles_'+ft).onclick = function() {
                    //console.log('upload click')
                    if (!jQuery(this).hasClass('plupload_disabled')) {
                      uploader.start();
                    }
                    return false;
                  };
                  if (!uploader.files.length) {
                    jQuery('#uploadfiles_'+ft).addClass('plupload_disabled');
                  }
                },
                Refresh: function(up) {
                  // Called when the position or dimensions of the picker change
                  //console.log(up);              
                },
                QueueChanged: function(up) {
                  jQuery('#media-upload-list_'+ft).addClass('queued');
                  document.getElementsByClassName('media_total_file_size_'+ft)[0].innerHTML = plupload.formatSize(uploader.total.size);
                  jQuery('#media-container-'+ft+' span.plupload_upload_status').html(plupload.sprintf(('%d files queued'), uploader.total.queued));
                },                               
                StateChanged: function() {
                  uploader.disableBrowse(true);
                },
                FilesAdded: function(up, files) {
                  //console.log(uploader.files);
                  if (uploader.files.length) {
                    jQuery('#uploadfiles_'+ft).removeClass('plupload_disabled');
                  }
                  plupload.each(files, function(file) {
                    document.getElementById('media-upload-list_'+ft).innerHTML += '<li id="' + file.id + '" class=""><div class="plupload_file_name"><span>' + file.name + '</span></div><div class="plupload_file_action"><button type="button"></button></div><div class="plupload_file_status text-center">0%</div><div class="plupload_file_size text-center">' + plupload.formatSize(file.size) + '</div><div class="plupload_clearer">&nbsp;</div></li>';
                    th.handleStatus(file); 
                    //console.log(file);
                  });
                  jQuery('#media-upload-list_'+ft+' li.plupload_delete').each(function(i){
                    jQuery(this).children('.plupload_file_action').children('button').click(function(e){
                      e.preventDefault(); 
                      var current_file_id = jQuery(this).parent('.plupload_file_action').parent('.plupload_delete').attr('id');
                      jQuery('#'+current_file_id).remove();
                      console.log(current_file_id);                   
                      for( var i = 0; i < uploader.files.length; i++){ 
                        if ( uploader.files[i].id === current_file_id) {
                          uploader.removeFile(uploader.files[i]);
                        }
                      }                      
                    });
                  }); 
                  if (uploader.total.queued !== 0) {
                    jQuery('#media-container-'+ft+' span.plupload_upload_status').css('display', 'block');
                  }
                },
                FilesRemoved: function(up, files) {
                  // Called when files are removed from queue 
                  if (uploader.total.queued === 0) {
                    jQuery('#media-container-'+ft+' span.plupload_upload_status').css('display', 'none');
                  }
                  console.log('updated queued - ' + uploader.total.queued);
                  console.log('updated files length - ' + uploader.files.length);                    
                  var scrollTop = jQuery('#media-upload-list_'+ft).scrollTop();
                  jQuery('#media-upload-list_'+ft).scrollTop(scrollTop);
                  jQuery('#media-container-'+ft+' span.plupload_upload_status').html(plupload.sprintf(('%d files queued'), uploader.total.queued));
                },
                UploadProgress: function(up, file) {
                  th.handleStatus(file);
                  document.getElementById(file.id).getElementsByClassName('plupload_file_status')[0].innerHTML = file.percent+'%';
                  //upload progress
                  jQuery('.total_status_'+ft).html(uploader.total.percent + '%');
                  jQuery('#media-container-'+ft+' div.plupload_progress').css('display', 'block');
                  jQuery('#media-container-'+ft+' div.plupload_progress_bar').css('width', uploader.total.percent + '%');
                  jQuery('#media-container-'+ft+' span.plupload_upload_status').css('display', 'block');
                  jQuery('#media-container-'+ft+' span.plupload_upload_status').html(plupload.sprintf(('Uploaded %d/%d files'), uploader.total.uploaded, uploader.files.length));
                },
                FileUploaded: function(up, file, info) {
                  // Called when file has finished uploading
                  th.handleStatus(file);
                },
                UploadComplete: function(up, files) {
                  // Called when all files are either uploaded or failed
                  window.location.reload();
                },
                Error: function(up, err) {
                  var file = err.file, message;
                  if (file) {
                    message = err.message;
                    if (err.details) {
                      message += " (" + err.details + ")";
                    }
                    if (err.code == plupload.FILE_SIZE_ERROR) {
                      th.setState({filemismatch: true});
                      th.setState({filesizeError: true});
                      th.ShowFilesmismatchModal(file.name);
                    }
                    if (err.code == plupload.FILE_EXTENSION_ERROR) { 
                      th.setState({filemismatch: true});
                      var type = (file.type).split('/');
                      if (type) {
                        var extype = type[0];
                      }
                      if(extype == 'image') {
                        err_fType = 'Photo';
                      }
                      if (extype == 'audio') {
                        err_fType = 'Audio';
                      }
                      if (extype == 'application') {
                        err_fType = 'Text';
                      }
                      if (extype == 'video') {
                        err_fType = 'Video';
                      }                
                      th.ShowFilesmismatchModal(err_fType);
                    }
                    file.hint = message;
                    jQuery('#media-upload-list_'+ft+' #'+file.id).attr('class', 'plupload_failed').find('a').css('display', 'block').attr('title', message);
                  }

                  if (err.code === plupload.INIT_ERROR) {
                    setTimeout(function() {
                      uploader.destroy();
                      uploader = null;
                    }, 1);
                  }                 
                }
              }
            });

            uploader.init();
            
          },
          handleStatus: function(file) {
            var ft = this.props.fileType;
            var actionClass;
            if (file.status == plupload.DONE) {
              actionClass = 'plupload_done';
            }
            if (file.status == plupload.FAILED) {
              actionClass = 'plupload_failed';
            }
            if (file.status == plupload.QUEUED) {
              actionClass = 'plupload_delete';
            }
            if (file.status == plupload.UPLOADING) {
              actionClass = 'plupload_uploading';
            }
            var icon = jQuery('#media-upload-list_'+ft+' #'+file.id).attr('class', actionClass).find('a').css('display', 'block');
            if (file.hint) {
              icon.attr('title', file.hint);
            }
          },
          ShowFilesmismatchModal: function(err_fType){
            var msg = React.createElement("div", {className: 'text-center', style: {'padding': '1rem 0'}}, err_fType, " files need to be uploaded via the ", err_fType, " tab.");
            if(this.state.filesizeError){
              var msg = React.createElement("div", {className: 'text-center', style: {'padding': '1rem 0'}}, "Size of the file - ", React.createElement("b", null, err_fType), " is too large.");
            }
            this.setState({filemismatch_modal_status: true});
            this.setState({DS_modal_msg: msg});
          },                                        
          fcloseModal : function(){
            jQuery('#modal').modal('hide');
            this.setState({filemismatch_modal_status: false});
            this.setState({DS_modal_msg: ''});
            this.setState({filemismatch: false});
            this.setState({filesizeError: false});
          },
          render: function() {
            if (this.state.filemismatch_modal_status) {
              var filemismatchModalElement = React.createElement(Modal, {handleArchive: this.fcloseModal, fileType: this.props.fileType, filemismatch: this.state.filemismatch, base_url:this.state.base_url, delete_modal_msg: this.state.DS_modal_msg, arc_status: this.state.arc_status});
            }
            return React.createElement('div', {className:'media-box-wrapper'},
              React.createElement('div', {id: 'media-container-'+this.props.fileType, className: 'media-container'},
                React.createElement('div', {className: 'media-header'},
                  React.createElement('div', {className: 'file_name'}, 'Filename'),
                  React.createElement('div', {className: 'file_action'}, null),
                  React.createElement('div', {className: 'file_status text-center'},
                    React.createElement('span', null, 'Status')
                    ),
                  React.createElement('div', {className: 'file_size text-center'},
                    React.createElement('span', null, 'Size')
                  ),
                  React.createElement('div', {className:'plupload_clearer'})
                ),
                React.createElement('ul', {id:'media-upload-list_'+this.props.fileType, className: 'media_filelist'},
                  React.createElement('li', {className: 'media_droptext'}, this.props.dragmsg)
                ),
                React.createElement('div', {className: 'media_filelist_footer'}, 
                  React.createElement('div', {className: 'file_name'},
                    React.createElement('div', {className: 'file_add_buttons'},
                      React.createElement('a', {id:'pickfiles_'+this.props.fileType, className:'button_add_file'}, 'Add files')
                    ),
                    React.createElement('span', {className: 'plupload_upload_status'})
                  ),
                  React.createElement('div', {className: 'file_action'}, null),
                  React.createElement('div', {className: 'file_status text-center'}, React.createElement('span', {className: 'total_status_'+this.props.fileType}, '0%')
                  ),
                  React.createElement('div', {className: 'file_size text-center'},
                    React.createElement('span', {className: 'media_total_file_size_'+this.props.fileType}, '0 b')
                  ),
                  React.createElement('div', {className: 'plupload_progress'},
                    React.createElement('div', {className: 'plupload_progress_container'}, React.createElement('div', {className: 'plupload_progress_bar'}, null)
                    )
                  ),
                  React.createElement('div', {className:'plupload_clearer'})
                )
              ),
              /* React.createElement('div', {className:'input-file-wrapper'},
                React.createElement('input', {type: 'file', className:'audio-file-input', accept:this.props.fileType, 'multiple':'multiple'})
              ), */
              React.createElement('button', {type: 'submit', id:'uploadfiles_'+this.props.fileType, className:'upload-save-button btn btn-primary'}, 'Upload & Save'),
              filemismatchModalElement
            )
            
          },
        });       
        
        //Select Download Section
        var SelectDownload = React.createClass({
        getInitialState: function() {
            return {
              checked_status: false,
              SD_modal_status: false,
              showModal: false,
              DS_modal_msg: '',
              delete_modal_msg: '',
              arc_status: media_archive,
              fileType: this.props.fileType,
              base_url: media_base_url,
              optionset: nmk,  
              sorting: [],    
              selectedKit: "",
              //selectedItem: "",
              //sortKey: "",
            }
          },
          componentWillMount: function() {
            var t = this;
            var currstate = t.state.fileType;
            if(currstate == 'photo') {
              currstate = 'image';
            }
            this.serverRequest = axios.get(media_base_url+'/media/vault-sort/'+a+'/'+currstate+'?_format=json')
            .then(function(response) {
              return response.data;
            })
            .then(function(data) {
              t.setState({sorting: data});
            });
            document.addEventListener('keypress', t.filterkeyUp.bind());
          },      
          refresh: function() {
            var th = this;
            var curState = th.state.fileType;                       
            var spinner = '<div class="progress-overlay"><div class="spinner-border"</div></div>';                        
            switch (curState) {
              case 'audio':
                var rows = jQuery('table#audio_vault tbody tr');               
                if(jQuery('input[id="show-all-input-audio"]').is(":checked")) {
                  jQuery('#filter-audio').val('');                        
                  jQuery('#media_audio_list_wrapper').append(spinner);
                  jQuery('#filter-btn-audio').trigger('click');            
                  rows.each(function(event){
                    jQuery(this).find('span.move-icon').removeClass('d-none');
                  });
                  setTimeout(function() {
                    jQuery('#media_audio_list_wrapper').find('.progress-overlay').remove();
                  }, 500);
                } else {
                  rows.each(function(event){
                    jQuery(this).find('span.move-icon').removeClass('d-none');
                  });
                }
              break;              
              case 'photo':
                var rows = jQuery('table#photo_vault tbody tr');
                if(jQuery('input[id="show-all-input-photo"]').is(":checked")) {
                  jQuery('#filter-photo').val(''); 
                  jQuery('#media_photo_list_wrapper').append(spinner);
                  jQuery('#filter-btn-photo').trigger('click');            
                  rows.each(function(event){
                    jQuery(this).find('span.move-icon').removeClass('d-none');
                  });
                  setTimeout(function() {
                    jQuery('#media_photo_list_wrapper').find('.progress-overlay').remove();
                  }, 500);
                }else{
                  rows.each(function(event){
                    jQuery(this).find('span.move-icon').removeClass('d-none');
                  });
                }
              break;              
              case 'text':
                var rows = jQuery('table#text_vault tbody tr');
                if(jQuery('input[id="show-all-input-text"]').is(":checked")) {
                  jQuery('#filter-text').val(''); 
                  jQuery('#media_text_list_wrapper').append(spinner);
                  jQuery('#filter-btn-text').trigger('click');            
                  rows.each(function(event){
                    jQuery(this).find('span.move-icon').removeClass('d-none');
                  });
                  setTimeout(function() {
                    jQuery('#media_text_list_wrapper').find('.progress-overlay').remove();
                  }, 500);
                }else{
                  rows.each(function(event){
                    jQuery(this).find('span.move-icon').removeClass('d-none');
                  });
                }
              break;              
              case 'video':
                var rows = jQuery('table#video_vault tbody tr');
                if(jQuery('input[id="show-all-input-video"]').is(":checked")) {
                  jQuery('#filter-video').val(''); 
                  jQuery('#media_video_list_wrapper').append(spinner);
                  jQuery('#filter-btn-video').trigger('click');            
                  rows.each(function(event){
                    jQuery(this).find('span.move-icon').removeClass('d-none');
                  });
                  setTimeout(function() {
                    jQuery('#media_video_list_wrapper').find('.progress-overlay').remove();
                  }, 500);
                }else{
                  rows.each(function(event){
                    jQuery(this).find('span.move-icon').removeClass('d-none');
                  });
                }
              break;              
              default:
              break;
            }
          },          
          render: function() {
            var options = React.createElement('select',{className: 'text-uppercase pl-1 pr-1', value: this.state.selectedKit, onChange: this.addToMediaKit.bind() },
              React.createElement('option', {value: '0', style: {'display':'none'}}, 'Add to media Kit'),
              this.state.optionset.map((optionitem, key) => {
                return React.createElement('option', {value: optionitem.nid}, optionitem.title )
              })
            );
            /*var additional_options = '';
            if(this.state.fileType == 'audio'){
              var additional_options = [React.createElement('option', {value: 6}, 'SORT BY DURATION (A-Z)' ),
                React.createElement('option', {value: 7}, 'SORT BY DURATION (Z-A)' )];
            }
            if(this.state.fileType == 'photo'){
              var additional_options =  [React.createElement('option', {value: 8}, 'SORT BY PIXEL DIMENSIONS (A-Z)' ),
              React.createElement('option', {value: 9}, 'SORT BY PIXEL DIMENSIONS (Z-A)' )];
            }
            if(this.state.fileType == 'text'){
              var additional_options = [React.createElement('option', {value: 10}, 'SORT BY PAGES (A-Z)' ),
              React.createElement('option', {value: 11}, 'SORT BY PAGES (Z-A)' )];
            }
            if(this.state.fileType == 'video'){
              var additional_options = [React.createElement('option', {value: 6}, 'SORT BY DURATION (A-Z)' ),
              React.createElement('option', {value: 7}, 'SORT BY DURATION (Z-A)' ),
              React.createElement('option', {value: 8}, 'SORT BY PIXEL DIMENSIONS (A-Z)' ),
              React.createElement('option', {value: 9}, 'SORT BY PIXEL DIMENSIONS (Z-A)' )];
            }
            var sortbyoptions = React.createElement('select',{className: 'text-uppercase sortby-pulldown pl-1 pr-1', value: this.state.selectedItem, onChange: this.sortedItem.bind() }, 
            React.createElement('option', {value: 0}, 'SORT BY TITLE (A-Z)' ),
            React.createElement('option', {value: 1}, 'SORT BY TITLE (Z-A)' ),
            React.createElement('option', {value: 2}, 'SORT BY FILE NAME (A-Z)' ),
            React.createElement('option', {value: 3}, 'SORT BY FILE NAME (Z-A)' ),
            React.createElement('option', {value: 4}, 'SORT BY FORMAT (A-Z)' ),
            React.createElement('option', {value: 5}, 'SORT BY FORMAT (Z-A)' ),
            additional_options,
            React.createElement('option', {value: 12}, 'SORT BY FILE SIZE (A-Z)' ),
            React.createElement('option', {value: 13}, 'SORT BY FILE SIZE (Z-A)' ),
            React.createElement('option', {value: 14}, 'SORT BY FAVORED FIRST' ),
            React.createElement('option', {value: 15}, 'SORT BY FAVORED LAST' ),
            );*/
            if (this.state.SD_modal_status) {
              var SelectDownloadModalElement = React.createElement(Modal, {handleHideModal: this.dismissDSModal, handleArchive: this.DeleteSelected, fileType: this.props.fileType, base_url:this.state.base_url, delete_modal_msg: this.state.DS_modal_msg, arc_status: this.state.arc_status});
            }
            if(this.state.arc_status) {
              var deleteRestore_element = React.createElement('li', {className: 'border-right-0'}, React.createElement('span', {className: 'delete-selected arc_1 pl-3', onClick: this.ShowSelectDownloadModal.bind()}, 'Restore Selected'));
              var addTokit = '';
            } else {
              var deleteRestore_element = React.createElement('li', null, React.createElement('span', {className: 'delete-selected delete-icon pl-3', onClick: this.ShowSelectDownloadModal.bind()}, 'Archive Selected'));
              var addTokit = React.createElement('li', {className:'add-to-kit'},
                options
              );
            }
            return React.createElement('div', null,
              React.createElement('div', {className:'select-box-element row justify-content-between pl-3 pr-3'},
                React.createElement('div', {className: 'justify-content-start'},
                  React.createElement('ul', null,
                    React.createElement('li', null,
                      React.createElement('label', {className: 'checkbox-container'},
                        React.createElement('span', {className: 'desc'},'Select All'),
                        React.createElement('input',{type: 'checkbox', id: 'audio-check-' +this.props.fileType, className: 'box-check', 'data-filetype': this.props.fileType, defaultChecked: false, onClick: this.SelectAll.bind()}),
                        React.createElement('span', {className: 'checkmark'}),
                      )
                    ),
                    React.createElement('li', null,
                      React.createElement('span', {className: 'download-selected media-download pl-3', fileType: this.props.fileType, onClick: this.DownloadSelected.bind()}, 'Download Selected')
                    ),
                    //React.createElement('li', null,
                    deleteRestore_element,
                    //),
                    addTokit
                  )
                ),
                React.createElement('div', {className: 'justify-content-end'}, 
                  /*React.createElement('div', {className: 'justify-content-start mr-3'}, sortbyoptions ),*/
                  React.createElement('ul', null,
                    React.createElement('li', null,
                      React.createElement('label', {className: 'checkbox-container filterby', id: 'show-all-'+this.props.fileType},
                        React.createElement('span', {id: 'show-all-text'+this.props.fileType, className: 'desc text-uppercase ml-3 color-3b', style: {'padding-left': '6px'}}, 'Show All'),
                        React.createElement('input',{type: 'checkbox', id: 'show-all-input-'+this.props.fileType, className: 'box-check mr-1', 'data-filetype': this.props.fileType, defaultChecked: true, onClick: this.refresh.bind()}),
                        React.createElement('span', {className: 'checkmark'}),
                      )
                    ),
                    React.createElement('li', {className: 'border-right-0'},
                      React.createElement('input',{type: 'text', id: 'filter-'+this.props.fileType, className: 'filter pl-1', 'data-filetype': this.props.fileType, placeholder: 'FILTER BY TITLE', type: 'text', autoFocus: true, onkeyup: this.filterkeyUp.bind(this)/* , onkeydown: this.filterkeyDown.bind(this) */}),
                      React.createElement('button', {id: 'filter-btn-'+this.props.fileType, type: 'submit', className: 'btn btn-primary filter-btn text-uppercase align-baseline font-fjalla', onClick: this.FilterBy.bind()}, 'Apply')
                    ),
                    React.createElement('li', {style: {'border-left': '1px solid #99a7b3'}},  
                      React.createElement('a', {className: 'text-decoration-none', href:media_base_url+"/media/kit/"+a}, 'Media Kits')
                    ),
                    React.createElement('li', {id: this.props.archiveswitchid, className: 'pr-0'},
                      React.createElement('a', {className: 'text-decoration-none', href:this.props.archive_switch}, this.props.archive_text)
                    )
                  )
                ),
              ),
            SelectDownloadModalElement
            )
          },
          FilterBy: function() {
            //alert('test');
            var th = this;
            var curState = th.state.fileType;
            var sortingl = th.state.sorting.length;
            var rows = jQuery('table#'+curState+'_vault tbody tr');
            rows.each(function(event){
              jQuery(this).find('span.move-icon').addClass('d-none');
            });
            var rowsArr = jQuery('table#'+curState+'_vault tbody tr').toArray();
            rowsArr = th.sortByTitle(rows, curState, sortingl);
            for (var i = 0; i < rowsArr.length; i++) {
              jQuery('table#'+curState+'_vault tbody').append(rowsArr[i]);
            }
          },
          sortByTitle: function(rows, curState, sortinglength) {
            var filterText = jQuery('#filter-'+curState).val().toLowerCase();
            if(jQuery('#filter-'+curState).val().length >= 2 || jQuery('#filter-'+curState).val().length == 0){
              rows.filter(function(a, b) {
                jQuery(this).toggle(jQuery(this).children('td.media-title').text().toLowerCase().indexOf(filterText) > -1);
                var textA = jQuery(this).children('td.media-title', a).text();
                var textB = jQuery(this).children('td.media-title', b).text();
                if(sortinglength == 0) {
                  return textA.localeCompare(textB);  
                } else {
                  return rows;
                }              
              });
            } else if(jQuery('#filter-'+curState).val().length == 1){
              alert('Please enter at least 2 characters.');
            }

            return rows;
          },
/*           filterkeyDown: function(e) {
            var curState = this.state.fileType;
            var ftext = e.target.value;
            switch (curState) {
              case 'audio':
              if(e.target.id == 'filter-audio'){
                jQuery('#show-all-input-audio').prop("checked", true);
                jQuery('#show-all-text-audio').removeClass("color-60");
                jQuery('#show-all-text-audio').addClass("color-3b");
              }
              break;
              case 'photo':
                if(e.target.id == 'filter-photo'){
                  jQuery('#show-all-input-photo').prop("checked", true);
                  jQuery('#show-all-text-photo').removeClass("color-60");
                  jQuery('#show-all-text-photo').addClass("color-3b");
                }
              break;
              case 'text':
                if(e.target.id == 'filter-text'){
                  jQuery('#show-all-input-text').prop("checked", true);
                  jQuery('#show-all-text-text').removeClass("color-60");
                  jQuery('#show-all-text-text').addClass("color-3b");
                }
              break;
              case 'video':
                if(e.target.id == 'filter-video'){
                  jQuery('#show-all-input-video').prop("checked", true);
                  jQuery('#show-all-text-video').removeClass("color-60");
                  jQuery('#show-all-text-video').addClass("color-3b");
                }
              default:
              break;              
            }
          }, */
          filterkeyUp: function(e) {
            var curState = this.state.fileType;
            var ftext = e.target.value;
            switch (curState) {
              case 'audio':
              if(e.target.id == 'filter-audio'){
                jQuery('#show-all-input-audio').prop("checked", false);
                jQuery('#show-all-text-audio').removeClass("color-3b");
                jQuery('#show-all-text-audio').addClass("color-60");
              }
              break;
              case 'photo':
                if(e.target.id == 'filter-photo'){
                  jQuery('#show-all-input-photo').prop("checked", false);
                  jQuery('#show-all-text-photo').removeClass("color-3b");
                  jQuery('#show-all-text-photo').addClass("color-60");
                }
              break;
              case 'text':
                if(e.target.id == 'filter-text'){
                  jQuery('#show-all-input-text').prop("checked", false);
                  jQuery('#show-all-text-text').removeClass("color-3b");
                  jQuery('#show-all-text-text').addClass("color-60");
                }
              break;
              case 'video':
                if(e.target.id == 'filter-video'){
                  jQuery('#show-all-input-video').prop("checked", false);
                  jQuery('#show-all-text-video').removeClass("color-3b");
                  jQuery('#show-all-text-video').addClass("color-60");
                }
              default:
              break;              
            }           
          },
          /*sortedItem: function(e) {
            var th = this;
            e.preventDefault();
            var curState = this.state.fileType;            
            var curVal = e.target.value;            
            this.setState({selectedItem: curVal}); 
            var rows = jQuery('table#'+curState+'_vault tbody tr').toArray();
            switch (curVal) {
              case '0':
                rows = th.sortByText(rows, '.media-title', true, curVal);
                break;
              case '1':
                rows = th.sortByText(rows, '.media-title', false, curVal);
                break;
              case '2':
                rows = th.sortByText(rows, '.media-f-name', true, curVal);
                break;
              case '3':
                rows = th.sortByText(rows, '.media-f-name', false, curVal);
                break;
              case '4':
                rows = th.sortByText(rows, '.media-format', true, curVal);
                break;
              case '5':
                rows = th.sortByText(rows, '.media-format', false, curVal);
                break;
              case '6':
                rows = th.sortByText(rows, '.media-duration', true, curVal);
                break;
              case '7':
                rows = th.sortByText(rows, '.media-duration', false, curVal);
                break;
              case '8':
                rows = th.sortByText(rows, '.media-dimension', true, curVal);
                break;
              case '9':
                rows = th.sortByText(rows, '.media-dimension', false, curVal);
                break;
              case '10':
                rows = th.sortByText(rows, '.media-pages', true, curVal);
                break;
              case '11':
                rows = th.sortByText(rows, '.media-pages', false, curVal);
                break;
              case '12':
                rows = th.sortByText(rows, '.media-f-size', true, curVal);
                break;
              case '13':
                rows = th.sortByText(rows, '.media-f-size', false, curVal);
                break;
              case '14':
                rows = th.sortByText(rows, '.media-fav', true, curVal);
                break;
              case '15':
                rows = th.sortByText(rows, '.media-fav', false, curVal);
                break;              
              default:
                console.error('Undefined sort field ' + curVal);
                break;
            }
            
            for (var i = 0; i < rows.length; i++) {
              jQuery('table#'+curState+'_vault tbody').append(rows[i]);
            }
          },
          sortByText: function(rows, selector, ascending, value) {
            var curState = this.state.fileType;
            rows.sort(function(a, b) {
              var textA = jQuery('td'+selector, a).text();
              var textB = jQuery('td'+selector, b).text();
              if(value == 14 || value == 15){
                textA = jQuery('td.media-title', a).text();
                textB = jQuery('td.media-title', b).text();
              }
              if (ascending) {                
                jQuery('.media-table th span').removeClass();
                jQuery('table#'+curState+'_vault td').removeClass('sorted');
                jQuery('table#'+curState+'_vault th'+selector+' span').addClass("desc-icon");
                jQuery('table#'+curState+'_vault td'+selector).addClass('sorted');
                return textA.localeCompare(textB);
              } else {
                jQuery('.media-table th span').removeClass();
                jQuery('table#'+curState+'_vault td').removeClass('sorted');
                jQuery('table#'+curState+'_vault th'+selector+' span').addClass("asc-icon");
                jQuery('table#'+curState+'_vault td'+selector).addClass('sorted');
                return textB.localeCompare(textA);
              }
            });

            return rows;
          }, */
          ShowSelectDownloadModal: function(){
            var msg =React.createElement("div", null, "This action will remove selected media file from your ", React.createElement("b", null, "Media Vault"), " and move it to your ", React.createElement("b", null, "Media Archive"), ". It will not be available for use while archived. You will be able to recover it later, if needed.");
            if(this.state.arc_status){
             msg = React.createElement('div', null, 'This action will restore selected file to your Media Vault and any previously selected uses.');
            }
            this.setState({SD_modal_status: true});
            this.setState({DS_modal_msg: msg});
          },                                        
          dismissDSModal: function(){
            this.setState({SD_modal_status: false});
            this.setState({DS_modal_msg: ''});
          },
          SelectAll: function(e){
            var mediatype = this.state.fileType;
            jQuery(this.props.box+' .checkbox-container input[type="checkbox"]').prop('checked',!this.state.checked_status);
            this.setState({checked_status: !this.state.checked_status});           
            if(!this.state.checked_status){
              jQuery('#'+this.state.fileType+'-select-box-element-wrapper').removeClass('options-disable'); 
              var clickedMedia = jQuery('#audio-check-'+this.state.fileType).attr("data-filetype");
              var checkedAll_audio = jQuery('#media_audio_list_wrapper .checkbox-container input[type="checkbox"]');
              var checkedAll_photo = jQuery('#media_photo_list_wrapper .checkbox-container input[type="checkbox"]');
              var checkedAll_text = jQuery('#media_text_list_wrapper .checkbox-container input[type="checkbox"]');
              var checkedAll_video = jQuery('#media_video_list_wrapper .checkbox-container input[type="checkbox"]');   
              var checkedList_audio = jQuery(checkedAll_audio).map(function() {
                    return this.attributes.getNamedItem("data-mid").value;
                  }).get();
              var checkedList_photo = jQuery(checkedAll_photo).map(function() {
                    return this.attributes.getNamedItem("data-mid").value;
                  }).get();
              var checkedList_text = jQuery(checkedAll_text).map(function() {
                    return this.attributes.getNamedItem("data-mid").value;
                  }).get();
              var checkedList_video = jQuery(checkedAll_video).map(function() {
                    return this.attributes.getNamedItem("data-mid").value;
                  }).get();
                  
              if(clickedMedia == 'audio' || this.props.singlecheckAudio == true) {
                if(checkedList_audio != '') {            
                  checkedList_audio.map((item, key) => {
                    selectedRows_audio.push(+item);              
                  });            
                }
                selectedRows_audio = selectedRows_audio.filter((val, id, array) => {
                  return array.indexOf(val) == id;  
                });
              } 
              if(clickedMedia == 'photo' || this.props.singlecheckPhoto == true) {
                if(checkedList_photo != '') {            
                  checkedList_photo.map((item, key) => {
                    selectedRows_photo.push(+item);              
                  });            
                }
                selectedRows_photo = selectedRows_photo.filter((val, id, array) => {
                  return array.indexOf(val) == id;  
                });
              }
              if(clickedMedia == 'text' || this.props.singlecheckText == true) {
                if(checkedList_text != '') {            
                  checkedList_text.map((item, key) => {
                    selectedRows_text.push(+item);              
                  });            
                }
                selectedRows_text = selectedRows_text.filter((val, id, array) => {
                  return array.indexOf(val) == id;  
                });               
              }
              if(clickedMedia == 'video' || this.props.singlecheckVideo == true) {
                if(checkedList_video != '') {            
                  checkedList_video.map((item, key) => {
                    selectedRows_video.push(+item);              
                  });            
                }
                selectedRows_video = selectedRows_video.filter((val, id, array) => {
                  return array.indexOf(val) == id;  
                });
              }                            
            }else{
              selectedRows_audio = [];
              selectedRows_photo = [];
              selectedRows_text = [];
              selectedRows_video = [];
              jQuery('#'+this.state.fileType+'-select-box-element-wrapper').addClass('options-disable');           
            }                        
          },
          DownloadSelected: function(){
            var t = this;  
            if(t.state.fileType == 'audio'){
              selectedRows_photo = [];
              selectedRows_text = [];
              selectedRows_video = []; 
              selectedRows_audio.map((item, key) => {
                axios.get(media_base_url+'/media/'+item+'/edit?_format=json')
                .then(function(result) {
                  if(result.status == 200){
                    var theAnchorAudio = jQuery('<a />').attr('href', result.data.field_media_audio_file[0].url).attr('download','').appendTo('body');  
                    theAnchorAudio[0].click();                   
                    theAnchorAudio.remove();
                    window.location.reload();
                  }else{
                    alert('Error');
                  }
                });
              });
              selectedRows_audio = [];
            }  
            if(t.state.fileType == 'photo'){
              selectedRows_audio = [];
              selectedRows_text = [];
              selectedRows_video = [];
              selectedRows_photo.map((item, key) => {
                axios.get(media_base_url+'/media/'+item+'/edit?_format=json')
                .then(function(result) {
                  if(result.status == 200){
                    var theAnchorPhoto = jQuery('<a />').attr('href', result.data.field_media_image[0].url).attr('download','').appendTo('body');
                    theAnchorPhoto[0].click();                   
                    theAnchorPhoto.remove();
                    window.location.reload();
                  }else{
                    alert('Error');
                  }
                });
              });
              selectedRows_photo = [];
            } 
            if(t.state.fileType == 'text'){
              selectedRows_audio = [];
              selectedRows_photo = [];
              selectedRows_video = []; 
              selectedRows_text.map((item, key) => {
                axios.get(media_base_url+'/media/'+item+'/edit?_format=json')
                .then(function(result) {
                  if(result.status == 200){                                      
                    var theAnchorText = jQuery('<a />').attr('href', result.data.field_media_file[0].url).attr('download','').attr('target', '_blank').appendTo('body');  
                    theAnchorText[0].click();                   
                    theAnchorText.remove();
                    setTimeout(location.reload.bind(location), 10000);
                  }else{
                    alert('Error');
                  }
                });
              });
              selectedRows_text = [];
            }
            if(t.state.fileType == 'video'){
              selectedRows_audio = [];
              selectedRows_photo = [];
              selectedRows_text = [];
              selectedRows_video.map((item, key) => {
                axios.get(media_base_url+'/media/'+item+'/edit?_format=json')
                .then(function(result) {
                  if(result.status == 200){
                    var theAnchorVideo = jQuery('<a />').attr('href', result.data.field_media_video_file[0].url).attr('download','').appendTo('body');  
                    theAnchorVideo[0].click();                   
                    theAnchorVideo.remove();
                    window.location.reload();
                  }else{
                    alert('Error');
                  }
                });
              });
              selectedRows_video = [];
            } 
          },
          DeleteSelected: function(){
            var t = this;
            axios.get(Drupal.url('rest/session/token'))
            .then(function (data) {
              var csrfToken = data.data;
              let headers = {'Content-Type': 'application/hal+json','Cache-Control': 'no-cache', 'X-CSRF-Token':csrfToken,};
              var media_type = t.state.fileType;
              if(t.state.fileType === 'photo'){
                media_type = 'image';
              }
              var type_url = t.state.base_url + '/rest/type/media/'+media_type+'';
              var hal_json_archive = {
                "_links": {
                  "type": {"href": type_url }
                },
                "field_archived": [
                  {
                    "value": Boolean(!media_archive)
                  }
                ]
              };
              switch (t.state.fileType) {
                case 'audio':
                  selectedRows_photo = [];
                  selectedRows_text = [];
                  selectedRows_video = []; 
                  return selectedRows_audio.map((item, key) => {
                    axios.patch(t.state.base_url+'/media/'+item+'/edit?_format=hal_json', hal_json_archive, { headers: headers })
                    .then(function(result) {
                      if(result.status == 200){
                        window.location.reload();
                      }else{
                        alert('Error');
                      }
                    });
                  });
                  selectedRows_audio = [];
                break;  
                case 'photo':
                  selectedRows_audio = [];
                  selectedRows_text = [];
                  selectedRows_video = [];
                  return selectedRows_photo.map((item, key) => {
                    axios.patch(t.state.base_url+'/media/'+item+'/edit?_format=hal_json', hal_json_archive, { headers: headers })
                    .then(function(result) {
                      if(result.status == 200){
                        window.location.reload();
                      }else{
                        alert('Error');
                      }
                    });
                  });
                  selectedRows_photo = [];
                break;  
                case 'text':
                  selectedRows_audio = [];
                  selectedRows_photo = [];
                  selectedRows_video = [];
                  return selectedRows_text.map((item, key) => {
                    axios.patch(t.state.base_url+'/media/'+item+'/edit?_format=hal_json', hal_json_archive, { headers: headers })
                    .then(function(result) {
                      if(result.status == 200){
                        window.location.reload();
                      }else{
                        alert('Error');
                      }
                    });
                  });
                  selectedRows_text = [];
                break;  
                case 'video':
                  selectedRows_audio = [];
                  selectedRows_photo = [];
                  selectedRows_text = [];
                  return selectedRows_video.map((item, key) => {
                    axios.patch(t.state.base_url+'/media/'+item+'/edit?_format=hal_json', hal_json_archive, { headers: headers })
                    .then(function(result) {
                      if(result.status == 200){
                        window.location.reload();
                      }else{
                        alert('Error');
                      }
                    });
                  });
                  selectedRows_video = [];
                break;  
                default:
                  selectedRows_audio = [];
                  selectedRows_photo = [];
                  selectedRows_text = [];
                  selectedRows_video = [];
              }
              jQuery('#modal').modal('hide');
              t.setState({showModal: false});
              t.setState({fileType: ''});
              t.setState({SD_modal_status: false});
              t.setState({DS_modal_msg: ''});
              t.setState({delete_modal_msg: ''});
            });
          },
          addToMediaKit: function(e){
            e.preventDefault();
            var th = this;
            var media_kit_id = e.target.value;             
            var mtype = th.state.fileType;
            var spinner = '<div class="progress-overlay"><div class="spinner-border"</div></div>';
            jQuery('#media_'+mtype+'_list_wrapper').append(spinner);
            var data_string = '';
            var selectedData = [];
            var existingData = [];
            var final_data = [];
            th.setState({selectedKit: media_kit_id});            
            jQuery('#'+mtype+'_vault tbody tr input:checkbox').each(function (event) {
              if (jQuery(this).is(':checked')) {
                selectedData.push(jQuery(this).attr('data-mid'));           
              }
            });
            
            this.serverRequest = axios.get(media_base_url+'/node/'+media_kit_id+'?_format=json')
              .then(function(response) {
                if(mtype == 'audio'){
                  return response.data.field_vault_audio;
                }
                if(mtype == 'photo'){
                  return response.data.field_vault_photo;
                }
                if(mtype == 'text'){
                  return response.data.field_vault_file;
                }
                if(mtype == 'video'){
                  return response.data.field_vault_video;
                }
              })
              .then(function(data) {
                return Promise.all(data.map( (record, index) => {
                  return record.target_id;
                }))
              })
              .then(function(responsex) {                                 
                existingData.push(responsex);
                var merge_data = existingData[0].concat(selectedData); 
                
                //remove duplicate data
                final_data = [...new Set(merge_data)];
                
                if(final_data.length > 0) {
                  jQuery.each( final_data, function( key, value ) {
                    data_string += '{"target_id":'+value+'},';                 
                  }); 
                  
                  //remove last comma
                  data_string = data_string.slice(0, -1);
                  data_string = '['+data_string+']';
                  console.log(data_string);
                  
                  //convert string to JSON data
                  jsondata = JSON.parse(data_string);
                  console.log(jsondata);
                  
                  //update node audio field array as per sort order
                  axios.get(Drupal.url('rest/session/token'))
                  .then(function (data) {
                    var csrfToken = data.data;
                    let headers = {'Content-Type': 'application/hal+json','Cache-Control': 'no-cache', 'X-CSRF-Token':csrfToken,};
                    var node_url_json = media_base_url+"/node/"+media_kit_id+'?_format=hal_json';
                    var type_url = media_base_url+'/rest/type/node/media_kit';
                    var media_field = {
                      "_links": {
                        "type": {"href": type_url }
                      }
                    };                    
                    //create dynamic key for media field type
                    if(mtype == 'text'){
                      reference_field = "field_vault_file";
                    } else{
                      reference_field = "field_vault_"+mtype;
                    }
                    media_field[reference_field] = jsondata;
                    var myArray = [];
                    myArray.push(media_field);
                    console.log(media_field);
                    console.log(myArray);
                    axios.patch(node_url_json, myArray[0], { headers: headers })
                    .then(function(resultdata) {
                      window.location.reload();
                      /* jQuery('#'+mtype+'-refresh').trigger('click');
                      jQuery('#'+mtype+'_vault tbody tr input:checkbox').each(function (event) {
                        jQuery(this).prop("checked", false);
                      });
                      jQuery('.select-box-element select').prop('selectedIndex',0); */
                      /* setTimeout(function() {
                        jQuery("#"+mtype+"-refresh").trigger('click');
                      }, 1000); */
                    })
                  });  
                }
            });
          }
        });

        //**************************App components for media tabs.*****************************************//
        //Audio files
        var url = media_base_url+"/node/"+media_vault_id+"?_format=json";
        
        var AppAudio = React.createClass({
          getInitialState: function() {
            return {
              audios: [],
              value: [],              
              showModal: false,
              singlecheckAudio: false,
              fileType: '',
              mid: '',
              base_url: media_base_url,
              marked_check: false,
              row_id: '',
              delete_modal_msg: '',
              arc_icon_class: 'arc_'+media_archive,
              arc_status: media_archive,
              spinner_status: false,
              sorting: [],
              wrapperID: '#media_audio_list_wrapper',
            }
          },
          componentWillMount: function() {
            var th = this;            
            this.serverRequest = axios.get(media_base_url+'/media/vault-sort/'+a+'/audio?_format=json')
            .then(function(response) {
              return response.data;
            })
            .then(function(data) {
              th.setState({sorting: data});
            });                    
              
            this.serverRequest =
              axios.get(url)
                .then(function(result) {
                  return result.data.field_vault_audio;
                })
                .then(function(response) {
                  return Promise.all(response.map( (record, index) => {    
                    return axios.get(media_base_url+'/media/'+record.target_id+'/edit?_format=json');
                  }))
                })
                .then(function(responsex) {                                 
                  th.setState({audios: responsex});
                }); 
          },
          componentWillUnmount: function() {
            this.serverRequest.abort();
          },
          UpdateMethod: function() {
            //Force a render with a simulated state change
            var th = this;
              this.serverRequest = 
                axios.get(url)
                .then(function(result) { 
                  return result.data.field_vault_audio;                   
                })
                .then(function(response) {
                   return Promise.all(response.map( (record, index) => {
                     return axios.get(media_base_url+'/media/'+record.target_id+'/edit?_format=json');
                   }))
                })
                .then(function(responsex) {
                  th.setState({audios: responsex}); 
                  th.setState({spinner_status: false});
                  jQuery('#media_audio_list_wrapper').find('.progress-overlay').remove();                  
                });             
          },          
          render: function() {
            var counter = 0;
            var archive_switch;
            var archiveswitchid;
            if(Boolean(media_archive)){
              archive_text = 'Media Vault';
            }else{
              archive_text = 'View Archive';
            }
            if (this.state.showModal) {
              var modalElement = React.createElement(Modal, {handleHideModal: this.handleHideModal, handleArchive: this.handleArchiveAudio, fileType: this.state.fileType, mid:this.state.mid, base_url:this.state.base_url, delete_modal_msg: this.state.delete_modal_msg, arc_status: this.state.arc_status});
            }
            if(this.state.spinner_status){
              var spinner_process = React.createElement('div', {className:'progress-overlay'}, React.createElement('div', {className:'spinner-border'}, null));
            }
            if(this.state.sorting.length == 0){
              this.state.audios.sort((a, b) => a.data.name[0].value.localeCompare(b.data.name[0].value));
            }
            var items = this.state.audios.map((item, key) => {
              
              if(item.data.field_archived[0].value == Boolean(media_archive)){
                counter += 1;
                //for created Date
                let current_datetime = new Date(item.data.created[0].value)
                var h = current_datetime.getHours();
                var meridian = 'AM';
                if( h > 12){
                 h = h - 12 ;
                 meridian = 'PM';
                }
                var min = current_datetime.getMinutes();
                if(min < 10){
                 min = '0'+min;
                }
                let formatted_date =  (current_datetime.getMonth() + 1) + "/" +current_datetime.getDate()+ "/" + current_datetime.getFullYear() +", "+ h + ":" + min+' '+meridian;
                
                //File type
                let app_extention = React.createElement(AppExtention, {base_url:this.state.base_url, fid: item.data.field_media_audio_file[0].target_id, get_type_col: false});
                
                //Audio Time
                if((item.data.field_duration).length > 0){
                  var audio_time = item.data.field_duration[0].value;
                } else {
                  var audio_time = '-';//React.createElement(AudioTime, {audioURL: item.data.field_media_audio_file[0].url}); 
                }                  
                              
                //File size
                if((item.data.field_file_size).length > 0){
                  var file_size = item.data.field_file_size[0].value;
                } else {
                  var file_size = React.createElement(AppFileSize, {base_url:this.state.base_url, fid: item.data.field_media_audio_file[0].target_id});
                }
                
                let file_name = React.createElement(AppFileName, {base_url:this.state.base_url, fid: item.data.field_media_audio_file[0].target_id});
                //for Rating
                var rateDate = '-';
                var rateDateAlign = 'text-center';
                if(item.data.field_rating.length){
                  rate = item.data.field_rating[0].url;
                  rateDate = React.createElement(AppTaxo, {base_url:this.state.base_url, srate: rate});
                  rateDateAlign = '';
                }
                //for Sample rating
                var srateDate = '-';
                var srateDateAlign = 'text-center';
                if(item.data.field_sample_rate.length){
                 srate = item.data.field_sample_rate[0].url;
                 srateDate = React.createElement(AppTaxo, {base_url:this.state.base_url, srate: srate});
                 srateDateAlign = '';
                }
                //for keyword
                var keywords_values = ['-'];
                var keyword_center = 'text-center';
                if(item.data.field_keywords.length){
                  keyword_center = '';
                  var keywords = item.data.field_keywords.map((kitem, kkey) => {
                        keywords_values[kkey] = React.createElement(AppTaxo, {base_url:this.state.base_url, srate: kitem.url});
                  });
                }
                //for favorite
                var favorite_inactive = 'inactive';
                if(Boolean(item.data.field_favorite[0].value)){
                  favorite_inactive = '';
                }
                
                let mkit_elem = React.createElement(AppMediaKits, {base_url:this.state.base_url, mid: item.data.mid[0].value, fileType: 'audio'});
                
                return React.createElement('tr', {'data-id': key, 'data-mtype': item.data.bundle[0].target_id, 'data-nid': media_vault_id, 'data-mid': item.data.mid[0].value, id: 'item-audio-'+key, className: 'audio-row ui-state-default'},
                      React.createElement('td', {className: 'audio-data text-center'},
                        React.createElement('span', {className: 'move-icon'}),
                        React.createElement('label', {className: 'checkbox-container'},
                          React.createElement('input',{type: 'checkbox', id: 'audio-check-'+key, className: 'box-check', 'data-mid': item.data.mid[0].value, defaultChecked: false, onChange: this.switch_operation_action.bind()}),
                          React.createElement('span', {className: 'checkmark'}),
                        )
                      ),
                      React.createElement('td', {className: 'audio-data text-center media-data-icon'},
                        React.createElement('div', {className: 'audio-box'},
                          React.createElement("audio", {id: 'audio-'+key, controls:"controls", style:{'width': '0px', 'height': '0px', 'visibility':'hidden'}}, 
                            React.createElement('source', {src:item.data.field_media_audio_file[0].url},'')
                          ),
                          React.createElement('button', {type: 'button', className: 'audio-play-button', onClick: this.playAudio.bind(null, this, 'audio-'+key, 'volCol-'+key)},''),
                          React.createElement('div', {className:'vol-box'},
                            React.createElement('div', {className:'vol-box-inner'},
                              React.createElement('input', {type: 'range', id:'volCol-'+key, className: 'volume-control', min: 0, max: 1, step: 0.1, value: this.state.value, onChange: this.kbVolControl.bind(null, this, 'audio-'+key, 'volCol-'+key)}),
                              React.createElement('i', {className:'fa fa-volume-up', onClick: this.kbmute.bind(null, this, 'audio-'+key, 'volCol-'+key)},'')
                            )
                          )
                        ),
                      ),
                      React.createElement('td', {className: 'audio-data media-title'}, item.data.name[0].value, mkit_elem),
                      React.createElement('td', {className: 'audio-data media-f-name'}, file_name),
                      React.createElement('td', {className: 'audio-data media-format'}, app_extention),
                      React.createElement('td', {className: 'audio-data media-duration'}, audio_time),
                      React.createElement('td', {className: 'audio-data media-f-size'}, file_size),
                      React.createElement('td', {className: 'audio-data media-fav'},
                        React.createElement('ul', {},
                          React.createElement('li', {},
                            React.createElement('a', {href:'/media/'+item.data.mid[0].value+'/edit', className: 'audio-edit audio-round-button'}, ''),
                          ),
                          React.createElement('li', {},
                            React.createElement('button', {type: 'button', className: 'audio-favo audio-round-button '+favorite_inactive, onClick: this.handleFavoriteAudio.bind(null, item.data.mid[0].value, item.data.field_favorite[0].value, key)}, '')
                          ),
                          React.createElement('li', {},
                            React.createElement('a', {href:item.data.field_media_audio_file[0].url, download:'', className: 'audio-download audio-round-button'}, ''), 
                          ),
                          React.createElement('li', {},
                            React.createElement('button', {type: 'button', className: this.state.arc_icon_class+' audio-round-button', onClick: this.Showmodal.bind(null, item.data.bundle[0].target_id, item.data.mid[0].value, key)}, '')
                          )
                        ),
                      ),
                )
              }else if(media_archive){
                archive_switch = '/media/vault/'+a+window.location.hash;
                archiveswitchid = 'archiveswitch';
              }else{
                archive_switch = '/media/archive/'+a+window.location.hash;
                archiveswitchid = 'archiveswitch';
              }
            });
            var table_head = React.createElement('thead',{},
              React.createElement('tr', null,
                React.createElement('th', null, ),
                React.createElement('th', null, ),
                React.createElement('th', {className: 'media-title', style:{'width':'36%'}},
                  React.createElement('span', null, 'Title')),
                React.createElement('th', {className: 'media-f-name', style:{'width':'20%'}},
                  React.createElement('span', null, 'File Name')),
                React.createElement('th', {className: 'media-format'},
                  React.createElement('span', null, 'Format')),
                React.createElement('th', {className: 'media-duration'},
                  React.createElement('span', null, 'Duration')),
                React.createElement('th', {className: 'media-f-size'},
                  React.createElement('span', null, 'File Size')),
                React.createElement('th', {className: 'text-center media-fav'}, React.createElement('span', null, 'ACTIONS')),
              )
            );
            var table_data = React.createElement('table',{id: 'audio_vault', className: 'media-table mt-0'},table_head, React.createElement('tbody', {className: ''}, items));
            React.render(
              React.createElement(SelectDownload, {box: '#media_audio_list_wrapper', fileType: 'audio', singlecheckAudio: this.state.singlecheckAudio, archiveswitchid: archiveswitchid, archive_switch, archive_switch: archive_switch, archive_text: archive_text, nmk: nmk}),document.querySelector("#audio-select-box-element-wrapper"));
            if(media_archive == 0){  
              var audiomsg =React.createElement("span", null, "Drag audio here to upload.", React.createElement("br", null, "Acceptable file types include: aiff, mp3, and wav."));
              React.render(React.createElement(FileUploader,{dragmsg: audiomsg, fileType:'audio', extensions : 'aiff,mp3,wav'}), document.querySelector("#media-uploader-box-audio"));
            }
            var updatediv = React.createElement('div', {className: 'd-none', id: 'audio-refresh', onClick: this.UpdateMethod.bind()}, 'refresh');
            
            return ( React.createElement("div", {id: "media_audio_list_wrapper", className: 'row m-0 table-responsive'}, table_data, modalElement, spinner_process, updatediv) );
          },
          playAudio: function(appInstance, id, idcontrol) {
            //Pause all audio
            var kbAudio = document.getElementById(id);
            var audios = document.getElementsByTagName('audio');
            var sound = document.getElementById(idcontrol);
            kbAudio.volume = 1;
            jQuery(sound).css('background-image',
              '-webkit-gradient(linear, left top, right top, '
              + 'color-stop(' + kbAudio.volume + ', #fe5819), '
              + 'color-stop(' + kbAudio.volume + ', #ccc)'
              + ')'
            );
            appInstance.setState({value: 1})
            for(var i = 0, len = audios.length; i < len;i++){
              if(audios[i] != kbAudio){
                audios[i].pause();
                jQuery(audios[i]).parent().removeClass('playing');
                jQuery(audios[i]).parent().addClass('pause');
              }else if (kbAudio.duration > 0 && !kbAudio.paused) {
                kbAudio.pause();
               jQuery(audios[i]).parent().removeClass('playing');
               jQuery(audios[i]).parent().addClass('pause');
              }else if( kbAudio.duration > 0 && kbAudio.paused ) {
                kbAudio.play();
                jQuery(audios[i]).parent().removeClass('pause');
                jQuery(audios[i]).parent().addClass('playing');
              }
            }
          },
          kbVolControl: function(appInstance, idaudio, idcontrol) {
            var sound = document.getElementById(idcontrol);
            document.getElementById(idaudio).volume = sound.value;
            appInstance.setState({value: sound.value})
            jQuery(sound).css('background-image',
              '-webkit-gradient(linear, left top, right top, '
              + 'color-stop(' + sound.value + ', #fe5819), '
              + 'color-stop(' + sound.value + ', #ccc)'
              + ')'
            );
          },
          kbmute: function(appInstance, idaudio, idcontrol){
            var mutedVol = 0;
            var kbAudio = document.getElementById(idaudio);
            var sound = document.getElementById(idcontrol);
            kbAudio.muted = !kbAudio.muted;
            if(!kbAudio.muted){
              appInstance.setState({value: kbAudio.volume});
              jQuery(sound).css('background-image',
                '-webkit-gradient(linear, left top, right top, '
                + 'color-stop(' + kbAudio.volume + ', #fe5819), '
                + 'color-stop(' + kbAudio.volume + ', #ccc)'
                + ')'
              );
            }else{
              appInstance.setState({value: mutedVol});
              jQuery(sound).css('background-image',
                '-webkit-gradient(linear, left top, right top, '
                + 'color-stop('+ mutedVol +', #fe5819), '
                + 'color-stop('+ mutedVol +', #ccc)'
                + ')'
              );
            }
          },
          Showmodal: function(fileType, mid, row_id){
            var msg =React.createElement("div", null, "This action will remove this media file from your ", React.createElement("b", null, "Media Vault"), " and move it to your ", React.createElement("b", null, "Media Archive"), ". It will not be available for use while archived. You will be able to recover it later, if needed.");
            if(this.state.arc_status){
             msg = React.createElement('div', null, 'This action will restore this file to your Media Vault and any previously selected uses.');
            }
            this.setState({showModal: true});
            this.setState({fileType: fileType});
            this.setState({mid: mid});
            this.setState({row_id: row_id});
            this.setState({delete_modal_msg: msg});
          },
          handleHideModal: function(){
           this.setState({showModal: false});
           this.setState({mid: ''});
           this.setState({row_id: ''});
           this.setState({delete_modal_msg: ''});
          },
          handleArchiveAudio: function(){
            var t = this;
            axios.get(Drupal.url('rest/session/token'))
            .then(function (data) {
              var csrfToken = data.data;
              let headers = {'Content-Type': 'application/hal+json','Cache-Control': 'no-cache', 'X-CSRF-Token':csrfToken,};
              var media_url_hal_json = t.state.base_url+'/media/'+ t.state.mid+'/edit?_format=hal_json';
              var type_url = t.state.base_url + '/rest/type/media/audio';
              var audio_hal_json_archive = {
                "_links": {
                  "type": {"href": type_url }
                },
                "field_archived": [
                  {
                    "value": Boolean(!media_archive)
                  }
                ]
              };
              axios.patch(media_url_hal_json, audio_hal_json_archive, { headers: headers })
              .then(function(result) {
                if(result.status == 200){
                  t.setState({spinner_status: true});
                  jQuery("#audio-refresh").trigger('click');
                }else{
                  alert('Error');
                }
              });
              jQuery('#modal').modal('hide');
              t.setState({showModal: false});
              t.setState({mid: ''});
              t.setState({row_id: ''});
              t.setState({delete_modal_msg: ''});
            });
          },
          handleFavoriteAudio: function(mid, field_favorite_value, row_id){
            this.setState({spinner_status: true});
            var t =this;
            var favorite_row = Number(row_id);
            axios.get(Drupal.url('rest/session/token'))
            .then(function (data) {
              var csrfToken = data.data;
              let headers = {'Content-Type': 'application/hal+json','Cache-Control': 'no-cache', 'X-CSRF-Token':csrfToken,};
              var media_url_hal_json = t.state.base_url+'/media/'+mid+'/edit?_format=hal_json';
              var type_url = t.state.base_url + '/rest/type/media/audio';
              var audio_hal_json_favorite = {
                "_links": {
                  "type": {"href": type_url }
                },
                "field_favorite": [
                  {
                    "value": Boolean(!field_favorite_value)
                  }
                ]
              };
              axios.patch(media_url_hal_json, audio_hal_json_favorite, { headers: headers })
              .then(function(result) {
                if(result.status == 200){
                  let new_list = t.state.audios;
                  new_list[favorite_row].data.field_favorite[0].value = Boolean(!field_favorite_value);
                  t.setState({audios: new_list});
                  t.setState({spinner_status: false});
                }else{
                  alert('Error');
                }
              });
              t.setState({mid: ''});
            });
          },
           switch_operation_action: function(e){
            this.setState({singlecheckAudio: true});
            if (e.target.checked) {
              selectedRows_audio.push(+e.target.attributes.getNamedItem("data-mid").value);
            } else {
              let index = selectedRows_audio.indexOf(+e.target.attributes.getNamedItem("data-mid").value);
              selectedRows_audio.splice(index, 1);
            }
            var data = jQuery(this.state.wrapperID+' .checkbox-container input[type="checkbox"]:checked').map(function() {
                        return e.target.value;
                      }).get();
            if(data == ''){
              jQuery('#audio-select-box-element-wrapper').addClass('options-disable');
            }
            else {
              jQuery('#audio-select-box-element-wrapper').removeClass('options-disable');
            }
           }
        });

        React.render(
          React.createElement(AppAudio, 'div',{className:'x2'}), document.querySelector("#nav-master-audio-detail"));
        
        //Photo Detail
        var AppPhoto = React.createClass({
          getInitialState: function() {
            return {
              photos: [],
              sorting: [],
              photosData: [],
              photosStyle: [],
              showModal: false,
              singlecheckPhoto: false,
              refereshCom: false,
              fileType: '',
              mid: '',
              base_url: media_base_url,
              row_id: '',
              delete_modal_msg: '',
              arc_icon_class: 'arc_'+media_archive,
              arc_status: media_archive,
              spinner_status: false,
              wrapperID: '#media_photo_list_wrapper',
            }
          },
          componentWillMount: function(){
            var th = this;
            this.serverRequest = axios.get(media_base_url+'/media/vault-sort/'+a+'/image?_format=json')
            .then(function(response) {
              return response.data;
            })
            .then(function(data) {
              th.setState({sorting: data});
            });                   
                        
            this.serverRequest = 
              axios.get(url)
                .then(function(result) {    
                    return result.data.field_vault_photo;
                })
                .then(function(response) {
                  return Promise.all(response.map( (record, index) => {
                    return axios.get(media_base_url+'/media/'+record.target_id+'/edit?_format=json');                    
                  }))
                })
                .then(function(responsex) {
                  th.setState({photos: responsex}); 
                });
          },
          componentDidMount: function(){ 
          },
          componentWillUnmount: function() {
            this.serverRequest.abort();
          },
          UpdateMethod: function() {
            //Force a render with a simulated state change
            var th = this;
              this.serverRequest = 
                axios.get(url)
                  .then(function(result) { 
                    return result.data.field_vault_photo;                   
                  })
                  .then(function(response) {
                     return Promise.all(response.map( (record, index) => {
                       return axios.get(media_base_url+'/media/'+record.target_id+'/edit?_format=json');
                     }))
                  })
                  .then(function(responsex) {
                    th.setState({photos: responsex});                   
                    th.setState({spinner_status: false}); 
                    jQuery('#media_photo_list_wrapper').find('.progress-overlay').remove();
                  });            
          },
          render: function() {
            var counter = 0;
            var archive_switch;
            var archiveswitchid;
            if(Boolean(media_archive)){
              archive_text = 'Media Vault';
            }else{
              archive_text = 'View Archive';
            }
            if (this.state.showModal) {
              var modalElement = React.createElement(Modal, {handleHideModal: this.handleHideModal, handleArchive: this.handleArchivePhoto, fileType: this.state.fileType, mid:this.state.mid, base_url:this.state.base_url, delete_modal_msg: this.state.delete_modal_msg, arc_status: this.state.arc_status});
            }
            if(this.state.spinner_status){
              var spinner_process = React.createElement('div', {className:'progress-overlay'}, React.createElement('div', {className:'spinner-border'}, null));
            }
            if(this.state.sorting.length == 0){
              this.state.photos.sort((a, b) => a.data.name[0].value.localeCompare(b.data.name[0].value));
            }
            var items = this.state.photos.map((item, key) => {
  
              if(item.data.field_archived[0].value == Boolean(media_archive)){
                counter += 1;
                //File size
                let file_name = React.createElement(AppFileName, {base_url:this.state.base_url, fid: item.data.field_media_image[0].target_id});
                //for created Date
                let current_datetime = new Date(item.data.created[0].value)
                var h = current_datetime.getHours();
                var meridian = 'AM';
                if( h > 12){
                 h = h - 12 ;
                 meridian = 'PM';
                }
                var min = current_datetime.getMinutes();
                if(min < 10){
                 min = '0'+min;
                }
                let formatted_date =  (current_datetime.getMonth() + 1) + "/" +current_datetime.getDate()+ "/" + current_datetime.getFullYear() +", "+ h + ":" + min+' '+meridian;
                //for favorite
                var favorite_inactive = 'inactive';
                if(Boolean(item.data.field_favorite[0].value)){
                  favorite_inactive = '';
                }
                //File type
                let app_extention = React.createElement(AppExtention, {base_url:this.state.base_url, fid: item.data.field_media_image[0].target_id, get_type_col: false});
                //File size
                if((item.data.field_file_size).length > 0){
                  var file_size = item.data.field_file_size[0].value;
                } else {
                  var file_size = React.createElement(AppFileSize, {base_url:this.state.base_url, fid: item.data.field_media_image[0].target_id});
                }
                
                //let p_dimentions = React.createElement(pdimention, {sourceURL: item.data.field_media_image[0].url});
                //Photo Pixel dimension
                if((item.data.field_pixel_dimentions).length > 0){
                  var p_dimension = item.data.field_pixel_dimentions[0].value;
                } else {
                  var p_dimension = '-';//React.createElement(AudioTime, {audioURL: item.data.field_media_audio_file[0].url}); 
                }
                
                let mkit_elem = React.createElement(AppMediaKits, {base_url:this.state.base_url, mid: item.data.mid[0].value, fileType: 'image'});
                
                return React.createElement('tr', {'data-id': key, 'data-mtype': item.data.bundle[0].target_id, 'data-nid': media_vault_id, 'data-mid': item.data.mid[0].value, id: 'item-photo-'+key,className:'media-row',  'data-exthumbimage': item.data.field_media_image[0].image_style, 'data-src': item.data.field_media_image[0].url/* ,  'data-sub-html': '#gallery-caption' */},
                  React.createElement('td', {className: 'media-data text-center'},
                    React.createElement('span', {className: 'move-icon'}),
                    React.createElement('label', {className: 'checkbox-container'},
                      React.createElement('input',{type: 'checkbox', id: 'audio-check-'+key, className: 'box-check', 'data-mid': item.data.mid[0].value, defaultChecked: false, onChange: this.switch_operation_action.bind()}),
                      React.createElement('span', {className: 'checkmark'}),
                    )
                  ),
                  React.createElement('td', {className: 'media-data media-data-col-name'},
                    React.createElement("div", {id: key, className:"media-box"}, 
                      React.createElement('img', {id: 'myimg-'+key, src:item.data.field_media_image[0].image_style}, ''),
                      React.createElement('div', {className: 'overlay'},
                        React.createElement('button', {type: 'button', className: 'preview-icon', onClick: this.ShowPhotomodal.bind()}, '')
                      )
                    )
                  ),
                  React.createElement('td', {className: 'media-data media-title'}, item.data.name[0].value, mkit_elem),
                  React.createElement('td', {className: 'media-data media-f-name'}, file_name),
                  React.createElement('td', {className: 'media-data media-format'}, app_extention),
                  React.createElement('td', {className: 'media-data media-dimension'}, p_dimension),
                  React.createElement('td', {className: 'media-data media-f-size'}, file_size),
                  React.createElement('td', {className: 'media-data media-fav text-center'},
                    React.createElement('ul', {},
                      React.createElement('li', {},
                        React.createElement('a', {href:'/media/'+item.data.mid[0].value+'/edit', className: 'media-edit audio-round-button'}, ''),
                      ),
                      React.createElement('li', {},
                        React.createElement('button', {type: 'button', className: 'media-favo round-button '+favorite_inactive, onClick: this.handleFavoritePhoto.bind(null, item.data.mid[0].value, item.data.field_favorite[0].value, key)}, '')
                      ),
                      React.createElement('li', {},
                        React.createElement('a', {href:item.data.field_media_image[0].url, download:'', className: 'media-download round-button'}, ''), 
                      ),
                      React.createElement('li', {},
                        React.createElement('button', {type: 'button', className: this.state.arc_icon_class+' audio-round-button', onClick: this.Showmodal.bind(null, item.data.bundle[0].target_id, item.data.mid[0].value, key)}, '')
                      )                   
                    )                      
                  ),
                )
              }else if(media_archive){
                archive_switch = '/media/vault/'+a+window.location.hash;
                archiveswitchid = 'archiveswitch';
              }else{
                archive_switch = '/media/archive/'+a+window.location.hash;
                archiveswitchid = 'archiveswitch';
              }
            });
            
            var table_head = React.createElement('thead',{},
              React.createElement('tr', null,
                React.createElement('th', null, ),
                React.createElement('th', null, ),
                React.createElement('th', {className: 'media-title', style:{'width':'36%'}}, React.createElement('span', null, 'Title')),
                React.createElement('th', {className: 'media-f-name', style:{'width':'20%'}}, React.createElement('span', null, 'File Name')),
                React.createElement('th', {className: 'media-format'}, React.createElement('span', null, 'Format')),
                React.createElement('th', {className: 'media-dimension'}, React.createElement('span', null, 'Pixel Dimensions')),
                React.createElement('th', {className: 'media-f-size'}, React.createElement('span', null, 'File Size')),
                React.createElement('th', {className: 'text-center media-fav'}, React.createElement('span', null, 'ACTIONS')),
              )
            );
            var table_body = React.createElement('tbody', {id: 'lightgallery'}, items);
            var table_data = React.createElement('table',{id: 'photo_vault', className: 'media-table'},table_head, table_body);
            React.render(
              React.createElement(SelectDownload, {box: '#media_photo_list_wrapper', fileType: 'photo', singlecheckPhoto: this.state.singlecheckPhoto, archiveswitchid: archiveswitchid, archive_switch: archive_switch, archive_text: archive_text, nmk: nmk}),document.querySelector("#photo-select-box-element-wrapper"));
            //render to Photo Tab
            if(media_archive == 0){
              var photomsg =React.createElement("span", null, "Drag photos here to upload.", React.createElement("br", null, "Acceptable file types include: jpeg, jpg, and png."));
              React.render(
              React.createElement(FileUploader,{dragmsg: photomsg, fileType:'image', extensions : 'jpg,jpeg,png'}), document.querySelector("#media-uploader-box-photo"));
            }
            var updatediv = React.createElement('div', {className: 'd-none', id: 'photo-refresh', onClick: this.UpdateMethod.bind()}, 'refresh');
            
            return ( React.createElement("div", {id: 'media_photo_list_wrapper', className: 'row pt-3 m-0 table-responsive'}, table_data, modalElement, /* captionForm, */ spinner_process, updatediv) );
          },
          ShowPhotomodal: function(e){
            var $lg = jQuery("[id^=lightgallery]");
            var gallery = $lg.lightGallery({
              width: '880px',
              height: '720px',
              addClass: 'fixed-size',
              counter: false,
              download: false,
              enableSwipe: false,
              enableDrag: false,
              share: false,
              autoplay: false,
              thumbMargin : 17,
              autoplayControls: false,
              fullScreen: false,
              zoom: false,
              actualSize: false,
              toogleThumb: false,
              thumbnail:true,           
              thumbWidth: 94,  
              thumbContHeight: 118,
              exThumbImage: 'data-exthumbimage',              
            });
            
            jQuery(e.target).trigger('click');

            gallery.on('onCloseAfter.lg',function(event, index, fromTouch, fromThumb){
              try{gallery.data('lightGallery').destroy(true);}catch(ex){};
            });
          },
          Showmodal: function(fileType, mid, row_id){
            var msg =React.createElement("div", null, "This action will remove this media file from your ", React.createElement("b", null, "Media Vault"), " and move it to your ", React.createElement("b", null, "Media Archive"), ". It will not be available for use while archived. You will be able to recover it later, if needed.");
            if(this.state.arc_status){
              msg = React.createElement('div', null, 'This action will restore this file to your Media Vault and any previously selected uses.');
            }
            this.setState({showModal: true});
            this.setState({fileType: fileType});
            this.setState({mid: mid});
            this.setState({row_id: row_id});
            this.setState({delete_modal_msg: msg});
          },
          handleHideModal: function(){
           this.setState({showModal: false});
           this.setState({mid: ''});
           this.setState({row_id: ''});
           this.setState({delete_modal_msg: ''});
          },
          forceUpdateHandler: function(){
            this.forceUpdate();
          },
          handleArchivePhoto: function(){
            var t = this;
            var delete_row = Number(this.state.row_id);
            axios.get(Drupal.url('rest/session/token'))
            .then(function (data) {
              var csrfToken = data.data;
              let headers = {'Content-Type': 'application/hal+json','Cache-Control': 'no-cache', 'X-CSRF-Token':csrfToken,};
              var media_url_hal_json = t.state.base_url+'/media/'+ t.state.mid+'/edit?_format=hal_json';
              var type_url = t.state.base_url + '/rest/type/media/image';
              var photo_hal_json_archive = {
                "_links": {
                  "type": {"href": type_url }
                },
                "field_archived": [
                  {
                    "value": Boolean(!media_archive)
                  }
                ]
              };
              axios.patch(media_url_hal_json, photo_hal_json_archive, { headers: headers })
              .then(function(result) {
                if(result.status == 200){
                  t.setState({spinner_status: true}); 
                  jQuery("#photo-refresh").trigger('click');
                }else{
                  alert('Error');
                }
              });
              jQuery('#modal').modal('hide');
              t.setState({showModal: false});
              t.setState({mid: ''});
              t.setState({row_id: ''});
              t.setState({delete_modal_msg: ''});
              //t.setState({ photos: this.state });
            });
          },
          handleFavoritePhoto: function(mid, field_favorite_value, row_id){
            this.setState({spinner_status: true});
            var t =this;
            var favorite_row = Number(row_id);
            axios.get(Drupal.url('rest/session/token'))
            .then(function (data) {
              var csrfToken = data.data;
              let headers = {'Content-Type': 'application/hal+json','Cache-Control': 'no-cache', 'X-CSRF-Token':csrfToken,};
              var media_url_hal_json = t.state.base_url+'/media/'+mid+'/edit?_format=hal_json';
              var type_url = t.state.base_url + '/rest/type/media/image';
              var image_hal_json_favorite = {
                "_links": {
                  "type": {"href": type_url }
                },
                "field_favorite": [
                  {
                    "value": Boolean(!field_favorite_value)
                  }
                ]
              };
              axios.patch(media_url_hal_json, image_hal_json_favorite, { headers: headers })
              .then(function(result) {
                if(result.status == 200){
                  let new_list = t.state.photos;
                  new_list[favorite_row].data.field_favorite[0].value = Boolean(!field_favorite_value);
                  t.setState({photos: new_list});
                  t.setState({spinner_status: false});
                }else{
                  alert('Error');
                }
              });
              t.setState({mid: ''});
            });
          },
          sortColumn: function(e){
            const getCellValue = (tr, idx) => tr.children[idx].innerText || tr.children[idx].textContent;
            const comparer = (idx, asc) => (a, b) => ((v1, v2) => 
              v1 !== '' && v2 !== '' && !isNaN(v1) && !isNaN(v2) ? v1 - v2 : v1.toString().localeCompare(v2)
              )(getCellValue(asc ? a : b, idx), getCellValue(asc ? b : a, idx));
            const table = e.target.closest('table');
            if(e.target.asc){
              jQuery('.media-table th.sort span').removeClass();
              jQuery(e.target).addClass("desc-icon");
            }else if(!e.target.asc){
              jQuery('.media-table th.sort span').removeClass();
              jQuery(e.target).addClass("asc-icon");
            }else{
              jQuery('.media-table th.sort span').removeClass();
              jQuery(e.target).addClass("asc-icon");
            }
            Array.from(table.querySelectorAll('tr:nth-child(n+2)'))
              .sort(comparer(Array.from(e.target.parentNode.parentNode.children).indexOf(e.target.parentNode), e.target.asc = !e.target.asc))
              .forEach(tr => table.appendChild(tr) );
              
            //adding class to sorted column
            jQuery('.media-table td').removeClass('sorted');
            var table_id = jQuery(e.target.closest('table').parentNode).attr('id');
            var ind = jQuery(e.target.parentNode).index() + 1;
            jQuery('#'+table_id+' td:nth-child('+ind+')').addClass('sorted');
          },
          switch_operation_action: function(e){
            this.setState({singlecheckPhoto: true});
            if (e.target.checked) {
              selectedRows_photo.push(+e.target.attributes.getNamedItem("data-mid").value);
            } else {
              let index = selectedRows_photo.indexOf(+e.target.attributes.getNamedItem("data-mid").value);
              selectedRows_photo.splice(index, 1);
            }
            var data = jQuery(this.state.wrapperID+' .checkbox-container input[type="checkbox"]:checked').map(function() {
                        return e.target.value;
                      }).get();
            if(data == ''){
              jQuery('#photo-select-box-element-wrapper').addClass('options-disable');
            }
            else {
              jQuery('#photo-select-box-element-wrapper').removeClass('options-disable');
            }
           }
        });
        React.render(
          React.createElement(AppPhoto, 'div',{className:'x2'}), document.querySelector("#nav-master-photo-detail"));

        //Text Detail
        var AppText = React.createClass({
          getInitialState: function() {
            return {
              texts: [],
              sorting: [],
              showModal: false,
              singlecheckText: false,
              showTextModal: false,
              fileType: '',
              mid: '',
              textFileURL: '',
              base_url: media_base_url,
              row_id: '',
              delete_modal_msg: '',
              arc_icon_class: 'arc_'+media_archive,
              arc_status: media_archive,
              spinner_status: false,
              wrapperID: '#media_text_list_wrapper',
            }
          },
          componentWillMount: function() {
            var th = this;
            this.serverRequest = axios.get(media_base_url+'/media/vault-sort/'+a+'/text?_format=json')
            .then(function(response) {
              return response.data;
            })
            .then(function(data) {
              th.setState({sorting: data});
            });
              
            this.serverRequest = 
              axios.get(this.props.source)
                .then(function(result) {    
                    return result.data.field_vault_file;
                })
                .then(function(response) {
                  return Promise.all(response.map( (record, index) => {
                    return axios.get(media_base_url+'/media/'+record.target_id+'/edit?_format=json');
                  }))
                })
                .then(function(responsex) {
                  th.setState({texts: responsex});
                });
          },
          componentDidMount: function(){
          },
          componentWillUnmount: function() {
            this.serverRequest.abort();
          },
          UpdateMethod: function() {
            //Force a render with a simulated state change
            var th = this;
              this.serverRequest = 
                axios.get(this.props.source)
                  .then(function(result) { 
                    return result.data.field_vault_file;                   
                  })
                  .then(function(response) {
                     return Promise.all(response.map( (record, index) => {
                       return axios.get(media_base_url+'/media/'+record.target_id+'/edit?_format=json');
                     }))
                  })
                  .then(function(responsex) {
                    th.setState({texts: responsex}); 
                    th.setState({spinner_status: false});
                    jQuery('#media_text_list_wrapper').find('.progress-overlay').remove();                    
                  });            
          },
          render: function() {
            var counter = 0;
            var archive_switch;
            var archiveswitchid;
            if(Boolean(media_archive)){
              archive_text = 'Media Vault';
            }else{
              archive_text = 'View Archive';
            }
            if (this.state.showTextModal) {
              var textReaderElement = React.createElement(textReader, {hideTextReaderModal: this.hideTextReaderModal, textFileURL: this.state.textFileURL});
            }
            if (this.state.showModal) {
              var modalElement = React.createElement(Modal, {handleHideModal: this.handleHideModal, handleArchive: this.handleArchiveText, fileType: this.state.fileType, mid:this.state.mid, base_url:this.state.base_url, delete_modal_msg: this.state.delete_modal_msg, arc_status: this.state.arc_status});
            }
            if(this.state.spinner_status){
              var spinner_process = React.createElement('div', {className:'progress-overlay'}, React.createElement('div', {className:'spinner-border'}, null));
            }
            if(this.state.sorting.length == 0){
              this.state.texts.sort((a, b) => a.data.name[0].value.localeCompare(b.data.name[0].value));
            }
            var items = this.state.texts.map((item, key) => {
              if(item.data.field_archived[0].value == Boolean(media_archive)){
                counter += 1;
                //File size
                let file_name = React.createElement(AppFileName, {base_url:this.state.base_url, fid: item.data.field_media_file[0].target_id});
                //for created Date
                let current_datetime = new Date(item.data.created[0].value)
                var h = current_datetime.getHours();
                var meridian = 'AM';
                if( h > 12){
                 h = h - 12 ;
                 meridian = 'PM';
                }
                var min = current_datetime.getMinutes();
                if(min < 10){
                 min = '0'+min;
                }
                let formatted_date =  (current_datetime.getMonth() + 1) + "/" +current_datetime.getDate()+ "/" + current_datetime.getFullYear() +", "+ h + ":" + min+' '+meridian;
                //for favorite
                var favorite_inactive = 'inactive';
                if(Boolean(item.data.field_favorite[0].value)){
                  favorite_inactive = '';
                }
                //File ext
                let app_extention = React.createElement(AppExtention, {base_url:this.state.base_url, fid: item.data.field_media_file[0].target_id, get_type_col: false});
                //File type
                let app_extentiontype = React.createElement(AppExtention, {base_url:this.state.base_url, fid: item.data.field_media_file[0].target_id, get_type_col: true});
                
                //File size
                if((item.data.field_file_size).length > 0){
                  var file_size = item.data.field_file_size[0].value;
                } else {
                  var file_size = React.createElement(AppFileSize, {base_url:this.state.base_url, fid: item.data.field_media_file[0].target_id});
                }   
                let mkit_elem = React.createElement(AppMediaKits, {base_url:this.state.base_url, mid: item.data.mid[0].value, fileType: 'text'});
                
                return React.createElement('tr', {'data-id': key, 'data-mtype': item.data.bundle[0].target_id, 'data-nid': media_vault_id, 'data-mid': item.data.mid[0].value, id: 'item-text-'+key,className:'media-row'},
                  React.createElement('td', {className: 'media-data text-center'},
                    React.createElement('span', {className: 'move-icon'}),
                    React.createElement('label', {className: 'checkbox-container'},
                      React.createElement('input',{type: 'checkbox', id: 'audio-check-'+key, className: 'box-check', 'data-fid': item.data.field_media_file[0].target_id, 'data-mid': item.data.mid[0].value, defaultChecked: false, onChange: this.switch_operation_action.bind()}),
                      React.createElement('span', {className: 'checkmark'}),
                    )
                  ),
                  React.createElement('td', {className: 'media-data media-data-col-name'},
                    React.createElement("div", {id: key, className:"media-box text-box"}, 
                      React.createElement('button', {type: 'button', className: 'text-read-button', onClick: this.showTextModal.bind(null,item.data.field_media_file[0].url)},''),
                    )
                  ),
                  React.createElement('td', {className: 'media-data media-title'}, item.data.name[0].value, mkit_elem),
                  React.createElement('td', {className: 'media-data media-f-name'}, file_name),
                  React.createElement('td', {className: 'media-data media-format'}, app_extentiontype),
                  React.createElement('td', {className: 'media-data media-f-size'}, file_size),
                  React.createElement('td', {className: 'media-data media-fav text-center'},
                    React.createElement('ul', {},
                      React.createElement('li', {},
                        React.createElement('a', {href:'/media/'+item.data.mid[0].value+'/edit', className: 'media-edit audio-round-button'}, ''),
                      ),
                      React.createElement('li', {},
                        React.createElement('button', {type: 'button', className: 'media-favo round-button '+favorite_inactive, onClick: this.handleFavoriteText.bind(null, item.data.mid[0].value, item.data.field_favorite[0].value, key)}, '')
                      ),
                      React.createElement('li', {},
                        React.createElement('a', {href:item.data.field_media_file[0].url, download:'', className: 'media-download round-button'}, ''), 
                      ),
                      React.createElement('li', {},
                        React.createElement('button', {type: 'button', className: this.state.arc_icon_class+' audio-round-button', onClick: this.Showmodal.bind(null, item.data.bundle[0].target_id, item.data.mid[0].value, key)}, '')
                      )
                    )
                  ),
                )
              }else if(media_archive){
                archive_switch = '/media/vault/'+a+window.location.hash;
                archiveswitchid = 'archiveswitch'; 
              }else{
                archive_switch = '/media/archive/'+a+window.location.hash;
                archiveswitchid = 'archiveswitch';  
              }
            });
            var table_head = React.createElement('thead',{},
              React.createElement('tr', null,
                React.createElement('th', null, ),
                React.createElement('th', null, ),
                React.createElement('th', {className: 'media-title', style:{'width':'36%'}}, React.createElement('span', null, 'Title')),
                React.createElement('th', {className: 'media-f-name', style:{'width':'20%'}}, React.createElement('span', null, 'File Name')),
                React.createElement('th', {className: 'media-format'}, React.createElement('span', null, 'Format')),
                React.createElement('th', {className: 'media-f-size'}, React.createElement('span', null, 'File Size')),
                React.createElement('th', {className: 'text-center media-fav'}, React.createElement('span', null, 'ACTIONS')),
              )
            );
            var table_body = React.createElement('tbody', null, items);
            var table_data = React.createElement('table',{id: 'text_vault', className: 'media-table'},table_head, table_body);
            React.render(
              React.createElement(SelectDownload, {box: '#media_text_list_wrapper', fileType: 'text', singlecheckText: this.state.singlecheckText, archiveswitchid: archiveswitchid, archive_switch: archive_switch, archive_text: archive_text, nmk: nmk}),document.querySelector("#text-select-box-element-wrapper"));
            //render to Text Tab
            if(media_archive == 0){
              React.render(
                React.createElement(FileUploader,{dragmsg: 'Drag Text based files here to upload.', fileType:'text', extensions : 'txt,doc,docx,pdf,epub'}), document.querySelector("#media-uploader-box-text"));
            }
            var updatediv = React.createElement('div', {className: 'd-none', id: 'text-refresh', onClick: this.UpdateMethod.bind()}, 'refresh');
            return ( React.createElement("div", {id: 'media_text_list_wrapper', className: 'row pt-3 m-0 table-responsive'}, table_data, modalElement, /* captionForm, */ spinner_process, textReaderElement, updatediv) );
          },
          Showmodal: function(fileType, mid, row_id){
            var msg =React.createElement("div", null, "This action will remove this media file from your ", React.createElement("b", null, "Media Vault"), " and move it to your ", React.createElement("b", null, "Media Archive"), ". It will not be available for use while archived. You will be able to recover it later, if needed.");
            if(this.state.arc_status){
             msg = React.createElement('div', null, 'This action will restore this file to your Media Vault and any previously selected uses.');
            }
            this.setState({showModal: true});
            this.setState({fileType: fileType});
            this.setState({mid: mid});
            this.setState({row_id: row_id});
            this.setState({delete_modal_msg: msg});
          },
          handleHideModal: function(){
           this.setState({showModal: false});
           this.setState({mid: ''});
           this.setState({row_id: ''});
           this.setState({delete_modal_msg: ''});
          },
          handleArchiveText: function(){
            var t = this;
            var delete_row = Number(this.state.row_id);
            axios.get(Drupal.url('rest/session/token'))
            .then(function (data) {
              var csrfToken = data.data;
              let headers = {'Content-Type': 'application/hal+json','Cache-Control': 'no-cache', 'X-CSRF-Token':csrfToken,};
              var media_url_hal_json = t.state.base_url+'/media/'+ t.state.mid+'/edit?_format=hal_json';
              var type_url = t.state.base_url + '/rest/type/media/text';
              var media_hal_json_archive = {
                "_links": {
                  "type": {"href": type_url }
                },
                "field_archived": [
                  {
                    "value": Boolean(!media_archive)
                  }
                ]
              };
              axios.patch(media_url_hal_json, media_hal_json_archive, { headers: headers })
              .then(function(result) {
                if(result.status == 200){
                  t.setState({spinner_status: true}); 
                  jQuery("#text-refresh").trigger('click');
                }else{
                  alert('Error');
                }
              });
              jQuery('#modal').modal('hide');
              t.setState({showModal: false});
              t.setState({mid: ''});
              t.setState({row_id: ''});
              t.setState({delete_modal_msg: ''});
            });
          },
          handleFavoriteText: function(mid, field_favorite_value, row_id){
            this.setState({spinner_status: true});
            var t =this;
            var favorite_row = Number(row_id);
            axios.get(Drupal.url('rest/session/token'))
            .then(function (data) {
              var csrfToken = data.data;
              let headers = {'Content-Type': 'application/hal+json','Cache-Control': 'no-cache', 'X-CSRF-Token':csrfToken,};
              var media_url_hal_json = t.state.base_url+'/media/'+mid+'/edit?_format=hal_json';
              var type_url = t.state.base_url + '/rest/type/media/text';
              var image_hal_json_favorite = {
                "_links": {
                  "type": {"href": type_url }
                },
                "field_favorite": [
                  {
                    "value": Boolean(!field_favorite_value)
                  }
                ]
              };
              axios.patch(media_url_hal_json, image_hal_json_favorite, { headers: headers })
              .then(function(result) {
                if(result.status == 200){
                  let new_list = t.state.texts;
                  new_list[favorite_row].data.field_favorite[0].value = Boolean(!field_favorite_value);
                  t.setState({texts: new_list});
                  t.setState({spinner_status: false});
                }else{
                  alert('Error');
                }
              });
              t.setState({mid: ''});
            });
          },
          showTextModal: function(fileURL){
            this.setState({showTextModal: true});
            this.setState({textFileURL: fileURL });
          },
          hideTextReaderModal: function(){
            this.setState({showTextModal: false});
            this.setState({textFileURL: '' });
          },
          sortColumn: function(e){
            const getCellValue = (tr, idx) => tr.children[idx].innerText || tr.children[idx].textContent;
            const comparer = (idx, asc) => (a, b) => ((v1, v2) => 
              v1 !== '' && v2 !== '' && !isNaN(v1) && !isNaN(v2) ? v1 - v2 : v1.toString().localeCompare(v2)
              )(getCellValue(asc ? a : b, idx), getCellValue(asc ? b : a, idx));
            const table = e.target.closest('table');
            if(e.target.asc){
              jQuery('.media-table th.sort span').removeClass();
              jQuery(e.target).addClass("desc-icon");
            }else if(!e.target.asc){
              jQuery('.media-table th.sort span').removeClass();
              jQuery(e.target).addClass("asc-icon");
            }else{
              jQuery('.media-table th.sort span').removeClass();
              jQuery(e.target).addClass("asc-icon");
            }
            Array.from(table.querySelectorAll('tr:nth-child(n+2)'))
              .sort(comparer(Array.from(e.target.parentNode.parentNode.children).indexOf(e.target.parentNode), e.target.asc = !e.target.asc))
              .forEach(tr => table.appendChild(tr) );
              
            //adding class to sorted column
            jQuery('.media-table td').removeClass('sorted');
            var table_id = jQuery(e.target.closest('table').parentNode).attr('id');
            var ind = jQuery(e.target.parentNode).index() + 1;
            jQuery('#'+table_id+' td:nth-child('+ind+')').addClass('sorted');
          },
          switch_operation_action: function(e){
            this.setState({singlecheckText: true});
            if (e.target.checked) {
              selectedRows_text.push(+e.target.attributes.getNamedItem("data-mid").value);
            } else {
              let index = selectedRows_text.indexOf(+e.target.attributes.getNamedItem("data-mid").value);
              selectedRows_text.splice(index, 1);
            }
            var data = jQuery(this.state.wrapperID+' .checkbox-container input[type="checkbox"]:checked').map(function() {
                        return e.target.value;
                      }).get();
            if(data == ''){
              jQuery('#text-select-box-element-wrapper').addClass('options-disable');
            }
            else {
              jQuery('#text-select-box-element-wrapper').removeClass('options-disable');
            }
           } 
        });
          React.render(
            React.createElement(AppText, {source: url, pollInterval: 10000}), document.querySelector("#nav-master-text-detail"));

        //Video Detail
        var AppVideo = React.createClass({
          getInitialState: function() {
            return {
              video: [],
              sorting: [],
              cty: [],
              showModal: false,
              singlecheckVideo: false,
              fileType: '',
              fileURL: '',
              mid: '',
              base_url: media_base_url,
              videoplayer: false,
              nextVideoTrack: 0,
              totalCount: 0,
              playnowclass : 'fa fa-pause col-md-6',
              playnow_status: true,
              volume_level: 1,
              seekslider_value: 0,
              curtimetext: '0:00',
              durtimetext: '0:00',
              row_id: '',
              delete_modal_msg: '',
              arc_icon_class: 'arc_'+media_archive,
              arc_status: media_archive,
              spinner_status: false,
              wrapperID: '#media_video_list_wrapper',
            }
          },
          componentWillMount: function() {
            var th = this;
            this.serverRequest = axios.get(media_base_url+'/media/vault-sort/'+a+'/video?_format=json')
            .then(function(response) {
              return response.data;
            })
            .then(function(data) {
              th.setState({sorting: data});
            });
            
            this.serverRequest = 
              axios.get(this.props.source)
                .then(function(result) {    
                    return result.data.field_vault_video;
                })
                .then(function(vresponse) {
                   return Promise.all(vresponse.map( (vrecord, index) => {
                     return axios.get(media_base_url+vrecord.url +'?_format=json');
                   }))
                })
                .then(function(vresponsex) {
                  th.setState({video: vresponsex});
                });           
          },
          componentDidMount: function(){
          },
          componentWillUnmount: function() {
            this.serverRequest.abort();
          },          
          UpdateMethod: function() {
            //Force a render with a simulated state change
            var th = this;
              this.serverRequest = 
                axios.get(this.props.source)
                  .then(function(result) { 
                    return result.data.field_vault_video;                   
                  })
                  .then(function(response) {
                     return Promise.all(response.map( (record, index) => {
                       return axios.get(media_base_url+'/media/'+record.target_id+'/edit?_format=json');
                     }))
                  })
                  .then(function(responsex) {                 
                    th.setState({video: responsex});
                    th.setState({spinner_status: false});
                    jQuery('#media_video_list_wrapper').find('.progress-overlay').remove();
                  });            
          },
          render: function() {
            var univ = [];
            var counter = 0;
            var archive_switch;
            var archiveswitchid;
            if(Boolean(media_archive)){
              archive_text = 'Media Vault';
            }else{
              archive_text = 'View Archive';
            }
            if (this.state.showModal) {
              var modalElement = React.createElement(Modal, {handleHideModal: this.handleHideModal, handleArchive: this.handleArchiveVideo, fileType: this.state.fileType, mid:this.state.mid, base_url:this.state.base_url, delete_modal_msg: this.state.delete_modal_msg, arc_status: this.state.arc_status});
            }
            if(this.state.spinner_status){
              var spinner_process = React.createElement('div', {className:'progress-overlay'}, React.createElement('div', {className:'spinner-border'}, null));
            }
            if (this.state.videoplayer) {
              var videoPlayerElement = React.createElement(VideoPlayer, {
                                          handleHideVideoPlayer: this.handleHideVideoPlayer,
                                          playNowVideo: this.playNowVideo,
                                          fileURL: this.state.fileURL,
                                          VVolControl: this.VVolControl,
                                          playnowclass: this.state.playnowclass,
                                          playnowNext: this.playnowNext,
                                          playnowPrev: this.playnowPrev,
                                          vidSeek: this.vidSeek,
                                          seektimeupdate: this.seektimeupdate,
                                          volume_level: this.state.volume_level,
                                          seekslider_value: this.state.seekslider_value,
                                          curtimetext: this.state.curtimetext,
                                          durtimetext: this.state.durtimetext,
                                          videoCompleted: this.videoCompleted});
            }
            const rowLen = this.state.video.length;
            if(this.state.sorting.length == 0){
              this.state.video.sort((a, b) => a.data.name[0].value.localeCompare(b.data.name[0].value));
            }
            var items = this.state.video.map((item, key) => {
              if(item.data.field_archived[0].value == Boolean(media_archive)){
                counter += 1;
                //File size
                let file_name = React.createElement(AppFileName, {base_url:this.state.base_url, fid: item.data.field_media_video_file[0].target_id});
                
                //for favorite
                var favorite_inactive = 'inactive';
                if(Boolean(item.data.field_favorite[0].value)){
                  favorite_inactive = '';
                }
                
                //let video_time = React.createElement(Videovm, {key: key});
                //File type
                let app_extention = React.createElement(AppExtention, {base_url:this.state.base_url, fid: item.data.field_media_video_file[0].target_id, get_type_col: false});
                //File size
                if((item.data.field_file_size).length > 0){
                  var file_size = item.data.field_file_size[0].value;
                } else {
                  var file_size = React.createElement(AppFileSize, {key: key, base_url:this.state.base_url, fid: item.data.field_media_video_file[0].target_id});
                }
                //Video duration
                if((item.data.field_duration).length > 0){
                  var video_time = item.data.field_duration[0].value;
                } else {
                  var video_time = '-';//React.createElement(AudioTime, {audioURL: item.data.field_media_audio_file[0].url}); 
                } 
                if(item.data.field_media_video_file[0].is_thumbnail){
                  var video_thumb = React.createElement("video", {id: 'video-'+key}, 
                  React.createElement('source', {src:item.data.field_media_video_file[0].url, className: 'd-none'},''), 
                  React.createElement('img', {src:item.data.field_media_video_file[0].image_style},''));
                } else {
                  var video_thumb = React.createElement("video", {id: 'video-'+key}, React.createElement('source', {src:item.data.field_media_video_file[0].url},''));
                }
                let mkit_elem = React.createElement(AppMediaKits, {base_url:this.state.base_url, mid: item.data.mid[0].value, fileType: 'video'});
                
                return React.createElement('tr', {'data-id': key, 'data-mtype': item.data.bundle[0].target_id, 'data-nid': media_vault_id, 'data-mid': item.data.mid[0].value, id: 'item-video-'+key,className:'media-row'},
                  React.createElement('td', {className: 'media-data text-center'},
                    React.createElement('span', {className: 'move-icon'}),
                    React.createElement('label', {className: 'checkbox-container'},
                      React.createElement('input',{type: 'checkbox', id: 'audio-check-'+key, className: 'box-check', 'data-mid': item.data.mid[0].value, defaultChecked: false, onChange: this.switch_operation_action.bind()}),
                      React.createElement('span', {className: 'checkmark'}),
                    )
                  ),
                  React.createElement('td', {className: 'media-data media-data-col-name'},
                    React.createElement("div", {id: key, className:"media-box"}, 
                      video_thumb,
                      React.createElement('div', {className: 'overlay'},
                        React.createElement('button', {type: 'button', className: 'video-play round-button', onClick: this.ShowVideoPlayer.bind(null, item.data.field_media_video_file[0].url, +key, +rowLen), style:{'display':'none'}}, ''),
                      )
                    )
                  ),
                  React.createElement('td', {className: 'media-data media-title'}, item.data.name[0].value, mkit_elem),
                  React.createElement('td', {className: 'media-data media-f-name'}, file_name),
                  React.createElement('td', {className: 'media-data media-format'}, app_extention),
                  React.createElement('td', {className: 'media-data media-duration'}, video_time),
                  React.createElement('td', {className: 'media-data media-f-size'}, file_size),
                  React.createElement('td', {className: 'media-data media-fav text-center'},
                    React.createElement('ul', {},
                      React.createElement('li', {},
                        React.createElement('a', {href:'/media/'+item.data.mid[0].value+'/edit', className: 'media-edit audio-round-button'}, ''),
                      ),
                      React.createElement('li', {},
                        React.createElement('button', {type: 'button', className: 'media-favo round-button '+favorite_inactive, onClick: this.handleFavoriteVideo.bind(null, item.data.mid[0].value, item.data.field_favorite[0].value, key)}, '')
                      ),
                      React.createElement('li', {},
                        React.createElement('a', {href:item.data.field_media_video_file[0].url, download:'', className: 'media-download round-button'}, ''), 
                      ),
                      React.createElement('li', {},
                        React.createElement('button', {type: 'button', className: this.state.arc_icon_class+' audio-round-button', onClick: this.Showmodal.bind(null, item.data.bundle[0].target_id, item.data.mid[0].value, key)}, '')
                      )
                    )
                  ),
                )
              }else if(media_archive){
                archive_switch = '/media/vault/'+a+window.location.hash;
                archiveswitchid = 'archiveswitch';
              }else{
                archive_switch = '/media/archive/'+a+window.location.hash;
                archiveswitchid = 'archiveswitch';
              }
            });
            var table_head = React.createElement('thead',{},
              React.createElement('tr', null,
                React.createElement('th', null, ),
                React.createElement('th', null, ),
                React.createElement('th', {className: 'media-title', style:{'width':'30%'}}, React.createElement('span', null, 'Title')),
                React.createElement('th', {className: 'media-f-name', style:{'width':'20%'}}, React.createElement('span', null, 'File Name')),
                React.createElement('th', {className: 'media-format'}, React.createElement('span', null, 'Format')),
                React.createElement('th', {className: 'media-duration'}, React.createElement('span', null, 'Duration')),
                React.createElement('th', {className: 'media-f-size'}, React.createElement('span', null, 'File Size')),
                React.createElement('th', {className: 'text-center media-fav'}, React.createElement('span', null, 'ACTIONS')),
              )
            );
            var table_body = React.createElement('tbody', null, items);
            var table_data = React.createElement('table',{id: 'video_vault', className: 'media-table'},table_head, table_body);
            React.render(
              React.createElement(SelectDownload, {box: '#media_video_list_wrapper', fileType: 'video', singlecheckVideo: this.state.singlecheckVideo, archiveswitchid: archiveswitchid, archive_switch: archive_switch, archive_text: archive_text, nmk: nmk}),document.querySelector("#video-select-box-element-wrapper"));
            //render to Video Tab
            if(media_archive == 0){ 
              var videomsg =React.createElement("span", null, "Drag video here to upload.", React.createElement("br", null, "Acceptable file types include: avi, mov, and mp4."));
              React.render(
                React.createElement(FileUploader,{dragmsg: videomsg, fileType:'video', extensions : 'avi,mov,mp4'}), document.querySelector("#media-uploader-box-video")
              );
            }
            var updatediv = React.createElement('div', {className: 'd-none', id: 'video-refresh', onClick: this.UpdateMethod.bind()}, 'refresh');
            return ( React.createElement("div", {id: 'media_video_list_wrapper', className: 'row pt-3 m-0 table-responsive'}, table_data, modalElement, videoPlayerElement, spinner_process, updatediv) );
          },
          Showmodal: function(fileType, mid, row_id){
            var msg =React.createElement("div", null, "This action will remove this media file from your ", React.createElement("b", null, "Media Vault"), " and move it to your ", React.createElement("b", null, "Media Archive"), ". It will not be available for use while archived. You will be able to recover it later, if needed.");
            if(this.state.arc_status){
             msg = React.createElement('div', null, 'This action will restore this file to your Media Vault and any previously selected uses.');
            }
            this.setState({showModal: true});
            this.setState({fileType: fileType});
            this.setState({mid: mid});
            this.setState({row_id: row_id});
            this.setState({delete_modal_msg: msg});
          },
          handleHideModal: function(){
           this.setState({showModal: false});
           this.setState({mid: ''});
           this.setState({row_id: ''});
           this.setState({delete_modal_msg: ''});
          },
          handleArchiveVideo: function(){
            var t = this;
            var delete_row = Number(this.state.row_id);
            axios.get(Drupal.url('rest/session/token'))
            .then(function (data) {
              var csrfToken = data.data;
              let headers = {'Content-Type': 'application/hal+json','Cache-Control': 'no-cache', 'X-CSRF-Token':csrfToken,};
              var media_url_hal_json = t.state.base_url+'/media/'+ t.state.mid+'/edit?_format=hal_json';
              var type_url = t.state.base_url + '/rest/type/media/video';
              var media_hal_json_archive = {
                "_links": {
                  "type": {"href": type_url }
                },
                "field_archived": [
                  {
                    "value": Boolean(!media_archive)
                  }
                ]
              };
              axios.patch(media_url_hal_json, media_hal_json_archive, { headers: headers })
              .then(function(result) {
                if(result.status == 200){
                  t.setState({spinner_status: true});
                  jQuery("#video-refresh").trigger('click');
                }else{
                  alert('Error');
                }
              });
              jQuery('#modal').modal('hide');
              t.setState({showModal: false});
              t.setState({mid: ''});
              t.setState({row_id: ''});
              t.setState({delete_modal_msg: ''});
            });
          },
          handleFavoriteVideo: function(mid, field_favorite_value, row_id){
            this.setState({spinner_status: true});
            var t =this;
            var favorite_row = Number(row_id);
            axios.get(Drupal.url('rest/session/token'))
            .then(function (data) {
              var csrfToken = data.data;
              let headers = {'Content-Type': 'application/hal+json','Cache-Control': 'no-cache', 'X-CSRF-Token':csrfToken,};
              var media_url_hal_json = t.state.base_url+'/media/'+mid+'/edit?_format=hal_json';
              var type_url = t.state.base_url + '/rest/type/media/video';
              var image_hal_json_favorite = {
                "_links": {
                  "type": {"href": type_url }
                },
                "field_favorite": [
                  {
                    "value": Boolean(!field_favorite_value)
                  }
                ]
              };
              axios.patch(media_url_hal_json, image_hal_json_favorite, { headers: headers })
              .then(function(result) {
                if(result.status == 200){
                  let new_list = t.state.video;
                  new_list[favorite_row].data.field_favorite[0].value = Boolean(!field_favorite_value);
                  t.setState({video: new_list});
                  t.setState({spinner_status: false});
                }else{
                  alert('Error');
                }
              });
              t.setState({mid: ''});
            });
          },
          ShowVideoPlayer: function(fileURL, trackID, rowLen){
            this.setState({videoplayer: true});
            this.setState({fileURL: fileURL});
            this.setState({nextVideoTrack: trackID});
            this.setState({totalCount: rowLen});
          },
          handleHideVideoPlayer: function(){
            this.setState({videoplayer: false});
            this.setState({nextVideoTrack: 0});
            this.setState({totalCount: 0});
            this.setState({curtimetext: '0:00'});
            this.setState({durtimetext: '0:00'});
          },
          playNowVideo: function(){
            if(this.state.playnow_status){
              jQuery('.modal-video-playing')[0].pause();
              this.setState({playnow_status: false});
              this.setState({playnowclass :'fa fa-play col-md-6'});
            }else{
              jQuery('.modal-video-playing')[0].play();
              this.setState({playnow_status: true});
              this.setState({playnowclass :'fa fa-pause col-md-6'});
            }
          },
          VVolControl: function() {
            var sound = document.getElementsByClassName("video-volume-control");
            jQuery('.modal-video-playing')[0].volume = sound[0].value;
            this.setState({volume_level: sound[0].value})
            jQuery(sound).css('background-image',
              '-webkit-gradient(linear, left top, right top, '
              + 'color-stop(' + sound[0].value + ', #4f6ab7), '
              + 'color-stop(' + sound[0].value + ', #ccc)'
              + ')'
            );
          },
          playnowNext: function(){
            var nextid = this.state.nextVideoTrack;
            var totalCount = this.state.totalCount;
            var nexturl = '';
            nextid++;
            if(totalCount <= nextid){
              totalCount--;
              nexturl = jQuery('#video-'+totalCount+' source').attr('src');
              this.setState({nextVideoTrack: +totalCount});
            }else{
              nexturl = jQuery('#video-'+nextid+' source').attr('src');
              this.setState({nextVideoTrack: +nextid});
            }
            jQuery('.modal-video-playing')[0].src = nexturl;
            jQuery('.modal-video-playing')[0].play();
            this.setState({playnow_status: true});
            this.setState({playnowclass :'fa fa-pause col-md-6'});
          },
          playnowPrev: function(){
            var previd = this.state.nextVideoTrack;
            var prevurl = '';
            previd--;
            if(previd < 0){
              prevurl = jQuery('#video-0 source').attr('src');
              this.setState({nextVideoTrack: 0});
            }else{
              prevurl = jQuery('#video-'+previd+' source').attr('src');
              this.setState({nextVideoTrack: +previd});
            }
            jQuery('.modal-video-playing')[0].src = prevurl;
            jQuery('.modal-video-playing')[0].play();
            this.setState({playnow_status: true});
            this.setState({playnowclass :'fa fa-pause col-md-6'});
          },
          vidSeek: function(){
            var vid = jQuery('.modal-video-playing')[0];
            var seekslider = document.getElementsByClassName("time-control");
            var seekto = vid.duration * (seekslider[0].value / 100);
            vid.currentTime = seekto;
            this.setState({seekslider_value: seekslider[0].value});
          },
          seektimeupdate: function(){
            if(this.state.videoplayer){
              var vid = jQuery('.modal-video-playing')[0];
              var nt = vid.currentTime * (100 / vid.duration);
              this.setState({seekslider_value: +nt});
              var curmins = Math.floor(vid.currentTime / 60);
              var cursecs = Math.floor(vid.currentTime - curmins * 60);
              var durmins = Math.floor(vid.duration / 60);
              var dursecs = Math.floor(vid.duration - durmins * 60);
              if(cursecs < 10){ cursecs = "0"+cursecs; }
              if(dursecs < 10){ dursecs = "0"+dursecs; }
              if(curmins < 10){ curmins = "0"+curmins; }
              if(durmins < 10){ durmins = "0"+durmins; }
              var start = curmins+":"+cursecs;
              var end = durmins+":"+dursecs;
              this.setState({curtimetext: start});
              this.setState({durtimetext: end});
            }
          },
          videoCompleted: function(){
            this.setState({playnow_status: false});
            this.setState({playnowclass :'fa fa-play col-md-6'});
          },
          sortColumn: function(e){
            const getCellValue = (tr, idx) => tr.children[idx].innerText || tr.children[idx].textContent;
            const comparer = (idx, asc) => (a, b) => ((v1, v2) => 
              v1 !== '' && v2 !== '' && !isNaN(v1) && !isNaN(v2) ? v1 - v2 : v1.toString().localeCompare(v2)
              )(getCellValue(asc ? a : b, idx), getCellValue(asc ? b : a, idx));
            const table = e.target.closest('table');
            if(e.target.asc){
              jQuery('.media-table th.sort span').removeClass();
              jQuery(e.target).addClass("desc-icon");
            }else if(!e.target.asc){
              jQuery('.media-table th.sort span').removeClass();
              jQuery(e.target).addClass("asc-icon");
            }else{
              jQuery('.media-table th.sort span').removeClass();
              jQuery(e.target).addClass("asc-icon");
            }
            Array.from(table.querySelectorAll('tr:nth-child(n+2)'))
              .sort(comparer(Array.from(e.target.parentNode.parentNode.children).indexOf(e.target.parentNode), e.target.asc = !e.target.asc))
              .forEach(tr => table.appendChild(tr) );
              
            //adding class to sorted column
            jQuery('.media-table td').removeClass('sorted');
            var table_id = jQuery(e.target.closest('table').parentNode).attr('id');
            var ind = jQuery(e.target.parentNode).index() + 1;
            jQuery('#'+table_id+' td:nth-child('+ind+')').addClass('sorted');
           },
           switch_operation_action: function(e){
            this.setState({singlecheckVideo: true});
            if (e.target.checked) {
              selectedRows_video.push(+e.target.attributes.getNamedItem("data-mid").value);
            } else {
              let index = selectedRows_video.indexOf(+e.target.attributes.getNamedItem("data-mid").value);
              selectedRows_video.splice(index, 1);
            }
            var data = jQuery(this.state.wrapperID+' .checkbox-container input[type="checkbox"]:checked').map(function() {
                        return e.target.value;
                      }).get();
            if(data == ''){
              jQuery('#video-select-box-element-wrapper').addClass('options-disable');
            }
            else {
              jQuery('#video-select-box-element-wrapper').removeClass('options-disable');
            }
           }        
        });

        React.render(
          React.createElement(AppVideo, {source: url, pollInterval: 10000}), document.querySelector("#nav-master-video-detail"));
        //Remote Video Detail
        var AppRemoteVideo = React.createClass({
          getInitialState: function() {
            return {
              remotevideo: [],
              showModal: false,
              remoteVideoModal: false,
              fileType: '',
              fileURL: '',
              mid: '',
              base_url: media_base_url,
              videolink: '',
            }
          },
          componentDidMount: function() {
            var th = this;
            this.serverRequest = 
              axios.get(this.props.source)
                .then(function(result) {    
                    return result.data.field_vault_remote_video;
                })
                .then(function(response) {
                   return Promise.all(response.map( (record, index) => {
                     return axios.get(media_base_url+record.url +'?_format=json');
                   }))
                })
                .then(function(responsex) {
                  th.setState({remotevideo: responsex});
                });
          },
          componentWillUnmount: function() {
            this.serverRequest.abort();
          },
          render: function() {
            var counter = 0;
            if (this.state.showModal) {
              var modalElement = React.createElement(Modal, {handleHideModal: this.handleHideModal, fileType: this.state.fileType, mid:this.state.mid, base_url:this.state.base_url});
            }
            if (this.state.remoteVideoModal) {
              var remote_video_modalElement = React.createElement(RemoteVideoModal, {handleHideModal: this.handleHideModal, videolink: this.state.videolink});
            }
            const rowLen = this.state.remotevideo.length;
            var items = this.state.remotevideo.map((item, key) => {
              counter += 1;
              var videolink = item.data.field_media_oembed_video[0].value;
              var regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
              var match = videolink.match(regExp);
              if (match && match[2].length == 11) {
                videolink = match[2];
              } else {
                videolink = '';
              }

              return React.createElement("div", {id: key, className:"video-box common-box col-xl-2 col-lg-2 col-md-3 col-sm-4"},
                React.createElement("div", {className:"video-div mb-3"},
                  React.createElement('iframe', {className: 'remote-video', src: '//www.youtube.com/embed/'+videolink, 'frameborder':'0', width: '100%', height: '117px'}),
                  React.createElement('div', {className: 'overlay'},
                    React.createElement('input',{type: 'checkbox', id: 'remote-video-check-'+key, className: 'box-check custom-control-input', defaultChecked: false}),
                    React.createElement('label',{htmlFor:'remote-video-check-'+key, className: 'custom-control-label'}),
                    React.createElement('button', {type: 'button', className: 'tag round-button'}, ''),
                    React.createElement('button', {type: 'button', className: 'favo round-button'}, ''),
                    React.createElement('button', {type: 'button', className: 'delete round-button', onClick: this.Showmodal.bind(null, item.data.bundle[0].target_id, item.data.mid[0].value)}, ''),
                    React.createElement('button', {type: 'button', className: 'video-play round-button', onClick: this.ShowRemoteVideoPlayer.bind(null, videolink), style:{'display':'none'}}, ''),
                    React.createElement('button', {type: 'button', className: 'weight round-button'}, +counter)
                  )
                )
              )
            });
            return ( React.createElement("div", {id: "media_remote_video_list_wrapper", className:"row p-3"}, items, modalElement, remote_video_modalElement) );
          },
          Showmodal: function(fileType, mid){
            this.setState({showModal: true});
            this.setState({fileType: fileType});
            this.setState({mid: mid});
          },
          handleHideModal: function(){
           this.setState({showModal: false});
           this.setState({remoteVideoModal: false});
          },
          ShowRemoteVideoPlayer: function(videolink){
            this.setState({remoteVideoModal: true});
            this.setState({videolink: videolink});
          }
        });

        React.render(
          React.createElement(AppRemoteVideo, {source: url, pollInterval: 10000}), document.querySelector("#nav-master-remote-video-detail"));
        
        //archive/media vault link with active tab on window load
        var currentURL = window.location.href; 
        var activeTabarr = currentURL.split('#');
        if(activeTabarr[1]){
          window.location.hash = activeTabarr[1];          
        }
        //archive/media vault link with active tab on tab switch
        jQuery(".nav > .nav-item").on("shown.bs.tab", function(e) {
          var hashid = jQuery(e.target).attr("href").substr(1);
          window.location.hash = hashid;
          jQuery('#archiveswitch a').each(function(){
            if(media_archive){
              var archive_switch = '/media/vault/'+a+window.location.hash;
            }else{
              var archive_switch = '/media/archive/'+a+window.location.hash;
            }                        
            jQuery(this).attr('href', archive_switch);
          });
        });
        // on load of the page: switch to the currently selected tab
        //var hash = window.location.hash;
        //jQuery('#nav-tab a[href="' + hash + '"]').tab('show');        
               
        //update media kits order
        function media_vault_sortable(m_type, mid = ""){
          var data_string = '';
          var neworder = new Array();
          var mtype = m_type;
          if(m_type == 'image'){
            mtype = 'photo';
          }
          jQuery('#'+mtype+'_vault tbody tr').each(function (event) {
            neworder.push(jQuery(this).attr('data-mid'));
          });
          
          //console.log(neworder);

          jQuery.ajax({
            url: "/media_vault/sortable",
            data:{"uid":a, "mid":neworder, "type":m_type},
            type: "POST",
            success:function(xhr, status){           
            },
            error: function (xhr, status) {
              alert("Sorry, there was a problem!");
            },
            complete: function (xhr, status) {
              if(status == 'success'){
                if(neworder.length > 0) {
                  jQuery.each( neworder, function( key, value ) {
                    data_string += '{"target_id":'+value+'},';
                  }); 
                  //remove last comma
                  data_string = data_string.slice(0, -1);
                  data_string = '['+data_string+']';
                  //convert string to JSON data
                  jsondata = JSON.parse(data_string);

                  //update node audio field array as per sort order
                  axios.get(Drupal.url('rest/session/token'))
                  .then(function (data) {
                    var csrfToken = data.data;
                    let headers = {'Content-Type': 'application/hal+json','Cache-Control': 'no-cache', 'X-CSRF-Token':csrfToken,};
                    var node_url_json = media_base_url+"/node/"+media_vault_id+'?_format=hal_json';
                    var type_url = media_base_url+'/rest/type/node/media_vault';
                    var media_field = {
                      "_links": {
                        "type": {"href": type_url }
                      }
                    };                    

                    //create dynamic key for media field type
                    if(m_type == 'text'){
                      reference_field = "field_vault_file";
                    } else if(m_type == 'image'){
                      reference_field = "field_vault_photo";
                    } else{
                      reference_field = "field_vault_"+m_type;
                    }

                    media_field[reference_field] = jsondata;
                    var myArray = [];
                    myArray.push(media_field);
                    axios.patch(node_url_json, myArray[0], { headers: headers })
                    .then(function(resultdata) { 
                      window.location.reload();
                      /* setTimeout(function() {
                        jQuery("#"+mtype+"-refresh").trigger('click');
                      }, 4000); */
                    })
                  });  
                }
              }              
            }
          });
        };
        
        //media vault sorting
        jQuery("tbody").sortable({  
          handle: ".move-icon",
          start: function(e, ui) {
            items: "> tr";
            appendTo: "parent";
            helper: "clone";
            opacity: 1;
            containment: "document";
          },
          update: function( e, ui ) {
            var spinner = '<div class="progress-overlay"><div class="spinner-border"</div></div>';
            var m_type = ui.item.attr('data-mtype');
            var type = m_type;
            if(m_type == 'image'){
              type = 'photo';
            }
            jQuery('#media_'+type+'_list_wrapper').append(spinner);
						media_vault_sortable(m_type);
          }
        });
        
      }
    }
  }
})(jQuery, Drupal, drupalSettings);