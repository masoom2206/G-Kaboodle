jQuery( document ).ready(function() {
  jQuery('.favolink').click(function(e) {
    e.preventDefault();
    e.stopPropagation();
    var mid = e.target.id;          
    jQuery.ajax({
      url: "/update-media-favorite",
      data:{"mid":mid},
      type: "POST",
      success:function(result){
        location.reload();        
      }
    });
  });
});