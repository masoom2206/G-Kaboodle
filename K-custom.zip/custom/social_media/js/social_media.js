/**
 * @file
 * Attaches behaviors for the social_media module.
 *
 */
(function ($, Drupal) {
  var initialized;
  Drupal.behaviors.social_media = {
    attach: function (context, settings) {
      if (!initialized) {
				initialized = true;
        var path_userid = drupalSettings.path_userid;
        var media_base_url = drupalSettings.media_base_url;
        var default_media_kit_id = drupalSettings.default_media_kit_id;
        var media_kit_url = media_base_url+"/node/"+default_media_kit_id+"?_format=json";
        var calendarData = drupalSettings.calendarData;
        console.log(calendarData);
        var events = calendarData['events'];
        var userName = calendarData['UserName'];
        var update_post = drupalSettings.update_post;
        console.log(update_post);
         //edit post
         jQuery('#nav-newpost textarea').val(update_post['post_name']);
         jQuery('#nav-newpost #media-kit-options select').val(parseInt(update_post['media_kit_id']));
        
         //initialize full Calendar
         var calendarEl = document.getElementById('calendar');
         var calendar = new FullCalendar.Calendar(calendarEl, {
            timeZone: 'UTC',
            plugins: [ 'interaction', 'dayGrid', 'timeGrid' ],
            defaultView: 'timeGridWeek',
            defaultDate: jQuery.now(),
            customButtons: {
              customUser:{
              theme: 'true',
              text: userName,
              },
              startWeek: {
              theme: 'true',
              text: '*',
              click: function() {
                 jQuery('.week-start-on').toggleClass('hidden');
                  jQuery('.week-start-on input').each(function(){
                   jQuery(this).click(function(){
                    calendar.setOption('firstDay', parseInt(jQuery(this).val()));
                   });
               });
              }
            }
          },
            columnHeaderHtml: function(date) {
              var get_events = calendar.getEvents();
                  var count_post  = 0; 
                   var array_data = []; 
                  jQuery.each(get_events, function(index ,value){
                      if(value.start.toISOString().indexOf(date.toISOString().split("T")[0]) != -1){
                         count_post++;
                        
                       /* var time_first =  value.start.toISOString().split("T")[1].split(":")[0];
                          if(jQuery.inArray(time_first, array_data) !== -1){
                              array_data[time_first] = 1;
                              var row = jQuery(".fc-slats tr:contains()");
                            }
                         else{
                               ++ array_data[time_first];
                             }*/
                      }   
                   });  
                   
                   /*jQuery(".fc-slats tr span:contains('1am')").parent().css("height","200px");*/
              if (date.getUTCDay() === 5) {
                return '<div class="custom-day-formate"><span class="day">Friday</span><span class="count-post">'+count_post+'</span></div><div class="custom-Day">'+date.getUTCDate()+'</div>';
              }
              else if(date.getUTCDay() === 4){
                return '<div class="custom-day-formate"><span class="day">Thursday</span><span class="count-post">'+count_post+'</span></div><div class="custom-Day">'+date.getUTCDate()+'</div>';
             }
              else if(date.getUTCDay() === 3){
                return '<div class="custom-day-formate"><span class="day">Wednesday</span><span class="count-post">'+count_post+'</span></div><div class="custom-Day">'+date.getUTCDate()+'</div>';
             }
              else if(date.getUTCDay() === 2){
                return '<div class="custom-day-formate"><span class="day">Tuesday</span><span class="count-post">'+count_post+'</span></div><div class="custom-Day">'+date.getUTCDate()+'</div>';
             }
              else if(date.getUTCDay() === 1){
                return '<div class="custom-day-formate"><span class="day">Monday</span><span class="count-post">'+count_post+'</span></div><div class="custom-Day">'+date.getUTCDate()+'</div>';
             } 
              else if(date.getUTCDay() === 0){
                return '<div class="custom-day-formate"><span class="day">Sunday</span><span class="count-post">'+count_post+'</span></div><div class="custom-Day">'+date.getUTCDate()+'</div>';
             }      

          else {
                return '<div class="custom-day-formate"><span class="day">Saturday</span><span class="count-post">'+count_post+'</span></div><div class="custom-Day">'+date.getUTCDate()+'</div>';
              }
          },
          columnHeaderFormat:{
            weekday: 'long',
          },
            header: {
              left: 'customUser',
              right: 'today, title, timeGridWeek, prev, next, startWeek'
            },
            eventRender: function(info) {
                var socialMediaIcon =  info.event.extendedProps.socialMediaName.toLowerCase()+'.png';
                //console.log(socialMediaIcon);
                 /*var output = '<div class="wrap"><div class="fc-content"><span class="fc-title">'*/
                info.el.innerHTML = '<div class="wrap"><div class="fc-content"><img alt="linkedin.png" src="/modules/custom/social_media/images/'+socialMediaIcon+'" width="15px"><span class="fc-title">'
                +info.event.extendedProps.socialMediaName + '</span><br><span class="fc-time" data-start="' + info.event.extendedProps.formatedTime + '" data-full="' + info.event.extendedProps.formatedTime + '">'+info.event.extendedProps.formatedTime+' - '+info.event.title+'</span> </div><div class="updatepost">'+info.event.extendedProps.edit+'</div></div>';
                
                //var formated_time = info.event.extendedProps.formatedTime ;
                //console.log(formated_time)
                //var res = formated_time.split(":");
                //console.log(res[0]);
                //jQuery(".fc-slats table tr .fc-widget-content:nth-child(2)").append(output);
                 /* $count = 0;
                  jQuery(".fc-slats table tr:odd td.fc-widget-content:nth-child(2)").each(function(){
                     var dat_time = jQuery(this).parent().attr("data-time");
                     var dat_time_first = dat_time.split(":");
                      //console.log(dat_time_first[0]);
                     if(parseInt(res[0]) == parseInt(dat_time_first[0]) ){
                       $count++;
                       var h = 80 * $count;
                       //jQuery(this).css("height", h);
                     }
                     
                  });
                  var $cal_height = 80 * $count;
                  if ($cal_height ==0){
                    $cal_height = 80;
                  }*/
									
									jQuery('.fc-time-grid-event').each(function(){
										var pt = [];
										var h = jQuery(this).height();
										jQuery('.fc-time-grid-event-inset').each(function(){
											var oldtop = parseInt(jQuery(this).css('top'));
											console.log(oldtop);
											var top = h * 2 + 10;
											jQuery(this).css('top', top);
										});		
									});
									var formated_time = '01:15';
									//console.log(formated_time)
									var res = formated_time.split(":");
									jQuery(".fc-slats table tr:odd td.fc-widget-content:nth-child(2)").each(function(){
									  var dat_time = jQuery(this).parent().attr("data-time");
									  var dat_time_first = dat_time.split(":");
										console.log(dat_time_first[0]);
									  if(parseInt(res[0]) == parseInt(dat_time_first[0]) ){
											jQuery('.fc-event-container').each(function(){
												var maxlen = jQuery(this).children().find('.fc-time-grid-event').length;
												if(maxlen > 1) {
													jQuery(this).children('.fc-time-grid-event').each(function(){
														var arr = []; 
														var height = 0; 
														arr.push(parseInt(jQuery(this).css('top')));
														console.log(arr);
														for (var i = 0; i < arr.length; i++) {
															height += arr[i] << 0;
														}
														console.log(height);
														jQuery(".fc-slats table tr:odd td.fc-widget-content:nth-child(2)").each(function(){
															jQuery(this).css("height", height);
														});
													});
												}
											});
									  }
									});  
                 
            },
            events: events,
          });
          calendar.render();
          calendar.setOption('firstDay', 6);
          calendar.setOption('contentHeight', 'auto');
					
					 jQuery('.fc-event-container').each(function(event){
						/*var len = jQuery(this).find('.fc-time-grid-event').length;
						var tt = jQuery(this).find('.fc-time-grid-event').height();
						var height = tt; 
						if(len > 1){
							var height = tt * len;
						}
						//data-time match
						jQuery('.fc-widget-content').height(height); */
					}); 
          
        //End initialize full Calendar  
				
        //Remote video modal player
        let RemoteVideoModal = React.createClass({
          componentDidMount: function() {
              jQuery(this.getDOMNode()).modal('show');
              jQuery(this.getDOMNode()).on('hidden.bs.modal', this.props.handleHideModal);
          },
          render: function() {
            return (
                React.createElement('div', {id: 'modal', className: 'modal fade'},
                  React.createElement('div', {className: 'modal-dialog'},
                    React.createElement('div', {className: 'modal-content'},
                      React.createElement('iframe', {className: 'remote-video-modal', src: '//www.youtube.com/embed/'+this.props.videolink, 'frameborder':'0', width: '600px', height: '400px'}),
                    )
                  )
                )
              )
          },
          propTypes:{
            handleHideModal: React.PropTypes.func.isRequired
          }
        });
        
        //VideoPlayer Modal
        let VideoPlayer = React.createClass({
          componentDidMount: function() {
              jQuery(this.getDOMNode()).modal('show');
              jQuery(this.getDOMNode()).on('shown.bs.modal', function () {
                jQuery('.modal-video-playing')[0].play();
              });
              jQuery('.modal-video-playing').on("timeupdate", this.props.seektimeupdate);
              jQuery('.modal-video-playing').on("ended", this.props.videoCompleted);
              jQuery(this.getDOMNode()).on('hidden.bs.modal', this.props.handleHideVideoPlayer);
          },
          render: function() {
            return (
              React.createElement('div', {id: 'modal', className: 'modal fade video-modal'},
                React.createElement('div', {className: 'modal-dialog'},
                  React.createElement('div', {className: 'modal-content'},
                    React.createElement('button', {type: 'Button', className: 'close video-close', 'data-dismiss': 'modal'},
                      React.createElement('i', {className:"fa fa-times"},'')
                    ),
                    React.createElement('div', {className: 'spinner-border'}, ''),
                    React.createElement("video", {className: 'modal-video-playing'}, 
                      React.createElement('source', {src:this.props.fileURL},'')
                    ),
                    React.createElement('div', {className:'control-box'},
                      React.createElement('div', {className: 'upper-box col-xl-12 col-md-12'},
                        React.createElement('div', {className: 'row'}, 
                          React.createElement('div', {className: 'col-md-4'}, 
                            React.createElement('i', {className: 'fa fa-volume-down'},''),
                            React.createElement('input', {type: 'Range', className: 'video-volume-control', value: this.props.volume_level, min: 0, max: 1, step: 0.1, onChange: this.props.VVolControl},''),
                            React.createElement('i', {className: 'fa fa-volume-up'},'')
                          ),
                          React.createElement('div', {className: 'col-md-4 text-center'},
                            React.createElement('i', {className: 'fa fa-backward', onClick: this.props.playnowPrev},''),
                            React.createElement('i', {className: this.props.playnowclass, onClick: this.props.playNowVideo},''),
                            React.createElement('i', {className: 'fa fa-forward', onClick: this.props.playnowNext},'')
                          ),
                          React.createElement('div', {className: 'col-md-3'}, '')
                        )
                      ),
                      React.createElement('div', {className: 'lower-box'},
                        React.createElement('span', {id: 'start'}, this.props.curtimetext),
                        React.createElement('input', {type: 'Range', className: 'time-control',min:'0', max:'100', value: this.props.seekslider_value, step:'1', onChange: this.props.vidSeek},''),
                        React.createElement('span', {id: 'end'}, this.props.durtimetext)
                      )
                    )
                  )
                )
              )
            )
          },
          propTypes:{
            handleHideVideoPlayer: React.PropTypes.func.isRequired,
          }
        });
        
        //File extention component
        var AppExtention = React.createClass({
          getInitialState: function() {
            return {
              fileExtension: '',
            }
          },
          componentWillMount: function() {
            var th = this;
            this.serverRequest = 
              axios.get(media_base_url+'/entity/file/'+this.props.fid+'?_format=json')
                .then(function(result) { 
                  th.setState({fileExtension: result.data.filename[0].value});
                })
          },
          componentWillReceiveProps: function(nextProps) {
            if(this.props.fid != nextProps.fid){
              var th = this;
              this.serverRequest = 
                axios.get(media_base_url+'/entity/file/'+nextProps.fid+'?_format=json')
                  .then(function(result) { 
                    th.setState({fileExtension: result.data.filename[0].value});
                  })
            }      
          },
          render: function() {
            var extName = (this.state.fileExtension).split('.').pop();
            if(Boolean(this.props.get_type_col)){
              if(extName == 'jpg' || extName == 'jpeg'){
                extName = 'JPEG file';
              }else if(extName == 'png'){
                extName = 'PNG image';
              }else if(extName == 'NEF'){
                extName = 'Camera Raw Image';
              }else if(extName == 'svg'){
                extName = 'SVG Image';
              }else if(extName == 'gif'){
                extName = 'GIF image';
              }else if(extName == 'pdf'){
                extName = 'Adobe File';
              }else if(extName == 'docx'){
                extName = 'Microsoft Word document';
              }else if(extName == 'txt'){
                extName = 'Plain Text file';
              }else if(extName == 'rtf'){
                extName = 'Rich Text Format document';
              }else if(extName == 'wpd'){
                extName = 'WordPerfect document';
              }else if(extName == 'pages'){
                extName = 'Pages document';
              }
            } 
            return React.createElement('span', {}, extName)
          },
        });
        
        // Audio time/size
        var AudioTime = React.createClass({
          getInitialState: function() {
            return {
              audio_time: '',
            }
          },
          componentWillMount: function() {
            var th = this;
            var audio_time = '-';
            let a = new Audio(this.props.audioURL);
            a.addEventListener('loadedmetadata', (e) => {
              this.setState({audio_time: (e.target.duration).toFixed(2)});
            });
          },
          componentWillReceiveProps: function(nextProps) {
            if(this.props.audioURL != nextProps.audioURL){
              var th = this;
              var audio_time = '-';
              let a = new Audio(nextProps.audioURL);
              a.addEventListener('loadedmetadata', (e) => {
                this.setState({audio_time: (e.target.duration).toFixed(2)});
              });
            }
          },
          render: function() {
            return React.createElement('span', {className: ''}, this.state.audio_time)
          },
        });
        
        //File size
        var AppFileSize = React.createClass({
          getInitialState: function() {
            return {
              value: '-',
            }
          },
          componentWillMount: function() {
            var th = this;
            this.serverRequest = 
              axios.get(media_base_url+'/entity/file/'+this.props.fid+'?_format=json')
                .then(function(result) { 
                  th.setState({value: result.data.filesize[0].value});
                })
          },
          componentWillReceiveProps: function(nextProps) {
            if(this.props.fid != nextProps.fid){
              var th = this;
              this.serverRequest = 
                axios.get(media_base_url+'/entity/file/'+nextProps.fid+'?_format=json')
                  .then(function(result) { 
                    th.setState({value: result.data.filesize[0].value});
                  })
            }      
          },
          render: function() {
            // Convert bytes to kilobytes.
            var units = ['KB','MB','GB','TB','PB','EB','ZB','YB'];
            var bytes = this.state.value;
            if(bytes <= 0){
              bytes = bytes + " bytes";
             }else{
              bytes = bytes / 1024;
              for(i= 0; i< units.length; i++){
                if (bytes.toFixed(2) >= 1024) {
                  bytes = bytes / 1024;
                }
                else {
                  bytes = bytes.toFixed(2);
                  break;
                }
              }
              bytes = bytes +' '+ units[i];
             }
            return React.createElement('span', {className: ''}, bytes)
          },
        });
        
        //Media Filename
        var AppFileName = React.createClass({
          getInitialState: function() {
            return {
              value: '-',
            }
          },
          componentWillMount: function() {
            var th = this;
            this.serverRequest = 
              axios.get(media_base_url+'/entity/file/'+this.props.fid+'?_format=json')
                .then(function(result) { 
                  th.setState({value: result.data.filename[0].value});
                })
          },
          componentWillReceiveProps: function(nextProps) {
            if(this.props.fid != nextProps.fid){
              var th = this;
              this.serverRequest = 
                axios.get(media_base_url+'/entity/file/'+nextProps.fid+'?_format=json')
                  .then(function(result) { 
                    th.setState({value: result.data.filename[0].value});
                  })
            }    
          },
          render: function() {
            return React.createElement('span', {}, this.state.value)
          },
        });
        
        //Text Reader Modal
        let textReader = React.createClass({
          componentDidMount: function() {
              jQuery(this.getDOMNode()).modal('show');
              jQuery(this.getDOMNode()).on('hidden.bs.modal', this.props.hideTextReaderModal);
          },
          render: function() {
            return (
                React.createElement('div', {id: 'modal', className: 'modal fade text-reader'},
                  React.createElement('div', {className: 'modal-dialog'},
                    React.createElement('div', {className: 'modal-content'},
                      React.createElement('div', {className: 'modal-body'},
                        React.createElement('iframe', {className: 'text', src: 'https://docs.google.com/gview?url='+this.props.textFileURL+'&embedded=true', width: '100%', height: '500px'})
                      ),
                    )
                  )
                )
              )
          },
          propTypes:{
            hideTextReaderModal: React.PropTypes.func.isRequired
          }
        });
        
        //Audio kit data secion
        var AppAudiokit = React.createClass({
          getInitialState: function() {
             return {
              audios: [],
            }
          },
          componentWillMount: function() {
            var th = this;
            this.serverRequest = 
              axios.get(media_kit_url)
                .then(function(result) {    
                    return result.data.field_vault_audio;
                })
                .then(function(response) {
                   return Promise.all(response.map( (record, index) => {
                     return axios.get(media_base_url+'/media/'+record.target_id+'/edit?_format=json');
                   }))
                })
                .then(function(responsex) {
                  th.setState({audios: responsex});
                });            
          },
          componentWillUnmount: function() {
            this.serverRequest.abort();
          },
          render: function() {
            jQuery('#transfer-box button').removeAttr('disabled');
            var items = this.state.audios.map((item, key) => {
              
              //File type
              let app_extention = React.createElement(AppExtention, {fid: item.data.field_media_audio_file[0].target_id, get_type_col: false});
              
              //Audio Time
              let audio_time = React.createElement(AudioTime, {audioURL: item.data.field_media_audio_file[0].url})
              
              //File size
              let file_size = React.createElement(AppFileSize, {fid: item.data.field_media_audio_file[0].target_id});
              
              return React.createElement('tr', {className:'audio-row'},
                React.createElement('td', {className: 'audio-data'},
                  React.createElement('label', {className: 'checkbox-container'},
                    React.createElement('input',{type: 'checkbox', id: 'audio-kit-check-'+key, className: 'box-check', 'data-mid': item.data.mid[0].value, 'value': item.data.mid[0].value}),
                    React.createElement('span', {className: 'checkmark'}),
                  )
                ),
                React.createElement('td', {className: 'audio-data'},
                  React.createElement('div', {className: 'audio-box'},
                    React.createElement("audio", {id: 'audio-kit-'+key, controls:"controls", style:{width: '0px', height: '0px', visibility:'hidden'}}, 
                      React.createElement('source', {src:item.data.field_media_audio_file[0].url},'')
                    ),
                    React.createElement('button', {type: 'button', className: 'audio-play-button', onClick: this.playAudio.bind(null, this, 'audio-kit-'+key, 'volCol-'+key)},''),
                    React.createElement('div', {className:'vol-box'},
                      React.createElement('div', {className:'vol-box-inner'},
                        React.createElement('input', {type: 'range', id:'volCol-kit-'+key, className: 'volume-control', min: 0, max: 1, step: 0.1, value: this.state.value, onChange: this.kbVolControl.bind(null, this, 'audio-kit-'+key, 'volCol-'+key)}),
                        React.createElement('i', {className:'fa fa-volume-up', onClick: this.kbmute.bind(null, this, 'audio-kit-'+key, 'volCol-kit-'+key)},'')
                      )
                    )
                  ),
                ),
								React.createElement('td', {className: 'audio-data media-file-name'}, item.data.name[0].value),
                React.createElement('td', {className: 'audio-data'}, app_extention),
                React.createElement('td', {className: 'audio-data'}, audio_time),
                React.createElement('td', {className: 'audio-data'}, file_size),
              )
            });
            
            var table_head = React.createElement('thead',{},
              React.createElement('tr', null,
                React.createElement('th', null, ),
                React.createElement('th', null, ),
                React.createElement('th', null, 'Title'),
                React.createElement('th', null, 'Format'),
                React.createElement('th', null, 'Duration'),
                React.createElement('th', null, 'Size'),
              )
            );
            
            var table_body = React.createElement('tbody', null, items);
            
            var updatediv = React.createElement('div', {className: 'd-none', id: 'audio-kit-refresh', onClick: this.UpdateMethod.bind()}, 'refresh');
            
            var table_data = React.createElement('table',{className: 'media-table'},table_head,table_body);
            
            return (
              //React.createElement('h3', null, 'Hello1')
              //React.createElement('table',{className: 'media-table'},table_head,table_body)
              React.createElement("div", {}, table_data, updatediv)
            )
          },
          UpdateMethod: function() {
            //Force a render with a simulated state change
            media_kit_id = jQuery('#mediakitid').val();
            media_kit_url = media_base_url+"/node/"+media_kit_id+"?_format=json";
            var th = this;
            this.serverRequest = 
              axios.get(media_kit_url)
                .then(function(result) {    
                    return result.data.field_vault_audio;
                })
                .then(function(response) {
                   return Promise.all(response.map( (record, index) => {
                     return axios.get(media_base_url+'/media/'+record.target_id+'/edit?_format=json');
                   }))
                })
                .then(function(responsex) {
                  th.setState({audios: responsex});
                });
          },
          playAudio: function(appInstance, id, idcontrol) {
            //Pause all audio
            var kbAudio = document.getElementById(id);
            var audios = document.getElementsByTagName('audio');
            var sound = document.getElementById(idcontrol);
            kbAudio.volume = 1;
            jQuery(sound).css('background-image',
              '-webkit-gradient(linear, left top, right top, '
              + 'color-stop(' + kbAudio.volume + ', #fe5819), '
              + 'color-stop(' + kbAudio.volume + ', #ccc)'
              + ')'
            );
            appInstance.setState({value: 1})
            for(var i = 0, len = audios.length; i < len;i++){
              if(audios[i] != kbAudio){
                audios[i].pause();
                jQuery(audios[i]).parent().removeClass('playing');
                jQuery(audios[i]).parent().addClass('pause');
              }else if (kbAudio.duration > 0 && !kbAudio.paused) {
                kbAudio.pause();
               jQuery(audios[i]).parent().removeClass('playing');
               jQuery(audios[i]).parent().addClass('pause');
              }else if( kbAudio.duration > 0 && kbAudio.paused ) {
                kbAudio.play();
                jQuery(audios[i]).parent().removeClass('pause');
                jQuery(audios[i]).parent().addClass('playing');
              }
            }
          },
          kbVolControl: function(appInstance, idaudio, idcontrol) {
            var sound = document.getElementById(idcontrol);
            document.getElementById(idaudio).volume = sound.value;
            appInstance.setState({value: sound.value})
            jQuery(sound).css('background-image',
              '-webkit-gradient(linear, left top, right top, '
              + 'color-stop(' + sound.value + ', #fe5819), '
              + 'color-stop(' + sound.value + ', #ccc)'
              + ')'
            );
          },
          kbmute: function(appInstance, idaudio, idcontrol){
            var mutedVol = 0;
            var kbAudio = document.getElementById(idaudio);
            var sound = document.getElementById(idcontrol);
            kbAudio.muted = !kbAudio.muted;
            if(!kbAudio.muted){
              appInstance.setState({value: kbAudio.volume});
              jQuery(sound).css('background-image',
                '-webkit-gradient(linear, left top, right top, '
                + 'color-stop(' + kbAudio.volume + ', #fe5819), '
                + 'color-stop(' + kbAudio.volume + ', #ccc)'
                + ')'
              );
            }else{
              appInstance.setState({value: mutedVol});
              jQuery(sound).css('background-image',
                '-webkit-gradient(linear, left top, right top, '
                + 'color-stop('+ mutedVol +', #fe5819), '
                + 'color-stop('+ mutedVol +', #ccc)'
                + ')'
              );
            }
          }
        });  
        React.render(
          React.createElement(AppAudiokit, {}), document.querySelector("#audio-kit-content-section")
        );
        
        //Photo Kit data secion
        var AppPhotokit = React.createClass({
          getInitialState: function() {
            return {
              photos: [],
            }
          },
          componentWillMount: function(){
            var th = this;
            this.serverRequest = 
              axios.get(media_kit_url)
                .then(function(result) {    
                    return result.data.field_vault_photo;
                })
                .then(function(response) {
                   return Promise.all(response.map( (record, index) => {
                     return axios.get(media_base_url+'/media/'+record.target_id+'/edit?_format=json');
                   }))
                })
                .then(function(responsex) {
                  th.setState({photos: responsex});
                });   
          },
          componentWillUnmount: function() {
            this.serverRequest.abort();
          },
          render: function() {
            jQuery('#transfer-box button').removeAttr('disabled');
            var counter = 0;
            var items = this.state.photos.map((item, key) => {
                counter += 1;
                //File name
                let file_name = React.createElement(AppFileName, {fid: item.data.field_media_image[0].target_id});
                
                //File type
                let app_extention = React.createElement(AppExtention, {fid: item.data.field_media_image[0].target_id, get_type_col: false});
                
                //File size
                let file_size = React.createElement(AppFileSize, {fid: item.data.field_media_image[0].target_id});

                return React.createElement('tr', {className:'media-row',  'data-exthumbimage': item.data.field_media_image[0].image_style, 'data-src': item.data.field_media_image[0].url},
                  React.createElement('td', {className: 'media-data text-center'},
                    React.createElement('label', {className: 'checkbox-container'},
                      React.createElement('input',{type: 'checkbox', id: 'audio-kit-check-'+key, className: 'box-check', 'data-mid': item.data.mid[0].value, 'value': item.data.mid[0].value}),
                      React.createElement('span', {className: 'checkmark'}),
                    )
                  ),
                  React.createElement('td', {className: 'media-data media-data-col-name'},
                    React.createElement("div", {id: key, className:"media-box"}, 
                      React.createElement('img', {src:item.data.field_media_image[0].image_style}),
                      React.createElement('div', {className: 'overlay'},
                        React.createElement('button', {type: 'button', className: 'preview-icon', onClick: this.ShowPhotomodal.bind()}, '')
                      )
                    )
                  ),
                  React.createElement('td', {className: 'media-data media-file-name'}, file_name),
                  React.createElement('td', {className: 'media-data'}, app_extention),
                  React.createElement('td', {className: 'media-data'}, file_size),
                )
            });
            
            var table_head = React.createElement('thead',{},
              React.createElement('tr', null,
                React.createElement('th', null, ),
								React.createElement('th', null, ),
                React.createElement('th', null, 'Title'),
                React.createElement('th', null, 'Format'),
                React.createElement('th', null, 'Size'),
              )
            );
            var table_body = React.createElement('tbody', {id: 'media_kit_photo_gallery'}, items);
            
            var updatediv = React.createElement('div', {className: 'd-none', id: 'photo-kit-refresh', onClick: this.UpdateMethod.bind()}, 'refresh');
            
            var table_data = React.createElement('table',{className: 'media-table'},table_head,table_body);
            
            return (
             // React.createElement('table',{className: 'media-table'},table_head,table_body)
             React.createElement("div", {}, table_data, updatediv)
            );
          },
          UpdateMethod: function() {
            //Force a render with a simulated state change
            media_kit_id = jQuery('#mediakitid').val();
            media_kit_url = media_base_url+"/node/"+media_kit_id+"?_format=json";
            var th = this;
            this.serverRequest = 
              axios.get(media_kit_url)
                .then(function(result) {    
                    return result.data.field_vault_photo;
                })
                .then(function(response) {
                   return Promise.all(response.map( (record, index) => {
                     return axios.get(media_base_url+'/media/'+record.target_id+'/edit?_format=json');
                   }))
                })
                .then(function(responsex) {
                  th.setState({photos: responsex});
                });
          },
          ShowPhotomodal: function(e){
            var $gallery = jQuery('#media_kit_photo_gallery').lightGallery({
              width: '880px',
              height: '720px',
              addClass: 'fixed-size',
              counter: false,
              download: false,
              enableSwipe: false,
              enableDrag: false,
              download: false,
              share: false,
              autoplay: false,
              thumbMargin : 17,
              autoplayControls: false,
              fullScreen: false,
              zoom: false,
              actualSize: false,
              toogleThumb: false,
              thumbWidth: 94,
              thumbContHeight: 118,
              exThumbImage: 'data-exthumbimage',
            });
						jQuery(e.target).trigger('click');
            $gallery.on('onCloseAfter.lg',function(event, index, fromTouch, fromThumb){
              try{$gallery.data('lightGallery').destroy(true);}catch(ex){};
            });
          }
        });
        React.render(
          React.createElement(AppPhotokit, {}), document.querySelector("#photo-kit-content-section")
        );
        
         //Text data secion
        var AppTextKit = React.createClass({
          getInitialState: function() {
            return {
              texts: [],
              showTextModal: false,
              textFileURL: '',
              mid: '',
            }
          },
          componentWillMount: function() {
            var th = this;
            this.serverRequest = 
              axios.get(media_kit_url)
                .then(function(result) {    
                    return result.data.field_vault_file;
                })
                .then(function(response) {
                   return Promise.all(response.map( (record, index) => {
                     return axios.get(media_base_url+'/media/'+record.target_id+'/edit?_format=json');
                   }))
                })
                .then(function(responsex) {
                  th.setState({texts: responsex});
                });
          },
          componentWillUnmount: function() {
            this.serverRequest.abort();
          },   
          render: function() {
            jQuery('#transfer-box button').removeAttr('disabled');
            if (this.state.showTextModal) {
              var textReaderElement = React.createElement(textReader, {hideTextReaderModal: this.hideTextReaderModal, textFileURL: this.state.textFileURL});
            }
            var items = this.state.texts.map((item, key) => {
                //File name
                let file_name = React.createElement(AppFileName, {fid: item.data.field_media_file[0].target_id});
                //File type
                let app_extention = React.createElement(AppExtention, {fid: item.data.field_media_file[0].target_id, get_type_col: true});
                //File size
                let file_size = React.createElement(AppFileSize, {fid: item.data.field_media_file[0].target_id});

                return React.createElement('tr', {className:'media-row'},
                  React.createElement('td', {className: 'media-data text-center'},
                    React.createElement('label', {className: 'checkbox-container'},
                      React.createElement('input',{type: 'checkbox', id: 'audio-kit-check-'+key, className: 'box-check', 'data-fid': item.data.field_media_file[0].target_id, 'data-mid': item.data.mid[0].value, 'value': item.data.mid[0].value}),
                      React.createElement('span', {className: 'checkmark'}),
                    )
                  ),
                  React.createElement('td', {className: 'media-data media-data-col-name'},
                    React.createElement("div", {id: key, className:"media-box text-box"}, 
                      React.createElement('button', {type: 'button', className: 'text-read-button', onClick: this.showTextModal.bind(null,item.data.field_media_file[0].url)},''),
                    )
                  ),
                  React.createElement('td', {className: 'media-data media-file-name'}, file_name),
                  React.createElement('td', {className: 'media-data'}, app_extention),
                  React.createElement('td', {className: 'media-data'}, file_size),
                )
            });
            var table_head = React.createElement('thead',{},
              React.createElement('tr', null,
                React.createElement('th', null, ),
								React.createElement('th', null, ),
                React.createElement('th', null, 'Title'),
                React.createElement('th', null, 'Format'),
                React.createElement('th', null, 'Size'),
              )
            );
            var table_body = React.createElement('tbody', null, items);
            
            var updatediv = React.createElement('div', {className: 'd-none', id: 'text-kit-refresh', onClick: this.UpdateMethod.bind()}, 'refresh');
            
            var table_data = React.createElement('table',{className: 'media-table'},table_head,table_body);

            return ( 
             // React.createElement('table',{className: 'media-table'},table_head,table_body, textReaderElement)
             React.createElement("div", {}, table_data, updatediv, textReaderElement)
            );
          },
          UpdateMethod: function() {
            media_kit_id = jQuery('#mediakitid').val();
            media_kit_url = media_base_url+"/node/"+media_kit_id+"?_format=json";
            var th = this;
            this.serverRequest = 
              axios.get(media_kit_url)
                .then(function(result) {    
                    return result.data.field_vault_file;
                })
                .then(function(response) {
                   return Promise.all(response.map( (record, index) => {
                     return axios.get(media_base_url+'/media/'+record.target_id+'/edit?_format=json');
                   }))
                })
                .then(function(responsex) {
                  th.setState({texts: responsex});
                });
          },
          showTextModal: function(fileURL){
            this.setState({showTextModal: true});
            this.setState({textFileURL: fileURL });
          },
          hideTextReaderModal: function(){
            this.setState({showTextModal: false});
            this.setState({textFileURL: '' });
          }
        });
        React.render(
          React.createElement(AppTextKit, {}), document.querySelector("#text-kit-content-section")
        );
        
        //Video data secion
         var AppVideoKit = React.createClass({
          getInitialState: function() {
            return {
              video: [],
              showModal: false,
              singlecheckVideo: false,
              fileType: '',
              fileURL: '',
              mid: '',
              base_url: media_base_url,
              videoplayer: false,
              nextVideoTrack: 0,
              totalCount: 0,
              playnowclass : 'fa fa-pause col-md-6',
              playnow_status: true,
              volume_level: 1,
              seekslider_value: 0,
              curtimetext: '0:00',
              durtimetext: '0:00',
            }
          },
          componentWillMount: function() {
            var th = this;
            this.serverRequest = 
              axios.get(media_kit_url)
                .then(function(result) {    
                    return result.data.field_vault_video;
                })
                .then(function(response) {
                   return Promise.all(response.map( (record, index) => {
                     return axios.get(media_base_url+record.url +'?_format=json');
                   }))
                })
                .then(function(responsex) {
                  th.setState({video: responsex});
                });
          },
          componentWillUnmount: function() {
            this.serverRequest.abort();
          },
          
          render: function() {
            jQuery('#transfer-box button').removeAttr('disabled');
           
            if (this.state.videoplayer) {
              var videoPlayerElement = React.createElement(VideoPlayer, {
                                          handleHideVideoPlayer: this.handleHideVideoPlayer,
                                          playNowVideo: this.playNowVideo,
                                          fileURL: this.state.fileURL,
                                          VVolControl: this.VVolControl,
                                          playnowclass: this.state.playnowclass,
                                          playnowNext: this.playnowNext,
                                          playnowPrev: this.playnowPrev,
                                          vidSeek: this.vidSeek,
                                          seektimeupdate: this.seektimeupdate,
                                          volume_level: this.state.volume_level,
                                          seekslider_value: this.state.seekslider_value,
                                          curtimetext: this.state.curtimetext,
                                          durtimetext: this.state.durtimetext,
                                          videoCompleted: this.videoCompleted});
            }
            const rowLen = this.state.video.length;
            var items = this.state.video.map((item, key) => {
                //File name
                let file_name = React.createElement(AppFileName, {fid: item.data.field_media_video_file[0].target_id});
                
                //File type
                let app_extention = React.createElement(AppExtention, {fid: item.data.field_media_video_file[0].target_id, get_type_col: false});
                
                //File size
                let file_size = React.createElement(AppFileSize, {fid: item.data.field_media_video_file[0].target_id});

                return React.createElement('tr', {className:'media-row'},
                  React.createElement('td', {className: 'media-data text-center'},
                    React.createElement('label', {className: 'checkbox-container'},
                      React.createElement('input',{type: 'checkbox', id: 'audio-kit-check-'+key, className: 'box-check', 'data-mid': item.data.mid[0].value, 'value': item.data.mid[0].value}),
                      React.createElement('span', {className: 'checkmark'}),
                    )
                  ),
                  React.createElement('td', {className: 'media-data media-data-col-name'},
                    React.createElement("div", {id: key, className:"media-box"}, 
                      React.createElement("video", {id: 'video-kit-'+key}, 
                        React.createElement('source', {src:item.data.field_media_video_file[0].url},'')
                      ),
                      React.createElement('div', {className: 'overlay'},
                        React.createElement('button', {type: 'button', className: 'video-play round-button', onClick: this.ShowVideoPlayer.bind(null, item.data.field_media_video_file[0].url, +key, +rowLen), style:{'display':'none'}}, ''),
                      )
                    )
                  ),
                  React.createElement('td', {className: 'media-data media-file-name'}, file_name),
                  React.createElement('td', {className: 'media-data'}, app_extention),
                  React.createElement('td', {className: 'media-data'}, file_size),
                )
            });
            var table_head = React.createElement('thead',{},
              React.createElement('tr', null,
                React.createElement('th', null, ),
								React.createElement('th', null, ),
                React.createElement('th', null, 'Title'),
                React.createElement('th', null, 'Format'),
                React.createElement('th', null, 'Size'),
              )
            );
            var table_body = React.createElement('tbody', null, items);
            
            var updatediv = React.createElement('div', {className: 'd-none', id: 'video-kit-refresh', onClick: this.UpdateMethod.bind()}, 'refresh');
            
            var table_data = React.createElement('table',{className: 'media-table'},table_head,table_body);
            
            return ( 
              //React.createElement('table',{className: 'media-table'},table_head,table_body, videoPlayerElement, spinner_process)
              React.createElement("div", {}, table_data, updatediv, videoPlayerElement)

            );
          },
          UpdateMethod: function() {
            //Force a render with a simulated state change
            media_kit_id = jQuery('#mediakitid').val();
            media_kit_url = media_base_url+"/node/"+media_kit_id+"?_format=json";
            var th = this;
            this.serverRequest = 
              axios.get(media_kit_url)
                .then(function(result) {    
                    return result.data.field_vault_video;
                })
                .then(function(response) {
                   return Promise.all(response.map( (record, index) => {
                     return axios.get(media_base_url+record.url +'?_format=json');
                   }))
                })
                .then(function(responsex) {
                  th.setState({video: responsex});
                });
          },
          ShowVideoPlayer: function(fileURL, trackID, rowLen){
            this.setState({videoplayer: true});
            this.setState({fileURL: fileURL});
            this.setState({nextVideoTrack: trackID});
            this.setState({totalCount: rowLen});
          },
          handleHideVideoPlayer: function(){
            this.setState({videoplayer: false});
            this.setState({nextVideoTrack: 0});
            this.setState({totalCount: 0});
            this.setState({curtimetext: '0:00'});
            this.setState({durtimetext: '0:00'});
          },
          playNowVideo: function(){
            if(this.state.playnow_status){
              jQuery('.modal-video-playing')[0].pause();
              this.setState({playnow_status: false});
              this.setState({playnowclass :'fa fa-play col-md-6'});
            }else{
              jQuery('.modal-video-playing')[0].play();
              this.setState({playnow_status: true});
              this.setState({playnowclass :'fa fa-pause col-md-6'});
            }
          },
          VVolControl: function() {
            var sound = document.getElementsByClassName("video-volume-control");
            jQuery('.modal-video-playing')[0].volume = sound[0].value;
            this.setState({volume_level: sound[0].value})
            jQuery(sound).css('background-image',
              '-webkit-gradient(linear, left top, right top, '
              + 'color-stop(' + sound[0].value + ', #4f6ab7), '
              + 'color-stop(' + sound[0].value + ', #ccc)'
              + ')'
            );
          },
          playnowNext: function(){
            var nextid = this.state.nextVideoTrack;
            var totalCount = this.state.totalCount;
            var nexturl = '';
            nextid++;
            if(totalCount <= nextid){
              totalCount--;
              nexturl = jQuery('#video-'+totalCount+' source').attr('src');
              this.setState({nextVideoTrack: +totalCount});
            }else{
              nexturl = jQuery('#video-'+nextid+' source').attr('src');
              this.setState({nextVideoTrack: +nextid});
            }
            jQuery('.modal-video-playing')[0].src = nexturl;
            jQuery('.modal-video-playing')[0].play();
            this.setState({playnow_status: true});
            this.setState({playnowclass :'fa fa-pause col-md-6'});
          },
          playnowPrev: function(){
            var previd = this.state.nextVideoTrack;
            var prevurl = '';
            previd--;
            if(previd < 0){
              prevurl = jQuery('#video-0 source').attr('src');
              this.setState({nextVideoTrack: 0});
            }else{
              prevurl = jQuery('#video-'+previd+' source').attr('src');
              this.setState({nextVideoTrack: +previd});
            }
            jQuery('.modal-video-playing')[0].src = prevurl;
            jQuery('.modal-video-playing')[0].play();
            this.setState({playnow_status: true});
            this.setState({playnowclass :'fa fa-pause col-md-6'});
          },
          vidSeek: function(){
            var vid = jQuery('.modal-video-playing')[0];
            var seekslider = document.getElementsByClassName("time-control");
            var seekto = vid.duration * (seekslider[0].value / 100);
            vid.currentTime = seekto;
            this.setState({seekslider_value: seekslider[0].value});
          },
          seektimeupdate: function(){
            if(this.state.videoplayer){
              var vid = jQuery('.modal-video-playing')[0];
              var nt = vid.currentTime * (100 / vid.duration);
              this.setState({seekslider_value: +nt});
              var curmins = Math.floor(vid.currentTime / 60);
              var cursecs = Math.floor(vid.currentTime - curmins * 60);
              var durmins = Math.floor(vid.duration / 60);
              var dursecs = Math.floor(vid.duration - durmins * 60);
              if(cursecs < 10){ cursecs = "0"+cursecs; }
              if(dursecs < 10){ dursecs = "0"+dursecs; }
              if(curmins < 10){ curmins = "0"+curmins; }
              if(durmins < 10){ durmins = "0"+durmins; }
              var start = curmins+":"+cursecs;
              var end = durmins+":"+dursecs;
              this.setState({curtimetext: start});
              this.setState({durtimetext: end});
            }
          },
          videoCompleted: function(){
            this.setState({playnow_status: false});
            this.setState({playnowclass :'fa fa-play col-md-6'});
          }       
        });
        React.render(
          React.createElement(AppVideoKit, {}), document.querySelector("#video-kit-content-section")
        );
        
        //Remote Video Kit data secion
        var AppRemoteVideoKit = React.createClass({
          getInitialState: function() {
            return {
              remotevideo: [],
              remoteVideoModal: false,
              fileType: '',
              mid: '',
              videolink: '',
            }
          },
          componentDidMount: function() {
            var th = this;
            this.serverRequest = 
              axios.get(media_kit_url)
                .then(function(result) {    
                    return result.data.field_vault_remote_video;
                })
                .then(function(response) {
                   return Promise.all(response.map( (record, index) => {
                     return axios.get(media_base_url+record.url +'?_format=json');
                   }))
                })
                .then(function(responsex) {
                  th.setState({remotevideo: responsex});
                });
          },
          componentWillUnmount: function() {
            this.serverRequest.abort();
          },
          render: function() {
            jQuery('#transfer-box button').removeAttr('disabled');
            jQuery('#media-kit-modal').modal('hide');
            
            var counter = 0;
            if (this.state.remoteVideoModal) {
              var remote_video_modalElement = React.createElement(RemoteVideoModal, {handleHideModal: this.handleHideModal, videolink: this.state.videolink});
            }

            var items = this.state.remotevideo.map((item, key) => {
              counter += 1;
              var videolink = item.data.field_media_oembed_video[0].value;
              var regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
              var match = videolink.match(regExp);
              if (match && match[2].length == 11) {
                videolink = match[2];
              } else {
                videolink = '';
              }

              return React.createElement("div", {id: key, className:"video-box col-lg-6"},
                React.createElement("div", {className:"video-div mb-3"},
                  React.createElement('iframe', {className: 'remote-video', src: '//www.youtube.com/embed/'+videolink, 'frameborder':'0', width: '100%', height: '117px'}),
                  React.createElement('div', {className: 'overlay'},
                    React.createElement('label', {className: 'checkbox-container'},
                      React.createElement('input',{type: 'checkbox', id: 'remote-kit-check-'+key, className: 'box-check', 'data-mid': item.data.mid[0].value, 'value': item.data.mid[0].value}),
                      React.createElement('span', {className: 'checkmark'}),
                    ),
                    React.createElement('button', {type: 'button', className: 'tag round-button'}, ''),
                    React.createElement('button', {type: 'button', className: 'video-play round-button', onClick: this.ShowRemoteVideoPlayer.bind(null, videolink), style:{'display':'none'}}, ''),
                    React.createElement('button', {type: 'button', className: 'weight round-button'}, +counter)
                  )
                )
              )
            });
            
            var updatediv = React.createElement('div', {className: 'd-none', id: 'remote-kit-refresh', onClick: this.UpdateMethod.bind()}, 'refresh');
            
            return ( 
              React.createElement("div", {id: "media_remote_video_kit_list_wrapper", className:"row p-3 m-0"}, items, remote_video_modalElement, updatediv) 
            );
          },
          UpdateMethod: function() {
            //Force a render with a simulated state change
            media_kit_id = jQuery('#mediakitid').val();
            media_kit_url = media_base_url+"/node/"+media_kit_id+"?_format=json";
           var th = this;
            this.serverRequest = 
              axios.get(media_kit_url)
                .then(function(result) {    
                    return result.data.field_vault_remote_video;
                })
                .then(function(response) {
                   return Promise.all(response.map( (record, index) => {
                     return axios.get(media_base_url+record.url +'?_format=json');
                   }))
                })
                .then(function(responsex) {
                  th.setState({remotevideo: responsex});
                });
          },
          ShowRemoteVideoPlayer: function(videolink){
            this.setState({remoteVideoModal: true});
            this.setState({videolink: videolink});
          }
        });
        React.render(
          React.createElement(AppRemoteVideoKit, {}), document.querySelector("#remote-kit-content-section")
        );
        
				//Media Kits select options
        var AppMediaOptions = React.createClass({
          getInitialState: function() {
            return {
              mediakits: [],
            }
          },
          componentWillMount: function() {
            var th = this;
            this.serverRequest = 
              axios.get(media_base_url+'/user/media_kits/'+path_userid)
                .then(function(result) {    
                  th.setState({mediakits: result.data});
                });
          },
          componentWillUnmount: function() {
            this.serverRequest.abort();
          },
          render: function() {
            var options = this.state.mediakits.map((item, key) => {
              return React.createElement('option', {value: item.nid}, item.title
              )
            });
            
            return ( 
              React.createElement("select", {className: 'w-100 rounded', onChange: this.ChooseMediaKit.bind()}, options)
            );
          },
          ChooseMediaKit: function(e) {
            var mediakit_id = e.target.value;     
            jQuery('#media-kit-modal').modal('show');
            jQuery('#mediakitid').val(mediakit_id);
            
            //refresh all tabs and change title under right side kit
            jQuery("#audio-kit-refresh").trigger('click');
            jQuery("#photo-kit-refresh").trigger('click');
            jQuery("#text-kit-refresh").trigger('click');
            jQuery("#video-kit-refresh").trigger('click');
            jQuery("#remote-kit-refresh").trigger('click');
          }
        });
        React.render(
          React.createElement(AppMediaOptions, {}), document.querySelector("#media-kit-options")
        );
        
        //ON/Off toggle button
        jQuery('.slider-toggle input').on('change', function() {
          if (jQuery(this).is(":checked")) {
            jQuery(this).parents('.slider-toggle').find('span').text('On');
            jQuery(this).parents('.slider-toggle').find('span').addClass('btnon'); 
            //jQuery(this).parents('.slider-toggle').find('span').removeClass('btnoff'); 
            jQuery("#post-now").text('SCHEDULE');
            }
          else {
            jQuery(this).parents('.slider-toggle').find('span').text('Off');
            //jQuery(this).parents('.slider-toggle').find('span').addClass('btnoff'); 
            jQuery(this).parents('.slider-toggle').find('span').removeClass('btnon');
            jQuery("#post-now").text('POST NOW');
          }
        });
        
        /*datetimepicker*/
        jQuery('#datetimepicker').datetimepicker({
          //format:'F d, Y H:i a',
          step:15,
          minDate: 0,
          minTime:0,
          todayButton	: false,
          defaultSelect	: false,
          yearStart: (new Date).getFullYear(),
          inline: true,
          onChangeDateTime:function(current_time,$input){
            if (new Date(current_time) <= new Date()) {
              jQuery('#datetimepicker').val('');
              alert('Scheduled time should be greater than the current time.');
            }
          },
          onSelect: function(dateText) {
            jQuery(this).change();
         }
        }).on('change', function() {
           	if(jQuery('#manual_check').is(':checked')){
	            jQuery('#auto-schedule-submit').removeClass('disabled');
	          }
	          else{
	            jQuery('#auto-schedule-submit').addClass('disabled');
	          }
        });
        
         /*timepicker*/
        jQuery('#schedule_time').datetimepicker({
          format:'H:i',
          datepicker:false,
          step:15,
          inline: true,
          onSelect: function(Text) {
              jQuery(this).change();
         }
        }).on('change', function() {
            if(jQuery('#auto_check').is(':checked')){
              jQuery('#auto-schedule-submit').removeClass('disabled');
            }
            else{
              jQuery('#auto-schedule-submit').addClass('disabled');
              
            }
        });
				
        //Every Weekday selector
        jQuery('body').on('click', '.setweekly', function() {
          jQuery('.setweekly').removeClass('xdsoft_current');
          jQuery(this).addClass('xdsoft_current'); 
        });
        
        //SCHEDULE SETTINGS submit button
        jQuery('body').on('click', '#auto-schedule-submit', function() {
          var valid = true;
          var error_msg = '';
          var radio = jQuery("input[name='settings']:checked").attr("id");
          console.log(radio);
          if(radio == 'manual_check'){
            var datetimepicker = jQuery("#datetimepicker").val();
            if(!datetimepicker){
              error_msg = "Choose date/time !";
              valid = false;
            }
          }
          else if(radio == 'auto_check'){
            //get selection type
            var type = jQuery('#auto_check_select').find(":selected").val();
            if(type){
              //get selected days
              var days = jQuery('#weekdays .xdsoft_current').map(function() {
                          return jQuery(this).data('weekday')
                        }).get();
              console.log(days); 
              //get selected time    
              var time = jQuery("#schedule_time").val();          
              
              if(type == 'daily'){}
              else if(type == 'weekday'){}
              else if(type == 'weekly'){
                if(days == ""){
                  error_msg = "Select any day !";
                  valid = false;
                }
              }
              else if(type == 'biweekly'){}
              else if(type == 'monthly'){}
              
              if(!time){
                error_msg = "Select any time slot !";
                valid = false;
              }
            }else{
              error_msg = "Please make a selection !";
              valid = false;
            }
          }
          else{
            error_msg = "Choose any one option !";
            valid = false;
          }       
          
          jQuery("#auto-Schedule-modal .modal-body").find('.alert').remove();
          if(valid){
          //console.log(jQuery('.socialmedia-title span').text());
            jQuery('#auto-Schedule-modal button').removeClass('disabled');
            jQuery.ajax({
              url: "/save-schedule-settings",
              data:{
                "uid":path_userid,
                "schedule_type":radio,
                "manual_datetime":datetimepicker,
                "auto_select":type,
                "auto_day":days,
                "auto_time":time,
                "media_kit_id":jQuery('#media-kit-options select').find(":selected").val(),
                "social_media_name":jQuery('.socialmedia-title span').text(),
                "text":jQuery('#nav-newpost textarea').val(),
                "status":'Draft',
                "action":'schedule',
              },
              type: "POST",
              success:function(data){
                //console.log(data);
                jQuery("#auto-Schedule-modal .modal-body").prepend('<div class="alert alert-success">Settings saved successfully.</div>');
                jQuery('#auto-Schedule-modal button').prop('disabled', false);
                jQuery('#gear .switch').removeClass('disable');
                jQuery('#gear .btnenbl').removeClass('btnoff');
                jQuery('#auto-Schedule-modal').modal('hide');                
              }
            });
          }
          else{
            jQuery("#auto-Schedule-modal .modal-body").prepend('<div class="alert alert-danger" role="alert">'+ error_msg +'</div>'); 
          }
        });
        
        
        jQuery('body').on('click', 'button.social-media-config-btn', function() {
          var mids = new Array();
          mids = jQuery('table.media-table tbody tr input[type=checkbox]:checked').map(function() {
            return jQuery(this).data('mid')
          }).get();
          console.log(mids);
          //get status of post from test
          var current_status_test = jQuery(this).text();
           if (current_status_test == 'SCHEDULE'){
              var current_status = 'Scheduled';
           }
           else if (current_status_test == 'SAVE AS DRAFT') {
              var current_status = 'Draft';
           }
          jQuery.ajax({
              url: "/save-schedule-settings",
              data:{
                "uid":path_userid,
                "mid":mids,
                "media_kit_id":jQuery('#media-kit-options select').find(":selected").val(),
                "social_media_name":jQuery('.socialmedia-title span').text(),
                "text":jQuery('#nav-newpost textarea').val(),
                "status":current_status,
                "action":'save',
              },
              type: "POST",
              success:function(xhr, status) {
                if(status == 'success'){
                  window.location.reload();
                }
              }
            });
        });
          jQuery('#available-connections .border-secondary').on('click', '.available-net', function() {
            jQuery.ajax({
              url: "/save-schedule-settings",
              data:{
                "uid":path_userid,
              },
              type: "POST",
              success:function(xhr, status) {
                if(status == 'success'){
                  console.log('working');
                }
              }
               });
              var current_class = jQuery(this).parents('.border-secondary').attr("class").split(/\s+/);
                  var i;
                  var find_class;
                  for (i = 0; i < current_class.length; ++i) {
                      if(current_class[i].indexOf("custom") >= 0){
                       find_class = '.'+current_class[i];
                      }
                  }
                  jQuery(this).parents('.border-secondary').hide();   
                  jQuery("#active-connections .connections-list").find(find_class).show();
                
           
        });
         
         jQuery('#active-connections .border-secondary').on('click', '.active-net', function() {
          jQuery.ajax({
              url: "/save-schedule-settings",
              data:{
                "uid":path_userid,
              },
              type: "POST",
              success:function(xhr, status) {
                if(status == 'success'){
                  console.log('worked');
                }
              }
           });
          var current_class = jQuery(this).parents('.border-secondary').attr("class").split(/\s+/);
           var i;
           var find_class;
            for (i = 0; i < current_class.length; ++i) {
                if(current_class[i].indexOf("custom") >= 0){
                 console.log(current_class[i]);
                find_class = '.'+current_class[i];
                 console.log(find_class);
                }
            }
            jQuery(this).parents('.border-secondary').hide();
           jQuery("#available-connections .connections-list").find(find_class).show();
         
        });
        //Add selected media under specific post
        jQuery('body').on('click', '#add-selected', function() {
          //get selected media kit tab name
          var selected_tab = jQuery('#nav-newpost .tab-pane.active').attr('id');
          selected_tab = selected_tab.split("-");
          var tabname = selected_tab[1];
          
          //get selected data from media kit
          var selected_data = jQuery('#'+tabname+'-kit-content-section input[type="checkbox"]:checked').map(function() {
            return jQuery(this).data('mid')
          }).get();
          console.log(selected_data);
        });

      }
    }
  //edit post  
    
  };

  

})(jQuery, Drupal);

//Day selector rules for Auto Scheduler. 
function change_auto_scheduler(val){
  jQuery("#weekdays .xdsoft_time").removeClass('xdsoft_current');
  jQuery("#weekdays .xdsoft_time").removeClass('setweekly');
  
  //Auto select all 7 days and disable the day selector from changes. 
  if(val == 'daily'){
    jQuery("#weekdays .xdsoft_time").addClass('xdsoft_current');
  }
  //Auto select Mon - Fri and disable the day selector from changes. 
  else if(val == 'weekday'){
    jQuery("#weekdays .xdsoft_time:nth-child(-n+5)").addClass('xdsoft_current');
  }
  //Require 1 or more days be selected.
  else if(val == 'weekly'){
    jQuery("#weekdays .xdsoft_time").addClass('setweekly');
  }
  //For all other options, disable the day selector from changes.
}
