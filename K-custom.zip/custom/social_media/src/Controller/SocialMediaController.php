<?php
 
/**
* @file
* Contains \Drupal\social_media\Controller\SocialMediaController.php
*
*/
 
namespace Drupal\social_media\Controller;
use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\Response;
use Drupal\media_entity\Entity\Media;

class SocialMediaController extends ControllerBase {
  
  public function get_media_tags(){
    $term = \Drupal::request()->get('search');
    
    //fetch default media kit of a user
    $tags = \Drupal::database()->select('taxonomy_term_field_data', 't')
    ->fields('t', ['tid', 'name'])
    ->condition('t.vid', 'keywords', '=')
    ->condition('t.name', "$term%", 'like')
    ->execute();
    
    $response = [];
    while($row = $tags->fetchObject()){
      $response[] = ['value' => $row->tid, 'text' => $row->name];
    }
    echo json_encode($response);
    exit;
  }
  

	public function facebook_page(){
    $config = \Drupal::config('social_media.api_settings')->get();
    
    $fb = new \Facebook\Facebook([
      'app_id' => $config['facebook_app_id'],
      'app_secret' => $config['facebook_app_secret'],
      'default_graph_version' => 'v5.0',
      ]);

    try {
      $response = $fb->get('/me?fields=id,name', 'EAAG4zG46PRwBAB1ZBWxVfXBfx7y236pwUTnDVZC6t0aNzf8OiMWZCdYjgWAZA6Q6NudSTIZA0eiV6gGVyYOzNZACR887PVALvYKsT0BAOLQeiM3tJZAAkc4pSG50rp3mHW8csOmHyJX6jV139hTar7jvtZCH9FKgGAZAStXBT0whv4Ude616A7trWWM5mQuxBmZACnU5oQqBOHCnQFwVsgj4aM3XZCcRIsrE8zHNtibOi4lMgZDZD');
    } catch(\Facebook\Exceptions\FacebookResponseException $e) {
      echo 'Graph returned an error: ' . $e->getMessage();
      exit;
    } catch(\Facebook\Exceptions\FacebookSDKException $e) {
      echo 'Facebook SDK returned an error: ' . $e->getMessage();
      exit;
    }

    $user = $response->getGraphUser();

    echo 'Name: ' . $user['name']; die;
	}
  
  public function main_page($user){
    global $base_url;
    $vid = 'social_media_networks';
    $terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree($vid);
    $social_network = [];
    foreach($terms as $term) {
    $term_id = $term->tid;
    $terms_obj =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($term_id);
      if(isset($terms_obj->field_icon) && isset($terms_obj->field_icon->target_id) ){
       $network_status = $terms_obj->field_status->value;
       $network_icon_target = $terms_obj->field_icon->target_id;
       $file = \Drupal::entityTypeManager()->getStorage('file')->load($network_icon_target );
       $social_icon_path = $file->url();    
       $social_network[] = ['name' => $terms_obj->name->value, 'tid' => $terms_obj->tid->value, 'network_icon' =>$social_icon_path, 'network_status'=> $network_status];
      }
    }
    $data['network_srttings'] = $social_network;
     \Drupal::logger('some_channel_name')->warning('<pre><code>' . print_r($data, TRUE) . '</code></pre>');
    $uid = $user->get('uid')->value;
    $data['uid'] = $uid;
    $account = \Drupal\user\Entity\User::load($uid); // pass your uid
    $name = $account->getUsername();
    $calendarData['UserName'] = $name;
    $update_post = [];
    //post edit
    if (isset($_GET['post_id'])) {
        $post_id = $_GET['post_id'];
        $query = \Drupal::database()->select('social_media', 'sm');
        $query->innerJoin('social_media_posts', 'smp', 'sm.id = smp.sid');
        $result = $query->fields('sm', array('id','social_media_name','text', 'data', 'media_kit_id'))
                ->fields('smp', array('mid'))
                ->condition('sm.uid', $uid, '=')
                ->condition('sm.id', $post_id, '=')
                ->execute()->fetchAll();
        foreach($result as $row_object)
        {  
           $update_post['mid'] = $row_object->mid ;        
           $update_post['post_name'] = $row_object->text;
           $update_post['media_kit_id'] = $row_object->media_kit_id;
           $sm_data = json_decode($row_object->data);
           $schedule_type = $sm_data->schedule_type;
           $update_post['manual_datetime']= $sm_data->manual_datetime;
           $update_post['auto_select'] = $sm_data->auto_select;
           $update_post['auto_day'] = $sm_data->auto_day;
           $update_post['auto_day'] = $sm_data->auto_time; 
        }
       
      
     } 
    
    
    
    //calendar data
        $events = array();     
        $query = \Drupal::database()->select('social_media', 'sm');
        $result = $query->fields('sm', array('id','social_media_name','data','text'))
                  ->condition('sm.uid', $uid, '=')
                  ->execute()->fetchAll();
         
        if(!empty($result)){
          foreach($result as $row_object){
            //$edit = \Drupal\Core\Url::fromUserInput('/social_media/form/social_media?id='.$row_object->id);
           /* $edit = \Drupal\Core\Url::fromUserInput('/social_media/form/social_media');
            $link_options = [
              'attributes' => [
                'class' => [
                  'fa fa-edit',
                ],
                'id' => $row_object->id,
              ],
            ];
            $edit->setOptions($link_options);
            $edit_link = \Drupal::l('', $edit);*/
            
            //$args = ['post_id' => $row_object->id];
           
            $postId = $row_object->id;
            $socialMediaName = $row_object->social_media_name;
             $link_options = [
              'attributes' => [
                'class' => [
                  'fa fa-edit',
                ],
              ],
              'query' => [
                   'post_id' => $row_object->id,
               ],
               'fragment' =>'nav-newpost',
            ];
            if (strcasecmp($socialMediaName, 'Facebook') == 0) {
              $s_id = 'fb';
            }
            else if (strcasecmp($socialMediaName, 'Linkedin') == 0) {
              $s_id = 'link';
            }
            else if (strcasecmp($socialMediaName, 'Instagram') == 0) {
              $s_id = 'insta';
            }
            /*else if (strcasecmp($socialMediaName, 'Facebook') == 0) {
              $s_id = 'fb';
            }*/
            $url = \Drupal\Core\Url::fromUserInput('/kit/item/social-media/'.$uid.'/'.$s_id);
            $url->setOptions($link_options);
            $edit_link = \Drupal::l('', $url);
                              
            $postName = $row_object->text;
            $scheduled_data = json_decode($row_object->data);
            $schedule_type = $scheduled_data->schedule_type;
            if($schedule_type == 'manual_check'){
             $daysOfWeek = '';
             $daysOfWeekArray ='';
             $start_key = 'start'; 
             $manual_datetime = $scheduled_data->manual_datetime;
             $published_date = date('Y-m-d H:i:s', $manual_datetime);
             $Onlytime = explode(" ",$published_date);
             $formatedTime = date("g:i a", strtotime($Onlytime[1]));
             $unformatedTime = date('Y-m-d H:00', $manual_datetime);
            }  
            else{
              $start_key = 'startTime';
              $daysOfWeek = [];
              $daysOfWeekArray = 'daysOfWeek';
              $auto_select = $scheduled_data->auto_select;
              $published_date  = $scheduled_data->auto_time;
              $remove_minute = str_replace(":",":00",$published_date);
              $unformatedTime = substr($remove_minute, 0, -2);
              $formatedTime = date("g:i a", strtotime($published_date));              
              if($auto_select == 'daily'){
                 $daysOfWeek = ['0','1','2','3','4','5','6'];
              }
              else if ($auto_select == 'weekly') {
                 $auto_day = $scheduled_data->auto_day;
                 switch ($auto_day) {
                    case 'Mon':
                        $daysOfWeek[] = '1';
                        break;
                    case 'Tue':
                        $daysOfWeek[] = '2';
                        break;
                    case 'Wed':
                        $daysOfWeek[] = '3';
                        break;
                    case 'Thu':
                        $daysOfWeek[] = '4';
                        break;    
                    case 'Fri':
                        $daysOfWeek[] = '5';
                        break; 
                 } 
               } 
               else if ($auto_select == 'weekday') {
                 $daysOfWeek = ['1','2','3','4','5']; 
               }
            }
            $events[] = array('title'=>$postName, $start_key =>$unformatedTime,'socialMediaName'=>$socialMediaName, $daysOfWeekArray=>$daysOfWeek,'formatedTime'=>$formatedTime, 'edit' => $edit_link,'className'=>'custom-event');
          }
         
        }  
         $calendarData['events'] = $events;

    //fetch default media kit of a user
    $default_media_kit = \Drupal::database()->select('node_field_data', 'n')
    ->fields('n', ['nid'])
    ->condition('n.uid', $uid, '=')
    ->condition('n.type', 'media_kit', '=')
    ->range(0, 1)
    ->execute()
    ->fetchAssoc();   
    
    $render_data['theme_data'] = array(
        '#theme' => 'social_media',
        '#data' => $data,
        '#attached' => [
          'library' =>  [
            'social_media/fullCalender', 
            'social_media/social_media.main',
            'media_vault_tool/react.min',
            'media_vault_tool/react.dom.min',
            'media_vault_tool/axios',
            'social_media/datetimepicker',
          ],
          'drupalSettings' =>  [
            'media_base_url' => $base_url,
            'path_userid' => $uid,
            'default_media_kit_id' => $default_media_kit['nid'],
            'calendarData' => $calendarData,
            'update_post' => $update_post
          ],
        ],
      );

    return $render_data;
  }
  
  /**
  * To save schedule settings modal.
  */
	public function save_schedule_settings(){
		//get your POST parameter
    $action = \Drupal::request()->get('action');
    $media_kit_id = \Drupal::request()->get('media_kit_id');
    $social_media_name = \Drupal::request()->get('social_media_name');
      \Drupal::logger('some_channel_name')->warning('<pre><code>' . print_r($social_media_name, TRUE) . '</code></pre>');
    $text = \Drupal::request()->get('text');
    $uid = \Drupal::request()->get('uid');    
    $status = \Drupal::request()->get('status'); 
    if($action == 'schedule'){
      $schedule_type = \Drupal::request()->get('schedule_type');
      $manual_datetime = \Drupal::request()->get('manual_datetime');
      $auto_select = \Drupal::request()->get('auto_select');
      $auto_day = \Drupal::request()->get('auto_day');
      $auto_time = \Drupal::request()->get('auto_time');
      if($auto_day){
        $auto_day = implode(',', $auto_day);
      }
      
      //convert manual_datetime to timestamp
      if($manual_datetime){
        $manual_datetime = strtotime($manual_datetime);
      }
      
      // schedule data
      $schedule_data = []; 
      $schedule_data['schedule_type'] = $schedule_type;
      $schedule_data['manual_datetime'] = $manual_datetime;
      $schedule_data['auto_select'] = $auto_select;
      $schedule_data['auto_day'] = $auto_day;
      $schedule_data['auto_time'] = $auto_time;
      
      $result = \Drupal::database()->merge('social_media')
        ->key([
          'uid' => $uid,
          'media_kit_id' => $media_kit_id,
          'social_media_name' => $social_media_name, 

        ])
        ->fields([
          'status' => $status,
          'text' => $text,
          'data' => json_encode($schedule_data), 
          'created' => time(),
        ])
        ->execute();
    }else{
      $mids = $_POST['mid'];
      $sm = \Drupal::database()->select('social_media', 'sm')
      ->fields('sm', ['id', 'data'])
      ->condition('sm.uid', $uid, '=')
      ->condition('sm.media_kit_id', $media_kit_id, '=')
      ->condition('sm.social_media_name', $social_media_name, '=')
      ->execute()
      ->fetchObject();
      
      if(!empty($sm)){
        $sm_data = json_decode($sm->data);
        $schedule_type = $sm_data->schedule_type;
        $manual_datetime = $sm_data->manual_datetime;
        $auto_select = $sm_data->auto_select;
        $auto_day = $sm_data->auto_day;
        $auto_time = $sm_data->auto_time;          
      
        \Drupal::database()->update('social_media')
          ->fields([
            'text' => $text,
            'status' => $status,
          ])
          ->condition('uid', $uid, '=')
          ->condition('media_kit_id', $media_kit_id, '=')
          ->condition('social_media_name', $social_media_name, '=')
          ->execute();

        foreach($mids as $mid){        
          $res = \Drupal::database()->insert('social_media_posts')
            ->fields(['sid', 'mid', 'schedule_type', 'manual_datetime', 'auto_select', 'auto_day', 'auto_time',])
            ->values([
              'sid' => $sm->id,
              'mid' => $mid,
              'schedule_type' => $schedule_type,
              'manual_datetime' => $manual_datetime,
              'auto_select' => $auto_select,
              'auto_day' => $auto_day,
              'auto_time' => $auto_time,
            ])
            ->execute();
        }        
      } 

    }
    $result = 'done';
		return new Response($result);
	}
  public function save_social_network_settings(){
     $result = 'success';
		return new Response($result);
  }
  
}