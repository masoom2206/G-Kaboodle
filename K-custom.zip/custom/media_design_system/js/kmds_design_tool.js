  var media_base_url = drupalSettings.media_base_url;
  var uid = drupalSettings.uid;
  var name = drupalSettings.name;
  var email = drupalSettings.email;
  var avatar = drupalSettings.avatar;
  var product_group_url = media_base_url+"/kmds/product-group?_format=json";
  /* var userApi = jQuey.ajax({
    type: 'POST',
    url: 'http://35.160.82.144/api/v1/get_api_access',
    data: [{
        'user_id': uid,
        'name': name,
        'email': email,
    }],
   }); */

  var H_items = [
    { 'Name': 'File', 'MenuItem': [
      { 'Icon': '&nbsp;', 'Name': 'New Design', 'Shortcut': 'Alt+N', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, { 'Icon': '&nbsp;', 'Name': 'New Design from Template...', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, { 'Icon': '&nbsp;', 'Name': 'New from Clipboard', 'Shortcut': 'Shift+Ctrl+Alt+N', 'Disabled': 'g-disabled', 'Divider': 'item-divider', 'Tail': '&nbsp;' }, { 'Icon': '&nbsp;', 'Name': 'Open Local File...', 'Shortcut': 'Ctrl+O', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, { 'Icon': '&nbsp;', 'Name': 'Open from Cloud...', 'Shortcut': 'Shift+Ctrl+O', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, { 'Icon': '', 'Name': 'Open Recent',  'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': 'item-divider', 'Tail': 'has-tail', 'MenuTailItem': [
					{'Icon': 'fa fa-cloud-upload', 'Name': 'Test', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;'}
				]}, 
			{ 'Icon': 'fa fa-save', 'Name': 'Save', 'Shortcut': 'Ctrl+S', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, { 'Icon': '&nbsp;', 'Name': 'Download File', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, { 'Icon': '&nbsp;', 'Name': 'Save to Cloud as', 'Shortcut': 'Shift+Ctrl+S', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, { 'Icon': 'fa fa-history', 'Name': 'Show Version History', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': 'item-divider', 'Tail': '&nbsp;' }, { 'Icon': '&nbsp;', 'Name': 'Import', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': 'has-tail', 'MenuTailItem': [
					{'Icon': '&nbsp;', 'Name': 'Place Image...', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Link Image...', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': 'item-divider', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Add Fonts...', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;'}
				]},			
			{ 'Icon': 'fa fa-sign-out', 'Name': 'Export', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': 'has-tail', 'MenuTailItem': [
					{'Icon': '&nbsp;', 'Name': 'Advanced Export...', 'Shortcut': 'Shift+Ctrl+E', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'PNG Image(.png)', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'JPEG Image(.jpg)', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;'}, {'Icon': '&nbsp;', 'Name': 'Scalable Vector Graphics(.svg)', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;'}, {'Icon': '&nbsp;', 'Name': 'PDF Document(.pdf)', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': 'has-tail', 'MenuTailItem': [
						{'Icon': '&nbsp;', 'Name': '72 dpi', 'Shortcut': '&nbsp;', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': '96 dpi', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': '150 dpi', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;'}, {'Icon': '&nbsp;', 'Name': '300 dpi', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': 'item-divider', 'Tail': '&nbsp;'}, {'Icon': '&nbsp;', 'Name': 'Advanced Options...', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;'},
					]},
				]},
			{ 'Icon': 'fa fa-print', 'Name': 'Print', 'Shortcut': 'Ctrl+P', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }
		]}, 
    { 'Name': 'Edit', 'MenuItem': [
      { 'Icon': 'fas fa-reply', 'Name': 'Undo', 'Shortcut': 'Ctrl+Z', 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, { 'Icon': 'fas fa-share', 'Name': 'Redo', 'Shortcut': 'Shift+Ctrl+Z', 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, { 'Icon': 'fa fa-cut', 'Name': 'Cut', 'Shortcut': 'Ctrl+X', 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, { 'Icon': 'fa fa-copy', 'Name': 'Copy', 'Shortcut': 'Ctrl+C', 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, { 'Icon': '&nbsp;', 'Name': 'Paste', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': 'has-tail', 'MenuTailItem': [
					{'Icon': 'fa fa-paste', 'Name': 'Paste', 'Shortcut': 'Ctrl+V', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Paste In Place', 'Shortcut': 'Shift+Ctrl+V', 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Paste Inside Selection', 'Shortcut': 'Alt+Shift+Ctrl+V', 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;'}, {'Icon': '&nbsp;', 'Name': 'Paste Style', 'Shortcut': 'F4', 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;'}
				]},			
			{ 'Icon': '&nbsp;', 'Name': 'Delete', 'Shortcut': 'Del', 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, { 'Icon': '&nbsp;', 'Name': 'Duplicate', 'Shortcut': 'Ctrl+D', 'Disabled': 'g-disabled', 'Divider': 'item-divider', 'Tail': '&nbsp;' }, { 'Icon': '&nbsp;', 'Name': 'Edit Selection', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, { 'Icon': '&nbsp;', 'Name': 'Select All', 'Shortcut': 'Ctrl+A', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, { 'Icon': '&nbsp;', 'Name': 'Deselect All', 'Shortcut': 'Shift+Ctrl+A', 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, { 'Icon': '&nbsp;', 'Name': 'Invert Selection', 'Shortcut': 'Shift+Ctrl+I', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, { 'Icon': '&nbsp;', 'Name': 'Select by Font Type', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, { 'Icon': 'fas fa-cog', 'Name': 'Settings...', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }
		]}, 
    { 'Name': 'Modify', 'MenuItem': [
      { 'Icon': '&nbsp;', 'Name': 'Arrange', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': 'has-tail', 'MenuTailItem': [
					{'Icon': '&nbsp;', 'Name': 'Bring to Front', 'Shortcut': 'Shift+Ctrl+Up', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': 'km-bring-forward fs-20', 'Name': 'Bring forward', 'Shortcut': 'Ctrl+Up', 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': 'km-bring-backword fs-20', 'Name': 'Send Backward', 'Shortcut': 'Ctrl+Down', 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;'}, {'Icon': '&nbsp;', 'Name': 'Send to Back', 'Shortcut': 'Shift+Ctrl+Down', 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;'}
				]},
			{ 'Icon': '&nbsp;', 'Name': 'Align', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': 'has-tail', 'MenuTailItem': [
					{'Icon': '&nbsp;', 'Name': 'Align Left', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Align Center', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Align Right', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': 'item-divider', 'Tail': '&nbsp;'}, {'Icon': '&nbsp;', 'Name': 'Align Top', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;'}, {'Icon': '&nbsp;', 'Name': 'Align Middle', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Align Bottom', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': 'item-divider', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Same Width', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;'}, {'Icon': '&nbsp;', 'Name': 'Same Height', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': 'item-divider', 'Tail': '&nbsp;'}, {'Icon': '&nbsp;', 'Name': 'Distribute Horizontally', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Distribute Vertically', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': 'item-divider', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Snap to Full Units', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;'}, {'Icon': '&nbsp;', 'Name': 'Snap to Half Units', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;'}
				]},
			{ 'Icon': '&nbsp;', 'Name': 'Transform', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': 'item-divider', 'Tail': 'has-tail', 'MenuTailItem': [
					{'Icon': '&nbsp;', 'Name': 'Rotate 45° Left', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Rotate 90° Left', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Rotate 180° Left', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': 'item-divider', 'Tail': '&nbsp;'}, {'Icon': '&nbsp;', 'Name': 'Rotate 45° Right', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;'}, {'Icon': '&nbsp;', 'Name': 'Rotate 90° Right', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Rotate 180° Right', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': 'item-divider', 'Tail': '&nbsp;' }, {'Icon': 'km-flip fs-26 fa-rotate-270 fa', 'Name': 'Flip Vertical', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;'}, {'Icon': 'km-flip fs-26 fa-flip-horizontal', 'Name': 'Flip Horizontal', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;'}
				]},
			{ 'Icon': 'fas fa-object-group', 'Name': 'Group Selection', 'Shortcut': 'Ctrl+G', 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, { 'Icon': 'km-compound fs-20', 'Name': 'Create Compound', 'Shortcut': 'Ctrl+M', 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, { 'Icon': 'fa fa-adjust', 'Name': 'Clip Selection', 'Shortcut': '&nbsp;', 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, { 'Icon': 'fas fa-object-group', 'Name': 'Ungroup Selection', 'Shortcut': 'Shift+Ctrl+G', 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, { 'Icon': '&nbsp;', 'Name': 'Mask with Shape', 'Shortcut': 'Ctrl+Shift+M', 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, { 'Icon': 'fa fa-crop', 'Name': 'Confirm Cropping', 'Shortcut': '&nbsp;', 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, { 'Icon': '&nbsp;', 'Name': 'Cancel Cropping', 'Shortcut': '&nbsp;', 'Disabled': 'g-disabled', 'Divider': 'item-divider', 'Tail': '&nbsp;' }, { 'Icon': '&nbsp;', 'Name': 'Create Coumpound Shape', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': 'has-tail', 'MenuTailItem': [
					{'Icon': 'km-union fs-24', 'Name': 'Union', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': 'km-subtract fs-20', 'Name': 'Subtract', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': 'km-intersect fs-24', 'Name': 'Intersect', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;'}, {'Icon': 'km-difference fs-20', 'Name': 'Difference', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;'}
				]},
			{ 'Icon': '&nbsp;', 'Name': 'Create Nested Compound', 'Shortcut': 'Ctrl+Alt+M', 'Disabled': 'g-disabled', 'Divider': 'item-divider', 'Tail': '&nbsp;' }, 
			
			{ 'Icon': '&nbsp;', 'Name': 'Path', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': 'has-tail', 'MenuTailItem': [
					{'Icon': '&nbsp;', 'Name': 'Join Paths', 'Shortcut': 'Ctrl+J', 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Split Path', 'Shortcut': 'Shift+Ctrl+J', 'Disabled': 'g-disabled', 'Divider': 'item-divider', 'Tail': '&nbsp;' }, {'Icon': 'km-path fs-24', 'Name': 'Convert to Path', 'Shortcut': 'Ctrl+Shift+P', 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;'}, {'Icon': '&nbsp;', 'Name': 'Convert to raw Path', 'Shortcut': 'Ctrl+Shift+R', 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;'}, {'Icon': '&nbsp;', 'Name': 'Convert to Outline', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Expand/Shink', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': 'fas fa-braille', 'Name': 'Vectorize Border', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;'}, {'Icon': '&nbsp;', 'Name': 'Vectorize Image', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;'}, {'Icon': '&nbsp;', 'Name': 'Attach Text to Path', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Detach Text from Path', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;'}, {'Icon': '&nbsp;', 'Name': 'Simplify Path', 'Shortcut': 'Ctrl+ALt+S', 'Disabled': 'g-disabled', 'Divider': 'item-divider', 'Tail': '&nbsp;'}, {'Icon': '&nbsp;', 'Name': 'Connect Paths Lines', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Break Curve', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;'}, {'Icon': '&nbsp;', 'Name': 'Reverse Order', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': 'item-divider', 'Tail': '&nbsp;'}
				]},
			{ 'Icon': 'km-symbol fs-20', 'Name': 'Symbol', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': 'has-tail', 'MenuTailItem': [
					{'Icon': 'km-symbol fs-24', 'Name': 'Create Symbol', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Detach Symbol Instance', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Reset Instance', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': 'item-divider', 'Tail': '&nbsp;'}
				]},
			{ 'Icon': '&nbsp;', 'Name': 'Flatten', 'Shortcut': 'Ctrl+X', 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }
		]}, 
    { 'Name': 'View', 'MenuItem': [
			{'Icon': '&nbsp;', 'Name': 'Original-View', 'Shortcut': 'Ctrl+0', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Fit Selection', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Fit Layer', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Fit All', 'Shortcut': 'Alt+Ctrl+0', 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Magnification', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': 'item-divider', 'Tail': 'has-tail', 'MenuTailItem': [
					{'Icon': '&nbsp;', 'Name': '6%', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': '12%', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': '25%', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': '50%', 'Shortcut': 'Ctrl+5', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': '66%', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': '100%', 'Shortcut': 'Ctrl+1', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': '150%', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': '200%', 'Shortcut': 'Ctrl+2', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': '300%', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': '400%', 'Shortcut': 'Ctrl+4', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': '800%', 'Shortcut': 'Ctrl+8', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': '1600%', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': '3200%', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': '6400%', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': '12800', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': '25600%', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': 'item-divider', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Zoom In', 'Shortcut': 'Ctrl++', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Zoom Out', 'Shortcut': 'Ctrl+-', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }
				]},
			{'Icon': '&nbsp;', 'Name': 'Outline View', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' },  {'Icon': '&nbsp;', 'Name': 'Fast View', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': 'item-divider', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Canvas', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': 'item-divider', 'Tail': 'has-tail', 'MenuTailItem': [
					{'Icon': '&nbsp;', 'Name': 'Show Rulers', 'Shortcut': 'Ctrl+Alt+R', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': 'fa fa-check', 'Name': 'Show Guidelines', 'Shortcut': 'Ctrl+,', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': 'fa fa-check', 'Name': 'Show Symbol Labels', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Show Grid', 'Shortcut': 'Ctrl+Alt+G', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': 'fa fa-check', 'Name': 'Show Slices', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': 'fa fa-check', 'Name': 'Show Effects', 'Shortcut': 'Ctrl+E', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }
				]},
			{'Icon': '&nbsp;', 'Name': 'Snap to', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': 'item-divider', 'Tail': 'has-tail', 'MenuTailItem': [
					{'Icon': '&nbsp;', 'Name': 'Use Snapping', 'Shortcut': 'Shift+F10', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Use Snap Zones', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': 'fa fa-check', 'Name': 'Snap to Grid', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': 'fa fa-check', 'Name': 'Snap to Guide Lines', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': 'fa fa-check', 'Name': 'Snap to Full Pixels', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': 'fa fa-check', 'Name': 'Snap to Anchor Points', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': 'fa fa-check', 'Name': 'Snap to Shapes', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': 'fa fa-check', 'Name': 'Snap to Pages', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }
				]},
			{'Icon': 'fa fa-check', 'Name': 'Show Inspector Panel', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': 'fa fa-check', 'Name': 'Show Layers Panel', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Show Libraries Panel', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Show Symbol Panels', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': 'item-divider', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'New View', 'Shortcut': 'Ctrl+Alt+N', 'Disabled': '&nbsp;', 'Divider': 'item-divider', 'Tail': '&nbsp;' }, {'Icon': 'far fa-play-circle', 'Name': 'Play/Present', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Toggle Fullscreen', 'Shortcut': 'Alt+Enter', 'Disabled': '&nbsp;', 'Divider': '&nbsp;', 'Tail': '&nbsp;' }
		]},
    { 'Name': 'Help', 'MenuItem': []}
  ];
	
	var toolbar_file = [
		{ 'Icon': 'fa fa-save', 'Name': 'Save', 'Action': 'file.save', 'Disabled': '&nbsp;' }, { 'Icon': 'fas fa-reply', 'Name': 'Undo', 'Action': 'edit.undo', 'Disabled': 'disabled' }, { 'Icon': 'fas fa-share', 'Name': 'Redo', 'Action': 'edit.redo', 'Disabled': 'disabled' }
	];
	var toolbar_view = [
		{ 'iclass': 'zoom-button', 'Icon': 'fa fa-search-plus', 'Name': 'Zoom' }, { 'iclass': '&nbsp;', 'Icon': 'fas fa-expand', 'Name': 'Fit All' }, { 'iclass': 'dropdown', 'Icon': 'fa fa-magnet fa-rotate-180', 'Name': 'Snap', 'MenuDropdownItem': [
			{'Icon': '&nbsp;', 'Name': 'Use Snapping', 'Shortcut': 'Shift+F10', 'Disabled': '&nbsp;', 'Divider': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Use Snap Zones', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;' }, {'Icon': 'fa fa-check', 'Name': 'Snap to Grid', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;' }, {'Icon': 'fa fa-check', 'Name': 'Snap to Guide Lines', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;' }, {'Icon': 'fa fa-check', 'Name': 'Snap to Full Pixels', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;' }, {'Icon': 'fa fa-check', 'Name': 'Snap to Anchor Points', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;' }, {'Icon': 'fa fa-check', 'Name': 'Snap to Shapes', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': '&nbsp;' }, {'Icon': 'fa fa-check', 'Name': 'Snap to Pages', 'Shortcut': null, 'Disabled': 'g-disabled', 'Divider': 'item-divider' }, {'Icon': '&nbsp;', 'Name': 'Show Grid', 'Shortcut': 'Ctrl+Alt+G', 'Disabled': '&nbsp;', 'Divider': '&nbsp;' }, {'Icon': 'fa fa-check', 'Name': 'Show Guidelines', 'Shortcut': 'Ctrl+,', 'Disabled': '&nbsp;', 'Divider': '&nbsp;' }, {'Icon': 'fa fa-check', 'Name': 'Show Symbol Labels', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;' }
		]}
	];
	var toolbar_tool = [
		{ 'iclass': 'dropdown', 'Icon': 'fas fa-mouse-pointer', 'Name': 'Select', 'MenuDropdownItem': [
			{'Icon': 'fas fa-mouse-pointer', 'Name': 'Pointer', 'Shortcut': 'V', 'Disabled': '&nbsp;', 'Divider': '&nbsp;' }, {'Icon': 'far fa-paper-plane fa-flip-horizontal', 'Name': 'Subselect', 'Shortcut': 'D', 'Disabled': '&nbsp;', 'Divider': 'item-divider' }, {'Icon': 'fa fa-check', 'Name': 'Laso', 'Shortcut': 'O', 'Disabled': '&nbsp;', 'Divider': '&nbsp;' }, {'Icon': 'fa fa-check', 'Name': 'Layer', 'Shortcut': 'M', 'Disabled': '&nbsp;', 'Divider': 'item-divider' }, {'Icon': 'fa fa-check', 'Name': 'Slice', 'Shortcut': 'S', 'Disabled': '&nbsp;', 'Divider': '&nbsp;' }
		]}, { 'iclass': 'dropdown', 'Icon': 'far fa-square', 'Name': 'Shape', 'MenuDropdownItem': [
			{'Icon': 'km-line fs-15', 'Name': 'Line', 'Shortcut': 'L', 'Disabled': '&nbsp;', 'Divider': '&nbsp;' }, {'Icon': 'far fa-square', 'Name': 'Rectangle', 'Shortcut': 'R', 'Disabled': '&nbsp;', 'Divider': '&nbsp;' }, {'Icon': 'far fa-circle', 'Name': 'Ellipse', 'Shortcut': 'E', 'Disabled': '&nbsp;', 'Divider': 'item-divider' }, {'Icon': '&nbsp;', 'Name': 'Polygon', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;' }, {'Icon': 'fa km-triangle fs-26', 'Name': 'Triangle', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;' }, {'Icon': 'km-star fs-26', 'Name': 'Star', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;' }
		]}, { 'iclass': 'dropdown', 'Icon': 'far fa-paper-plane fa-rotate-180', 'Name': 'Path', 'MenuDropdownItem': [
			{'Icon': 'fa km-nib fa-rotate-90', 'Name': 'Pen', 'Shortcut': 'P', 'Disabled': '&nbsp;', 'Divider': '&nbsp;' }, {'Icon': 'fa fa-rotate-90 km-pen fs-20', 'Name': 'Freehand', 'Shortcut': 'R', 'Disabled': '&nbsp;', 'Divider': '&nbsp;' }
		]}, { 'iclass': 'dropdown', 'Icon': 'fas fa-scalpel-path', 'Name': 'Knife', 'MenuDropdownItem': [
			{'Icon': 'fa', 'Name': 'Knife', 'Shortcut': 'K', 'Disabled': '&nbsp;', 'Divider': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Freehand Shapping', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;' }
		]},  
		{ 'iclass': '&nbsp;', 'Icon': 'km-text fs-22', 'Name': 'Text' }, { 'iclass': 'dropdown', 'Icon': 'fa fa-image', 'Name': 'Image', 'MenuDropdownItem': [
			{'Icon': '&nbsp;', 'Name': 'Place Image...', 'Shortcut': null, 'Disabled': '&nbsp;', 'Divider': '&nbsp;' }, {'Icon': '&nbsp;', 'Name': 'Link Image...', 'Shortcut': null, 'Disabled': 'disabled', 'Divider': '&nbsp;' }
		]},  
	];
	var toolbar_transform = [
		{ 'Icon': 'km-flip fs-26 fa-flip-horizontal', 'Name': 'Flip Horizontal', 'Action': 'transform.flip-horizontal', 'Disabled': 'disabled' }, { 'Icon': 'km-flip fs-26  fa-rotate-270 fa', 'Name': 'Flip Vertical', 'Action': 'transform.flip-vertical', 'Disabled': 'disabled' }, { 'Icon': 'fas fa-undo', 'Name': 'Rotate 90° Left', 'Action': 'transform.rotate-90-left', 'Disabled': 'disabled' }, { 'Icon': 'fas fa-redo', 'Name': 'Rotate 90° Right', 'Action': 'transform.rotate-90-left', 'Disabled': 'disabled' }
	];
	var toolbar_group = [
		{ 'Icon': 'fas fa-object-group', 'Name': 'Group', 'Action': 'modify.group', 'Disabled': 'disabled' }, { 'Icon': 'fas fa-object-group', 'Name': 'Ungroup', 'Action': 'modify.ungroup', 'Disabled': 'disabled' }, { 'Icon': 'km-compound fs-20', 'Name': 'Create Compound Shape', 'Action': 'modify.merge.union', 'Disabled': 'disabled' }, { 'Icon': 'fa fa-adjust', 'Name': 'Clip', 'Action': 'modify.clip', 'Disabled': 'disabled' }
	];
	var toolbar_arrange = [
		{ 'Icon': 'km-bring-forward fs-20', 'Name': 'Bring Forward', 'Action': 'arrange.order.bring-forward', 'Disabled': 'disabled' }, { 'Icon': 'km-bring-backword fs-20', 'Name': 'Send Backward', 'Action': 'arrange.order.send-backward', 'Disabled': 'disabled' }
	];
	var toolbar_action = [
		{ 'Icon': 'km-symbol fs-20', 'Name': 'Create Symbol', 'Action': 'modify.createsymbol', 'Disabled': '&nbsp;' }, { 'Icon': 'km-path fs-24', 'Name': 'Convert to Path', 'Action': 'modify.converttopath', 'Disabled': 'disabled' }, { 'Icon': 'fas fa-braille', 'Name': 'Vectorize Border', 'Action': 'modify.vectorize', 'Disabled': '&nbsp;' }, 
	];
	var alignments = [
		{ 'Name': 'Distribute Horizontally', 'Action': 'arrange.distribute.horizontal', 'Icon': 'fas fa-align-justify fa-rotate-270', 'Divider': '&nbsp;' }, { 'Name': 'Distribute Vertically', 'Action': 'arrange.distribute.vertical', 'Icon': 'fas fa-align-justify', 'Divider': 'divider' }, { 'Name': 'Align Left', 'Action': 'arrange.align.align-left', 'Icon': 'fas fa-align-left' , 'Divider': '&nbsp;' }, { 'Name': 'Align Center', 'Action': 'arrange.align.align-center', 'Icon': 'fas fa-align-center', 'Divider': '&nbsp;' }, { 'Name': 'Align Right', 'Action': 'arrange.align.align-right', 'Icon': 'fas fa-align-right', 'Divider': 'divider' }, { 'Name': 'Align Top', 'Action': 'arrange.align.align-top', 'Icon': 'fas fa-align-right fa-rotate-270' , 'Divider': '&nbsp;' }, { 'Name': 'Align Middle', 'Action': 'arrange.align.align-middle', 'Icon': 'fas fa-align-center fa-rotate-270', 'Divider': '&nbsp;' }, { 'Name': 'Align Bottom', 'Action': 'arrange.align.align-bottom', 'Icon': 'fas fa-align-right fa-rotate-90', 'Divider': '&nbsp;' }
	];
	var Rightproperty = [
		{ 'Name': 'Postion', 'Input_1': 'x', 'Dimension_1': 'x', 'Max_1': '100', 'InputId_1': 'pos-x', 'Input_2': 'y', 'Max_2': '100', 'Dimension_2': 'y', 'InputId_2': 'pos-y', 'Ratio': '&nbsp;' }, { 'Name': 'Size', 'Input_1': 'w', 'Max_1': '4000', 'InputId_1': 'size-width', 'Dimension_1': 'Width', 'Input_2': 'h', 'Max_2': '4000', 'InputId_2': 'size-height', 'Dimension_2': 'Height', 'Ratio': 'fas fa-percent' }, { 'Name': 'Angle', 'Input_1': 'R',  'Max_1': '360',  'InputId_1': 'angle','Dimension_1': 'Ratio', 'Input_2': 'Transform', 'Dimension_2': 'Transform', 'InputId_2': 'transform', 'Ratio': '&nbsp;' }, 
	];
	var Rightproperty_2 = [
		{ 'Name': 'Move', 'Input_1': 'X', 'Value_1': '0', 'Max_1': '100', 'Property_1': 'move-x', 'InputId_1': 'pos-x0', 'Input_2': 'Y', 'Value_2': '0', 'Max_2': '100', 'Property_2': 'move-y', 'InputId_2': 'pos-y0' }, { 'Name': 'Scale', 'Input_1': 'W', 'Value_1': '100%', 'Max_1': '4000', 'InputId_1': 'w-100', 'Property_1': 'scale-x', 'Input_2': 'H', 'Max_2': '4000', 'Value_2': '100%', 'InputId_2': 'h-100', 'Property_2': 'scale-y' }, { 'Name': 'Rotate', 'Input_1': '↑', 'Value_1': '0', 'Max_1': '360', 'InputId_1': 'rotate', 'Property_1': 'rotate', 'Input_2': '↓', 'Value_2': '0', 'Max_2': '360', 'Property_2': 'reflect', 'InputId_2': 'reflect' }, { 'Name': 'Skew', 'Input_1': 'X', 'Value_1': '0°', 'Max_1': '360', 'InputId_1': 'skew-x','Property_1': 'skew-x', 'Input_2': 'Y', 'Value_2': '0°', 'Property_2': 'skew-y', 'InputId_2': 'skew-y' }, { 'Name': 'Copies', 'Input_1': '&nbsp;', 'Value_1': '0', 'Max_1': '100', 'InputId_1': 'copies', 'Property_1': 'no. of copies' } 
	];
  
  setTimeout(function() {
    $('body').removeClass('loading');
    $('body #kmds_top_part').removeClass('d-none');
  }, 3000);
  setTimeout(function() {
    var de = new De();
    $('body').append(de);
  }, 3200);
  setTimeout(function() {
    $('.modal-header').hide();
    $('.modal-footer').css('padding', '35px');
    $('#modal').modal('show');
  }, 3500);

  $('body').append($('<div />', {'class': 'k-dialog-container'}));
  var modalc = new modalContent();
  var modalb = new modalBox(modalc);
  $('.k-dialog-container').append(modalb);
  
  function keyUpbtn(){
    if(($('#elem-width').val() === '') || ($('#elem-height').val() === '')){
      $('.btn-primary').attr('disabled', 'disabled');
    } else {
      $('.btn-primary').removeAttr('disabled');
    }
  }
  function keyDownbtn(){
    if(($('#elem-width').val() === '') || ($('#elem-height').val() === '')){
      $('.btn-primary').attr('disabled', 'disabled');
    } else {
      $('.btn-primary').removeAttr('disabled');
    }
  }
  
  function tooltipfn(){
    $('[data-toggle="tooltip"]').tooltip({placement : 'bottom'});
  }
	
	function getAction(id, action){
		this.id = id;
		this.action = action;
	}
  	
	getAction.prototype.menuAction = function(){
		return $('#'+this.id).attr('data-action', this.action);
	}
	
	/**
	 * return Product active Icons
	 */
  function getActiveicon(e){
    var id = e.id;
    var tid = $('#'+id).data('tid');
    $('.product-item').each(function(event) {
      $(this).removeClass('active');
      var inactive_ids = $(this).attr('id');
      $('#'+inactive_ids).each(function() {
        var inactive_tid = $(this).data('tid');
        var inactive_id = $(this).attr('id');
        var getinactiveTerm = media_base_url+'/termdata/'+ inactive_tid +'?_format=json';
        $.getJSON( getinactiveTerm, function( inactiveicon ) {
          $('#'+inactive_id+ ' .product-icon').attr('src', inactiveicon[0].icon);
        });
      });
    });
    
    $('#'+id).addClass('active');
    if($('#'+id).hasClass('active')) {
      var getactiveTerm = media_base_url+'/termdata/'+ tid +'?_format=json';
      $.getJSON( getactiveTerm, function( getactiveicon ) {
        $('#'+id).find('.product-icon').attr('src', getactiveicon[0].activeicon);
      });
      //set modal footer for new tab onclick product item
      var product_group = $('#'+id).data('group');
      if(product_group == 223) {
        var max = '22';
        var title = 'Value must be less then or equal to 22.';
        var measurement = 'inches';
      } else {
        var max = '4000';
        var title = 'Value must be less then or equal to 4000.';
        var measurement = 'pixels';
      }
      var elems = InputElems(max, measurement, title);
      var $footerelem = $('.modal-footer').html(
        $('<div/>', {"class": "d-none d-flex align-items-center", "id": "create-design"}).html(elems)
      );
      $('#create-design').removeClass('d-none');
      $('.modal-footer').css('padding', '1rem');
    }
  }
	
	/**
	 * A Global Modal Box
	 */
  function modalBox (modalcontent, title_msg = null) {
    var $elem = $('body div.k-dialog-container');
    $elem.append(
      $('<div/>', {'class': 'modal fade align-items-center', 'id': 'modal'}).append(
        $('<div/>', {'class': 'modal-dialog'}).append(
          $('<div/>', {'class': 'modal-content'}).append(
            $('<div/>', {'class': 'modal-header'}).append(
              $('<h4/>', {'class': 'modal-title', text: title_msg})
            )
          ).append(
            $('<div/>', {'class': 'modal-body'})
          ).append(
          $('<div/>', {'class': 'modal-footer'})
            /* .append(
              $('<button/>', {'class': 'btn btn-default', text: 'Cancel'})
            ).append(
              $('<button/>', {'class': 'btn btn-primary', text: button_text})
            ) */
          )
        )
      )
    );  
  }
	
	/**
	 * return Modal Body elements
	 */
  function modalContent () {      
    $.getJSON( product_group_url, function( data ) { //products
      var products = [];
      var productitems = [];
      var allelemitems = [];
      $.each( data, function( key, val ) { 
        if(val.name == 'Social Media'){
          var $class = 'active';
          var $iclass = 'show active';
          var $area = true;
        } else {
          var $class = $iclass = '';
          var $area = false;
        }
        products.push('<a id="nav-' + val.tid + '-tab" class="nav-item nav-link '+ $class +'" data-toggle="tab" href="#nav-' + val.tid +'" role="tab" aria-controls="nav-' + val.tid +'" aria-selected='+$area+'>' + val.name + '</a>'); 

        // product items
        var product_item_url = media_base_url+'/kmds/product-type/'+val.tid+'?_format=json';
        $.getJSON( product_item_url, function( dataitems ) {          
          var myArray = dataitems;
          var groups = {};
          for (var i = 0; i < myArray.length; i++) {
            var groupName = myArray[i].group;
            if (!groups[groupName]) {
              groups[groupName] = [];
            }
            groups[groupName].push({name: myArray[i].name, tid: myArray[i].tid, icon: myArray[i].icon});
          }
          myArray = [];
          for (groupName in groups) {
            myArray.push({group: groupName, items: groups[groupName]});
          }         
          
          $.each( myArray, function( ikey, ival ) {
            ival.items.sort((a, b) => a.name.localeCompare(b.name));
            var p_item = ival.items.map((nitem, nkey) => {            
              return '<div id="item-' + nitem.tid +'" data-tid='+ nitem.tid +'  data-group='+ ival.group +' class="product-item" onclick="getActiveicon(this)"><img class="product-icon" src="'+ nitem.icon +'" alt='+ nitem.name +' title='+ nitem.name +'/></div>';
            });
            
            allelemitems.push($('<div/>', {
              "class": 'tab-pane fade '+ $iclass +'',
              "id": 'nav-' + ival.group,
              "role": "tabpanel",
              "aria-labelledby": 'nav-' + ival.group + '-tab',
              "html": p_item,
              })
            );
          });
          return $('.tab-content.tab-group').append(allelemitems);        
        });
      });
      var $elem = $('.modal-body').append(
        $('<nav/>', {"class": "custom-nav-layout"}).append(
          $('<div/>', {
            "class": "nav nav-tabs nav-fill",
            "id": "nav-tab",
            "role": "tablist",
            "html": products,
          })
        )
      ).append(
        $('<div/>', {"class": "tab-content tab-group d-flex justify-content-center"})
      ); 
      
      //unset modal footer of old tab on switch tab
      $(".nav > .nav-item").on("shown.bs.tab", function(e) {
        $('.modal-footer').html('');
        $('.modal-footer').css('padding', '35px');
      });

      var $output = $elem;
      return $output;
    });
  }
	
  /**
	 * return Modal form elements
	 */
  function InputElems(max, measurement, title) {
     return $('<ul/>', {'class': 'd-flex'})
      .append(
        $('<li/>').append(
          $('<input/>', {'type': 'number', 'min': 0, 'max': max, 'maxlength': 2, 'class': 'dcreate-elem pl-2', 'name': 'width', 'title': '', 'data-original-title': '', 'data-toggle':'tooltip', 'data-placement': 'bottom', 'id': 'elem-width', 'placeholder': 'width', 'onmouseover': "tooltipfn(this)", 'onkeyup': "keyUpbtn()", 'onkeydown': "keyDownbtn()", 'oninput':"(this.value > "+max+") ? this.title = '" + title + "' : this.value"})
        )
      ).append(
        $('<li/>', {'class': 'elem-separator', 'text': 'x'})
      ).append(
        $('<li/>').append(
          $('<input/>', {'type': 'number', 'min': 0, 'max': max, 'maxlength': 2, 'data-toggle':'tooltip', 'data-placement': 'bottom', 'title': '', 'data-original-title': '', 'class': 'dcreate-elem pl-2', 'name': 'height', 'id': 'elem-height', 'placeholder': 'height', 'onkeyup': "keyUpbtn()", 'onkeydown': "keyDownbtn()", 'onmouseover': "tooltipfn(this)", 'oninput':"(this.value > "+max+") ? this.title = '" + title + "' : this.value" }) 
        )
      ).append(
        $('<li/>').append(
          /* $('<select/>', {'class': 'select-elem pl-2 ml-4', 'name': 'measurement', 'id': 'elem-measurement'}).append($('<option/>', {'value': 'in', 'text': 'in'})).append($('<option/>', {'value': 'px', 'text': 'px'})
          ) */
          $('<input/>', {'class': 'select-elem pl-2 ml-4', 'name': 'measurement', 'id': 'elem-measurement', 'value': measurement, 'disabled': 'disabled'})
        )
      )
      .append(
        $('<li/>', {'class': 'elem-separator'})
      ).append(
        $('<li/>').append(
          $('<button/>', {'id': 'dcreate', 'class': 'btn btn-primary', text: 'CREATE NEW DESIGN', 'disabled': 'disabled'})
        )
      );
  }
  
	/**
	 * return Designer tool container structure
	 */
  function De() {

    De.prototype._info = null, De.prototype._footer = null, De.prototype._header = null, De.prototype._toolbar = null, De.prototype._panels = null, De.prototype._leftSidebars = null, De.prototype._rightSidebars = null, De.prototype._windows = null,  De.prototype._user = null;

    De.prototype.getHeader = function() {
        return this._header
    }, De.prototype.getInfo = function() {
        return this._info
    }, De.prototype.getToolbar = function() {
        return this._toolbar
    }, De.prototype.getPanels = function() {
        return this._panels
    }, De.prototype.getLeftSidebars = function() {
        return this._leftSidebars
    }, De.prototype.getRightSidebars = function() {
        return this._rightSidebars
    }, De.prototype.getWindows = function() {
        return this._windows
    };
    
    this._mainframe = $("<div></div>").attr("id", "mainframe").insertAfter('#kmds_top_part');
    var i = this._frame = $("<div></div>").appendTo(this._mainframe),
        o = $("<div></div>").attr("id", "window").appendTo(i);
    this._windows = 'window';
    var l = $("<div></div>").attr("id", "info").appendTo(i);
    this._info = "info";
    var d = $("<div></div>").attr("id", "header").appendTo(i);
    this._header = new getMenuBar();
    var p = $("<div></div>").attr("id", "toolbar").appendTo(i);
    this._toolbar = new ToolBar();
    var g = $("<div></div>").attr("id", "panels").appendTo(i),
        h = $("<div></div>").attr("id", "footer").appendTo(i);
    this._footer = "footer"; 
    this._panels = "panels";
    var m = $("<div></div>").attr("id", "left-sidebar").appendTo(i);
    this._leftSidebars = new LeftSidebars();
    var f = $("<div></div>").attr("id", "right-sidebar").appendTo(i);
    this._rightSidebars = new RightSidebars();
  }
  
	/**
	 * return Header Menu
	 */
  function getMenuBar (){
    
    $("<div></div>").addClass("section menu").append($("<nav></nav>").addClass("g-menu-bar").append($("<ul></ul>").addClass("g-menu g-menu-root"))).appendTo('#header')
		
		$("<div></div>").addClass("section windows").append($("<div></div>").addClass("tabs").append($("<div></div>").addClass("tab g-active").append($("<span></span>").addClass("title").append('untitled')).append($("<span></span>").addClass("close").append('✕')))).appendTo('#header')
		
		$("<div></div>").addClass("section login user").append(
			$('<img class="avatar" src="'+ avatar +'" alt='+ name +' title='+ name +'/>')	
		).appendTo('#header')		
    
    $.each(H_items, function (index, dataMenu) {
      var menuBuilder = [];
      menuBuilder.push('<li class="g-menu-item"><span class="g-menu-item-caption">' + dataMenu.Name + '</span>');

      if (dataMenu.MenuItem.length > 0) {
        menuBuilder.push('<ul class="g-menu g-menu-bottom">');
        $.each(dataMenu.MenuItem, function (i, dataSubmenu) {
					if(dataSubmenu.Shortcut == null){
						var shortcutf = '';
					}else {
						var shortcutf = dataSubmenu.Shortcut;
					}
					var arr = [];
					var Itemname = '';
          arr = dataSubmenu.Name.split(' ')
          for (var i = 0; i<=arr.length; i++) {
           var Itemname = arr.join("_").toLowerCase().replace('...','')
          }
          menuBuilder.push('<li class="g-menu-item '+ dataSubmenu.Tail +' '+ dataSubmenu.Disabled +' '+ dataSubmenu.Divider +'"><span class="g-menu-item-icon"><i class="'+ dataSubmenu.Icon +'"></i></span><span id="' + Itemname + '" class="g-menu-item-caption">' + dataSubmenu.Name + '</span><span class="g-menu-item-shortcut">'+ shortcutf +'</span></><span class="g-menu-item-tail '+ dataSubmenu.Tail +'"></span>');
					if(dataSubmenu.Tail == 'has-tail'){
						menuBuilder.push('<ul class="g-menu g-menu-right">');
						$.each(dataSubmenu.MenuTailItem, function (ii, dataTailmenu) {
							if(dataTailmenu.Shortcut == null){
								var shortcutt = '';
							}else {
								var shortcutt = dataTailmenu.Shortcut;
							}
							var arrm = [];
							var Itemnamem = '';
							arr = dataTailmenu.Name.split(' ')
							for (var i = 0; i<=arrm.length; i++) {
							 var Itemnamem = arrm.join("_").toLowerCase().replace('...','')
							}
							menuBuilder.push('<li class="g-menu-item '+ dataSubmenu.Tail +' '+ dataTailmenu.Disabled +' '+ dataTailmenu.Divider +'"><span class="g-menu-item-icon"><i class="'+ dataTailmenu.Icon +'"></i></span><span id="' + Itemnamem + '" class="g-menu-item-caption">' + dataTailmenu.Name + '</span><span class="g-menu-item-shortcut">'+ shortcutt +'</span></><span class="g-menu-item-tail '+ dataTailmenu.Tail +'"></span>');
							if(dataTailmenu.Tail == 'has-tail'){
								menuBuilder.push('<ul class="g-menu g-menu-right">');
								$.each(dataTailmenu.MenuTailItem, function (iii, dataTailmenuLast) {
									if(dataTailmenuLast.Shortcut == null){
										var shortcutl = '';
									}else {
										var shortcutl = dataTailmenuLast.Shortcut;
									}
									var arrl = [];
									var Itemnamel = '';
									arr = dataTailmenuLast.Name.split(' ')
									for (var i = 0; i<=arrl.length; i++) {
									 var Itemnamel = arrl.join("_").toLowerCase().replace('...','')
									}
									menuBuilder.push('<li class="g-menu-item '+ dataTailmenuLast.Tail +' '+ dataTailmenuLast.Disabled +' '+ dataTailmenuLast.Divider +'"><span class="g-menu-item-icon"><i class="'+ dataTailmenuLast.Icon +'"></i></span><span id="' + Itemnamel + '" class="g-menu-item-caption">' + dataTailmenuLast.Name + '</span><span class="g-menu-item-shortcut">'+ shortcutl +'</span></><span class="g-menu-item-tail '+ dataTailmenuLast.Tail +'"></span>');
									
									menuBuilder.push('</li>');
								})
								menuBuilder.push('</ul>');
							}							
							menuBuilder.push('</li>');
						})
						menuBuilder.push('</ul>');
					}
					menuBuilder.push('</li>');
        });
        menuBuilder.push('</ul>');
      }

      menuBuilder.push('</li>');

      $('.g-menu-root').append(menuBuilder.join(''));
    });
		
    $('.g-menu-item-tail.has-tail').each(function (event){
			$(this).append('<i class="fa fa-caret-right"></i>');
		}); 
		
		$('.g-menu:not(.g-menu-root) > .g-menu-item > .g-menu-item-caption').each(function(event){
			var nf = new getAction('new_design', 'f.new')
			nf.menuAction()
			$(this).on('click', function(){ 
				this._actions = $(this).data('action')
				switch (this._actions) {
					case 'f.new':
						$('#modal').modal('show')
						break;
					case 'f.new.ft':
						$('#modal').modal('show')
						break;
					case 'f.new.cli':
						
						break;
					case 'f.open.l':

						break;
				}
			})
		});
  }
		
	/**
	 * return Header Menu
	 */
	function ToolBar (){		
		var toolBarBuilder = [];	
		
		// Toolbar File
		toolBarBuilder.push('<div class="section t-section file-section">')
		$.each(toolbar_file, function (i, toolBarmenu_file) {
			toolBarBuilder.push('<div class="toolbar-button" data-action="' + toolBarmenu_file.Action + '"><button class="action-button" data-toggle="tooltip" data-placement="bottom" data-title="' + toolBarmenu_file.Name + '" ' + toolBarmenu_file.Disabled + '><i class="' + toolBarmenu_file.Icon + '"></i></button></div>')
		})
		toolBarBuilder.push('</div>');
		
		// Toolbar View
		toolBarBuilder.push('<div class="section t-section view-section">')
		$.each(toolbar_view, function (ii, toolBarmenu_view) {
			if(toolBarmenu_view.iclass == 'zoom-button'){
				var left_btn = '<button class="left-attached attached-button" style="width: 15px;">-</button>';
				var right_btn = '<button class="right-attached attached-button" style="width: 15px;">+</button>';
				var caption = '<span class="caption">100%</span>';
			} else {
				var left_btn = '';
				var right_btn = '';
				var caption = '';
			}
			if(toolBarmenu_view.iclass == 'dropdown'){
				var dropdown = '<button class="dropdown-button"><i class="fa fa-caret-down"></i></button>';
			}	else {
				var dropdown = '';
			}
			toolBarBuilder.push('<div class="toolbar-button '+ toolBarmenu_view.iclass +'">'+ left_btn +'<button class="action-button" data-toggle="tooltip" data-placement="bottom" data-title="' + toolBarmenu_view.Name + '"><i class="' + toolBarmenu_view.Icon + '"></i>'+ caption +'</button>'+ right_btn +''+ dropdown)
			if(toolBarmenu_view.iclass == 'dropdown'){
				toolBarBuilder.push('<ul class="g-menu g-menu-bottom fixed">');
				$.each(toolBarmenu_view.MenuDropdownItem, function (ix, DropdownItem) {
					if(DropdownItem.Shortcut == null){
						var shortcutl = '';
					}else {
						var shortcutl = DropdownItem.Shortcut;
					}
					var arrl = [];
					var Itemnamel = '';
					arr = DropdownItem.Name.split(' ')
					for (var i = 0; i<=arrl.length; i++) {
					 var Itemnamel = arrl.join("_").toLowerCase().replace('...','')
					}
					toolBarBuilder.push('<li class="g-menu-item '+ DropdownItem.Disabled +' '+ DropdownItem.Divider +'"><span class="g-menu-item-icon"><i class="'+ DropdownItem.Icon +'"></i></span><span id="' + Itemnamel + '" class="g-menu-item-caption">' + DropdownItem.Name + '</span><span class="g-menu-item-shortcut">'+ shortcutl +'</span>');
					
					toolBarBuilder.push('</li>');
				})
				toolBarBuilder.push('</ul>');			
			}
		toolBarBuilder.push('</div>');
		})
		toolBarBuilder.push('</div>');
		
		// Toolbar Tools
		toolBarBuilder.push('<div class="section t-section tool-section">')
		$.each(toolbar_tool, function (iii, toolBarmenu_tool) {
			if(toolBarmenu_tool.iclass == 'dropdown'){
				var dropdown = '<button class="dropdown-button"><i class="fa fa-caret-down"></i></button>';
			} else {
				var dropdown = '';
			}
			toolBarBuilder.push('<div class="toolbar-button '+ toolBarmenu_tool.iclass +'"><button class="action-button" data-toggle="tooltip" data-placement="bottom"  data-title="' + toolBarmenu_tool.Name + '"><i class="' + toolBarmenu_tool.Icon + '"></i></button>'+ dropdown)
			if(toolBarmenu_tool.iclass == 'dropdown'){
				toolBarBuilder.push('<ul class="g-menu g-menu-bottom fixed">');
				$.each(toolBarmenu_tool.MenuDropdownItem, function (x, DropdownItemtool) {
					if(DropdownItemtool.Shortcut == null){
						var shortcut = '';
					}else {
						var shortcut = DropdownItemtool.Shortcut;
					}
					var arrl = [];
					var Itemnamel = '';
					arr = DropdownItemtool.Name.split(' ')
					for (var i = 0; i<=arrl.length; i++) {
					 var Itemnamel = arrl.join("_").toLowerCase().replace('...','')
					}
					toolBarBuilder.push('<li class="g-menu-item '+ DropdownItemtool.Disabled +' '+ DropdownItemtool.Divider +'"><span class="g-menu-item-icon"><i class="'+ DropdownItemtool.Icon +'"></i></span><span id="' + Itemnamel + '" class="g-menu-item-caption">' + DropdownItemtool.Name + '</span><span class="g-menu-item-shortcut">'+ shortcut +'</span>');
					
					toolBarBuilder.push('</li>');
				})
				toolBarBuilder.push('</ul>');			
			}
		toolBarBuilder.push('</div>');
		})
		toolBarBuilder.push('</div>');
		
		// Toolbar Transform
		toolBarBuilder.push('<div class="section t-section transform-section">')
		$.each(toolbar_transform, function (iv, toolBarmenu_transform) {
			toolBarBuilder.push('<div class="toolbar-button" data-action="' + toolBarmenu_transform.Action + '"><button class="action-button" data-toggle="tooltip" data-placement="bottom" data-title="' + toolBarmenu_transform.Name + '" ' + toolBarmenu_transform.Disabled + '><i class="' + toolBarmenu_transform.Icon + '"></i></button></div>')
		})
		toolBarBuilder.push('</div>');
		
		// Toolbar Group
		toolBarBuilder.push('<div class="section t-section transform-section">')
		$.each(toolbar_group, function (v, toolBarmenu_group) {
			toolBarBuilder.push('<div class="toolbar-button" data-action="' + toolBarmenu_group.Action + '"><button class="action-button" data-toggle="tooltip" data-placement="bottom" data-title="' + toolBarmenu_group.Name + '" ' + toolBarmenu_group.Disabled + '><i class="' + toolBarmenu_group.Icon + '"></i></button></div>')
		})
		toolBarBuilder.push('</div>');
		
		// Toolbar Arrange
		toolBarBuilder.push('<div class="section t-section transform-section">')
		$.each(toolbar_arrange, function (vi, toolBarmenu_arrange) {
			toolBarBuilder.push('<div class="toolbar-button" data-action="' + toolBarmenu_arrange.Action + '"><button class="action-button" data-toggle="tooltip" data-placement="bottom" data-title="' + toolBarmenu_arrange.Name + '" ' + toolBarmenu_arrange.Disabled + '><i class="' + toolBarmenu_arrange.Icon + '"></i></button></div>')
		})
		toolBarBuilder.push('</div>');
		
		// Toolbar Action
		toolBarBuilder.push('<div class="section t-section action-section">')
		$.each(toolbar_action, function (vii, toolBarmenu_action) {
			toolBarBuilder.push('<div class="toolbar-button" data-action="' + toolBarmenu_action.Action + '"><button class="action-button" data-toggle="tooltip" data-placement="bottom" data-title="' + toolBarmenu_action.Name + '" ' + toolBarmenu_action.Disabled + '><i class="' + toolBarmenu_action.Icon + '"></i></button></div>')
		})
		toolBarBuilder.push('</div>');

		$('#toolbar').append(toolBarBuilder.join(''));
		$('[data-toggle="tooltip"]').tooltip({placement : 'bottom'});
		$('.dropdown').each(function(event){
			$(this).on('click', function(){
				$("ul.g-menu.g-menu-bottom.fixed").each(function(event){
					$(this).hide();
				})
				$(this).children('ul.g-menu.g-menu-bottom.fixed').css('display', 'inline-block')
			})
			$(document).on("click", function(event){
        var $trigger = $(".toolbar-button.dropdown");
        if($trigger !== event.target && !$trigger.has(event.target).length){
          $("ul.g-menu.g-menu-bottom.fixed").hide();
        }            
			});
		});		
	}

	/**
	 * return Left Sidebar
	 */
	function LeftSidebars (){	
    var LsidebarBarBuilder = [];
		
		var $selector = LsidebarBarBuilder.push('<div class="sidebar-selector d-flex"><div class="sidebar-option text-uppercase d-flex justify-content-center align-items-center  sidebar-layers active c-pointer">Layers</div><div class="sidebar-option text-uppercase d-flex justify-content-center align-items-center sidebar-library c-pointer">Resources</div><div class="sidebar-option text-uppercase d-flex justify-content-center align-items-center sidebar-symbols c-pointer">Assets</div></div>');
		
		var $layers_pagesContainer = LsidebarBarBuilder.push('<div class="sidebar-container sidebar-layers d-flex align-items-stretch flex-column multiple"><div id="accordionDiv" class="toolbar accordion d-flex justify-content-between align-items-center"><label>Pages</label><button class="g-accordion page" data-toggle="collapse" data-target="#pages-container" aria-expanded="true" aria-controls="pages-container"></button><div class="g-accordion-ghost"></div><label class="g-switch" data-toggle="tooltip" data-placement="bottom "data-title="Toggle Single / Multipage Mode" style="margin-right: 5px;"><input type="checkbox" data-property="multipage-switch"><div></div></label><button id="delete-page" data-toggle="tooltip" data-placement="bottom" data-title="Delete Active Page"><i class="fas fa-trash-alt"></i></button><button id="create-new" data-toggle="tooltip" data-placement="bottom" data-title="Create New Page"><i class="far fa-plus-square"></i></button></div><div id="pages-container" class="collapse show pages-container" aria-labelledby="accordionDiv"><div id="pages" class="g-page-panel pages"><div class="d-flex page-row g-active align-items-center"><span class="d-flex page-title-group align-items-center"><span class="page-icon far fa-file"></span><span class="page-title">Page 1</span></span><span onmouseover="tooltipfn(this)" data-toggle="tooltip" data-placement="bottom" data-title="Toggle Locker" class="page-action c-pointer fas fa-unlock-alt fa fa-flip-horizontal"></span><span onmouseover="tooltipfn(this)" data-title="Toggle Visibility" data-toggle="tooltip" data-placement="bottom" class="page-action c-pointer fas fa-eye"></span></div></div></div><div id="page-layer-divider"><hr><div></div></div>');
		
		var $layers_layersContainer = LsidebarBarBuilder.push('<div class="toolbar d-flex justify-content-between align-items-center layer-toolbar"><label class="flex-grow">Layers</label><button id="delete-layer" data-toggle="tooltip" data-placement="bottom" data-title="Delete Layer or Item"><span class="fas fa-trash-alt"></span></button><button id="create-new-layer" data-toggle="tooltip" data-placement="bottom" data-title="New Layer"><span class="far fa-plus-square"></span></button></div><div class="layers-container"><div id="layers" class="layers g-layer-panel"></div></div><hr></div>');
		
		var $libraryContainer = LsidebarBarBuilder.push('<div class="sidebar-container sidebar-library multiple" style="display:none;">library</div>');
		
		var $symbolsContainer = LsidebarBarBuilder.push('<div class="sidebar-container sidebar-symbols multiple" style="display:none;">symbols</div>');
						
		LsidebarBarBuilder.push($selector)
		
	  $('#left-sidebar').append(LsidebarBarBuilder.join(''));
		//Layers, Resources, assets tab actions
		$('#left-sidebar .sidebar-option').each(function(e){
			$(this).on('click', function(){
				$('#left-sidebar .sidebar-option.active').each(function(e){
					$(this).removeClass('active')
				})
				$(this).addClass('active')
				if($(this).hasClass('sidebar-layers')){
					$('.sidebar-container.sidebar-layers').css('display', 'block')
					$('.sidebar-container.sidebar-library').css('display', 'none')
					$('.sidebar-container.sidebar-symbols').css('display', 'none')
				}if($(this).hasClass('sidebar-library')){
					$('.sidebar-container.sidebar-library').css('display', 'block')
					$('.sidebar-container.sidebar-layers').css('display', 'none')
					$('.sidebar-container.sidebar-symbols').css('display', 'none')
				}if($(this).hasClass('sidebar-symbols')){
					$('.sidebar-container.sidebar-symbols').css('display', 'block')
					$('.sidebar-container.sidebar-library').css('display', 'none')
					$('.sidebar-container.sidebar-layers').css('display', 'none')
				}
			})
		});	
		// Delete Page row
    $('button#delete-page').on('click', function(e){
			$('.page-row').each(function(){				
				if($(this).hasClass('g-active')){
					if($('.page-row').length > 1) {
						$(this).remove()
					}else {
						$('button#delete-page').css('cursor', 'default')
					}
					$('.page-row:last-child').addClass('g-active')
				}
			})
		})
		// Add new Page row
		var counter = 1;			
    $('button#create-new').on('click', function(e){
			 //counter++;
			$('.page-row').each(function(){
				$(this).removeClass('g-active');
			})
			if($('.page-row').length < 2) {
				counter = 2;
			}else {
				counter++;
			}
			var page_html =  $("<div></div>").attr("class", "d-flex page-row align-items-center g-active")
			.append(
				$("<span></span>").attr("class", "d-flex page-title-group align-items-center")
				.append($("<span></span>").attr("class", "page-icon far fa-file"))
				.append($("<span></span>").attr("class", "page-title").text('Page '+ counter +''))
			).append(
			  $('<span/>', {
					"class": "page-action c-pointer fas fa-unlock-alt fa fa-flip-horizontal",
					"data-title": "Toggle Locker",
					"data-placement": "bottom",
					"data-toggle": "tooltip",
					"onmouseover": "tooltipfn(this)",
				})
			).append(
			  $('<span/>', {
					"class": "page-action c-pointer fas fa-eye",
					"data-title": "Toggle Visibility",
					"data-placement": "bottom",
					"data-toggle": "tooltip",
					"onmouseover": "tooltipfn(this)",
				})
			)
			$('#pages').append(page_html);
		})	
		//Page tools action
		$('.page-action.fa-unlock-alt').each(function(){
			$(this).on('click', function(){
				$(this).removeClass('fa-unlock-alt');
				$(this).addClass('fa-lock');
			})
		})
		$('.page-action.fa-lock').each(function(){
			$(this).on('click', function(){
				$(this).removeClass('fa-lock');
				$(this).addClass('fa-unlock-alt');
			})
		})
		$('.page-action.fa-eye').each(function(){
			$(this).on('click', function(){
				$(this).removeClass('fas fa-eye');
				$(this).addClass('far fa-eye-slash');
			})
		})
		$('.page-action.fa-eye-slash').each(function(){
			$(this).on('click', function(){
				$(this).removeClass('far fa-eye-slash');
				$(this).addClass('fas fa-eye');
			})
		})
		
		// Delete Page row
		$('button#delete-layer').on('click', function(e){
			$('.layer-row.g-active').remove()		
			$('.layer-row:first-child').addClass('g-active')
		})
		// Add new Layer row
		var count_layer = 0;			
    $('button#create-new-layer').on('click', function(e){
			//count_layer++;
			$('.layer-row').each(function(){
				$(this).removeClass('g-active');
			})
			if($('.layer-row').length == 0) {
				count_layer = 0;
			}else {
				count_layer++;
			}
			var layer_html =  $("<div></div>").attr("class", "d-flex layer-row align-items-center g-active")
			.append(
				$("<span></span>").attr("class", "d-flex layer-title-group align-items-center")
				.append($("<span></span>").attr("class", "layer-icon fas fa-folder"))
				.append($("<span></span>").attr("class", "layer-title").text('Layer '+ count_layer +''))
			).append(
			  $('<span/>', {
					"class": "layer-action c-pointer fas fa-unlock-alt fa fa-flip-horizontal",
					"data-title": "Toggle Locker",
					"data-placement": "bottom",
					"data-toggle": "tooltip",
					"onmouseover": "tooltipfn(this)",
				})
			).append(
			  $('<span/>', {
					"class": "layer-action c-pointer fas fa-eye",
					"data-title": "Layer Visibility",
					"data-placement": "bottom",
					"data-toggle": "tooltip",
					"onmouseover": "tooltipfn(this)",
				})
			)
			.append(
			  $('<span/>', {
					"class": "layer-action c-pointer far fa-dot-circle",
					"data-title": "Toggle Outline",
					"data-placement": "bottom",
					"data-toggle": "tooltip",
					"onmouseover": "tooltipfn(this)",
				})
			)
			.append(
			  $('<span/>', {
					"class": "layer-action c-pointer layer-color g-pattern-chooser-simplified",
					"data-title": "Toggle Outline",
					"data-placement": "bottom",
					"data-toggle": "tooltip",
					"onmouseover": "tooltipfn(this)",
				}).append(
					$('<span/>', {
						"class": "layer-action c-pointer layer-color g-pattern-chooser-simplified",
					}).append(
						$('<span/>', {
							"class": "preview",
							"draggable": true,
							"style": {'height': '100%', 'background': 'linear-gradient(rgb(0, 168, 255), rgb(0, 168, 255)), url(&quot;data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI4IiBoZWlnaHQ9IjgiPjxyZWN0IHdpZHRoPSI4IiBoZWlnaHQ9IjgiIGZpbGw9IndoaXRlIi8+PHJlY3Qgd2lkdGg9IjQiIGhlaWdodD0iNCIgZmlsbD0iI0NEQ0RDRCIvPjxyZWN0IHg9IjQiIHk9IjQiIHdpZHRoPSI0IiBoZWlnaHQ9IjQiIGZpbGw9IiNDRENEQ0QiLz48L3N2Zz4=&quot;)'},
						})
					)
				)
			)
			$('#layers').prepend(layer_html);
		})
	}
	
	/**
	 * return Right Sidebar
	 */
	function RightSidebars (){	
    var RsidebarBarBuilder = [];

		var $toolbarPanel_1 = [];
		var $toolbarPanel_2 = [];
		var $propertyPanel_1 = [];
		var $propertyPanel_2 = [];
		var $propertyPanel_3 = [];
		
		$toolbarPanel_1.push('<div class="toolbar main-toolbar d-flex justify-content-between align-items-center ">') /* d-none */
		$.each(alignments, function (a, alignment) {
			$toolbarPanel_1.push('<button onmouseover="tooltipfn(this)" class="fs-18" data-action="' + alignment.Action + '" data-toggle="tooltip" data-placement="bottom" data-title="' + alignment.Name + '"><i class="' + alignment.Icon + '"></i></button><span class="' + alignment.Divider + '"></span>')
		})
		$toolbarPanel_1.push('</div>');
		$toolbarPanel_1 = $toolbarPanel_1.join('');
		
		$propertyPanel_1.push('<div class="properties-panel ">')/* d-none */
		$.each(Rightproperty, function (r, Rproperty) {
			if(Rproperty.Ratio != ''){
				var $cont = '<div class="content align-items-center d-flex fs-8" style="height:22px;"><span class=' + Rproperty.Ratio + ' onmouseover="tooltipfn(this)" data-toggle="tooltip" data-placement="bottom" data-title="Keep Ratio" data-ratio="no" style="text-align: center; cursor: pointer;"></span></div>';
				var cClass = 'column';
			} else {
				var $cont = '&nbsp;';
				var cClass = 'column p-0';
			}
			if(Rproperty.Input_2 == 'Transform'){
				var input2 = '<button id='+ Rproperty.InputId_2 +' class="transform-button">'+Rproperty.Input_2+'</button>';
			} else {
				var input2 = '<div><span class="g-input-label">' + Rproperty.Input_2 + '</span><input id='+ Rproperty.InputId_2 +' type="number" min="0" max='+ Rproperty.Max_2 +' data-dimension=' + Rproperty.Dimension_2 + ' style="padding-left: 20px; width: 100%;"></div>';
			}
			$propertyPanel_1.push('<div class="g-property-row"><label><span class="vertical-align">'+ Rproperty.Name +'</span></label><div class="columns d-flex"><div class="column d-flex flex-column align-items-center" style="width: 44%;"><div class="content w-100"><div><span class="g-input-label">' + Rproperty.Input_1 + '</span><input id='+ Rproperty.InputId_1 +' type="number" min="0" max='+ Rproperty.Max_1 +' data-dimension=' + Rproperty.Dimension_1 + ' style="padding-left: 20px; width: 100%;"></div></div></div><div class='+ cClass +' style="width: 12%;">'+ $cont +'</div><div class="column d-flex flex-column align-items-center" style="width: 44%;"><div class="content w-100">'+ input2 +'</div></div></div></div>')
		})		
		$propertyPanel_1.push('</div>');
		$propertyPanel_1 = $propertyPanel_1.join('');
		
		$toolbarPanel_2.push('<div class="toolbar d-flex justify-content-between align-items-center"><label>Transform</label><button data-action="stroke-settings" data-title="Advanced settings"><span class="gravit-icon-settings"></span></button></div>');
		
		$propertyPanel_2.push('<div class="properties-panel ">')/* d-none */
		$.each(Rightproperty_2, function (r, Rproperty_2) {
			if (Rproperty_2.Name == 'Copies') {
				var $hr = '<hr>';
				var input2 = '<div class="column p-0" style="width: 44%;"><div class="d-flex w-100 justify-content-center"><div data-property="pivot" class="g-pivot align-self-center"><div class="borderline"></div><div class="side" data-side="tl"></div><div class="side" data-side="tc"></div><div class="side" data-side="tr"></div><div class="side g-active" data-side="rc"></div><div class="side" data-side="br"></div><div class="side" data-side="bc"></div><div class="side" data-side="bl"></div><div class="side" data-side="lc"></div><div class="side" data-side="cc"></div></div></div></div>';
			} else {
				var $hr = '';
				var input2 = '<div class="column d-flex flex-column align-items-center" style="width: 44%;"><div class="content w-100"><div><span class="g-input-label">' + Rproperty_2.Input_2 + '</span><input id='+ Rproperty_2.InputId_2 +' value='+ Rproperty_2.Value_2 +' type="number" min="0" max='+ Rproperty_2.Max_2 +' data-property=' + Rproperty_2.Property_2 + ' style="padding-left: 20px; width: 100%;"></div></div></div>';
			}
			$propertyPanel_2.push($hr+'<div class="g-property-row"><label><span class="vertical-align">'+ Rproperty_2.Name +'</span></label><div class="columns d-flex"><div class="column d-flex flex-column align-items-center" style="width: 44%;"><div class="content w-100"><div><span class="g-input-label">' + Rproperty_2.Input_1 + '</span><input id='+ Rproperty_2.InputId_1 +' value='+ Rproperty_2.Value_1 +' type="number" min="0" max='+ Rproperty_2.Max_1 +' data-property=' + Rproperty_2.Property_1 + ' style="padding-left: 20px; width: 100%;"></div></div></div><div class="content p-0" style="width: 12%;">&nbsp;</div>'+ input2 +'</div></div>')
		})
		$propertyPanel_2.push('<div class="g-property-row"><label><span class="vertical-align"></span></label><div class="columns d-flex"><div class="content w-100"><button class="transform-button w-100" style="margin-top: 5px;">Apply</button></div></label></div><br>')
		$propertyPanel_2.push('</div>');
		$propertyPanel_2 = $propertyPanel_2.join('');

		var activepage = $('.page-row.g-active .page-title').text();
		$propertyPanel_3.push('<div class="toolbar d-flex justify-content-between align-items-center page-toolbar"><label>Page ('+ activepage +')</label></div>')
		
		var color = '<div class="column" style="width: 25%;"><div class="content"><div data-property="bck" class="g-pattern-chooser"><span class="fas fa-tint fa fa-rotate-180"></span></div></div></div>';

		var w = '<div class="column" style="width: 25%;"><div class="content"><div><span class="g-input-label">W</span><input type="text" data-property="w" style="padding-left: 20px; width: 100%;"></div></div></div>';

		var h = '<div class="column" style="width: 25%;"><div class="content"><div><span class="g-input-label">H</span><input type="text" data-property="h" style="padding-left: 20px; width: 100%;"></div></div></div>';

		var opacity = '<label class="column" style="width: 25%;"><div class="content"><input type="text" data-property="bop"></div></label>';

		$propertyPanel_3.push('<div class="properties-panel"><div data-property-row="canvas-size" class="g-property-row no-label"><div class="columns d-flex m-0">'+ color +' '+ w +' '+ h +' '+ opacity +' </div><div class="labels"><label style="width: 25%;"><span>Color</span></label><label style="width: 25%;"><span>Width</span></label><label style="width: 25%;"><span>Height</span></label><label style="width: 25%;"><span>Opacity</span></label></div></div><hr>')
		
		$propertyPanel_3.push('</div>')
		$propertyPanel_3 = $propertyPanel_3.join('')
		
		
		
		RsidebarBarBuilder.push('<div class="sidebar-container sidebar-inspector d-flex flex-column"><div class="panels flex-grow">'+ $toolbarPanel_1 +' '+ $propertyPanel_1 +' '+ $toolbarPanel_2 +' '+ $propertyPanel_2 +' '+ $propertyPanel_3 +'</div></div>');

	  $('#right-sidebar').append(RsidebarBarBuilder.join(''));
	}
 