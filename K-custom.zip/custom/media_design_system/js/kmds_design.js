(function ($, Drupal, drupalSettings) {
  var initialized;
  Drupal.behaviors.DesignBehavior = {
    attach: function (context, settings) {
      if (!initialized) {
        initialized = true;
        var media_base_url = drupalSettings.media_base_url;
        var use_in_mds = drupalSettings.use_in_mds;
        var uid = drupalSettings.uid;

        var product_group_url = media_base_url+"/kmds/product-group?_format=json";
        
        var AppCleanURL = React.createClass({
          getInitialState: function() {
            return {
              CleanURL: '',
            }
          },
          componentWillMount: function() {
            var th = this;
            document.addEventListener('load', th.cleanParam.bind());
          },
          cleanParam: function(key){
            var th = this;
            var sourceURL = this.props.sourceURL;
            var rtn = sourceURL.split("=")[0],
            param,
            params_arr = [],
            params_arr_tt = [],
            queryString = (sourceURL.indexOf("=") !== -1) ? sourceURL.split("=")[1] : "";
            if (queryString[1] !== "") {
              params_arr = queryString.split(" ");
              for (var i = params_arr.length - 1; i >= 0; i -= 1) {
                 var tt = params_arr.join("-");
              }                
              rtn = rtn + "=" + tt;
            }
            th.setState({CleanURL: rtn});
            return rtn;
          },
          render: function() {
            return React.createElement("a", {className: 'product-a', id: this.props.tid, href: this.state.CleanURL+'&hash=#'+this.props.group+'-content', onLoad: this.cleanParam.bind('type')}, React.createElement("img", {src: this.props.icon, className: 'product-icon', 'alt': this.props.name, 'title': this.props.name}));
          },
        });
        
        var AppProducts = React.createClass({
          getInitialState: function() {
            return {
              p_groups: [],  
              p_types: [],
            }
          },
          componentWillMount: function() {
            var th = this;            
            this.serverRequest = axios.get(product_group_url)
              .then(function(response) {
                return response.data;
              })
              .then(function(data) {
                th.setState({p_groups: data});
                return Promise.all(data.map( (record, index) => {  
                  var tid = record.tid;
                  return axios.get(media_base_url+'/kmds/product-type/'+tid+'?_format=json');
                }))
              })
              .then(function(responsex) {
                th.setState({p_types: responsex});
              });
            document.addEventListener('load', th.navUpdate.bind());    
          },
          componentWillUnmount: function() {
            this.serverRequest.abort();
          },          
          navUpdate: function(e){
            e.preventDefault();
            var k = jQuery(e.target).closest('.tab-pane').attr('data-key');
            if(k == 0){
              var eid = jQuery(e.target).closest('.tab-pane').attr('id');
              var id = (eid).split('-');
              var tabid = id[0];
              if(window.location.hash == 'undefined' || window.location.hash == ''|| window.location.hash == '#222-content') {
                jQuery(e.target).closest('.tab-pane').addClass('show active');
              } else {
                jQuery('#product-groups-tabs a[href="' + window.location.hash + '"]').tab('show');
              }
            }
          },
          render: function() {
            //set state in alphabetically
            this.state.p_groups.sort((a, b) => a.name.localeCompare(b.name));
            var left_panel_items = this.state.p_groups.map((leftitem, lkey) => {
              
              if(lkey == 0) {
                var active_class = 'active';
                var aria_selected = true;
              } else {
                var active_class = '';
                var aria_selected = false;
              }
              
              return React.createElement("a", {className: 'nav-link text-white caps-on f-24 font-fjalla '+active_class+' ', id: leftitem.tid+'-tab', 'data-toggle': 'pill', href:'#'+leftitem.tid+'-content', 'role': 'tab', 'aria-controls': leftitem.tid+'-content', 'aria-selected': aria_selected}, leftitem.name);
            });
            
            var right_panel_items = this.state.p_types.map((rightitem, ikey) => {
              var myArray = rightitem.data;
              var groups = {};
              for (var i = 0; i < myArray.length; i++) {
                var groupName = myArray[i].group;
                if (!groups[groupName]) {
                  groups[groupName] = [];
                }
                groups[groupName].push({name: myArray[i].name, tid: myArray[i].tid, icon: myArray[i].icon});
              }
              myArray = [];
              for (groupName in groups) {
                myArray.push({group: groupName, items: groups[groupName]});
              }
              
              return myArray.map((childitem, index) => { 
                childitem.items.sort((a, b) => a.name.localeCompare(b.name));
                var icon = childitem.items.map((nitem, nkey) => {
                  var productTypeIcon = React.createElement(AppCleanURL, {tid: nitem.tid, name: nitem.name, icon: nitem.icon, group: childitem.group, sourceURL: '/kmds/design/'+nitem.tid+'?type='+nitem.name});
                  return productTypeIcon;
                });
                
                return React.createElement("div", {className: 'tab-pane fade', 'data-key': ikey, id: childitem.group+'-content', 'role': 'tabpanel', 'aria-labelledby': childitem.group+'-tab', onLoad: this.navUpdate.bind(this)}, icon);
              });
            });
            
            var leftPanel = React.createElement("div", {className: 'col-3 left-side'},
            React.createElement("h2", {className: 'lato-light caps-on f-24 text-white'}, 'Select Service:'),            
            React.createElement("div", {className: 'nav flex-column nav-pills', id: "product-groups-tabs", 'role': 'tablist', 'aria-orientation': 'vertical'}, left_panel_items)
            );
            var rightPanel = React.createElement("div", {className: 'col-9'}, React.createElement("div", {className: 'tab-content', id: "product-types-tabContent"}, right_panel_items ));
                          
            return ( React.createElement("div", {className: 'row h-100'}, leftPanel, rightPanel));
          }
        });
        
        React.render(
          React.createElement(AppProducts, 'div',{className:'x2'}), document.querySelector("#products-container"));                  
                                  
      }
    }
  }
})(jQuery, Drupal, drupalSettings);