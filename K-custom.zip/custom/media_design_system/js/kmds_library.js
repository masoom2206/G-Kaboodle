(function ($, Drupal, drupalSettings) {
  var initialized;
  Drupal.behaviors.LibraryBehavior = {
    attach: function (context, settings) {
      if (!initialized) {
        initialized = true;
        var media_base_url = drupalSettings.media_base_url;
        var uid = drupalSettings.uid;
        var selectedtid = drupalSettings.tid;

        // Product Library class  
        var AppProductsLibrary = React.createClass({
          getInitialState: function() {
            return { 
              p_type: [],
              p_library: [],
            }
          },
          componentWillMount: function() {
            var th = this;            
            this.serverRequest = axios.get(media_base_url+'/termdata/'+selectedtid+'?_format=json')
              .then(function(response) {
                return response.data[0];
              })
              .then(function(data) {
                th.setState({p_type: data});
                var tid = data.tid;
                return axios.get(media_base_url+'/kmds/product-library/'+tid+'?_format=json');
              })
              .then(function(responsex) {
                th.setState({p_library: responsex.data});
              });
          },
          componentWillUnmount: function() {
            this.serverRequest.abort();
          },
          render: function() {
            // get hash value           
            var sourceURL = document.location.href;
            var hash = sourceURL.split("&hash=")[1];
            
            var type = this.state.p_type; 
            if(type.activeicon != 'null') {
              var ico = type.activeicon;
            } else {
              var ico = type.icon;
            }
            var leftPanel = React.createElement("div", {className: 'col-3 left-side'}, React.createElement("div", {className: 'active-product-type', id: type.tid}, React.createElement("img", {src: ico, 'alt': type.name, 'title': type.name})),
            React.createElement("div", {className: 'text-white pl-4 mt-70'}, React.createElement("img", {src: '/themes/custom/kaboodlemedia/images/leftarrow.png', className: 'back-arrow'}, ''),
            React.createElement("u", null, React.createElement("a", {href: '/kmds/design'+hash, className: 'text-white caps-on f-20 font-fjalla'}, 'Back To Media Selection'))) 
            );
            
            this.state.p_library.sort((a, b) => a.name.localeCompare(b.name));
            var right_panel_items = this.state.p_library.map((rightitem, ikey) => {
             
              var icon = React.createElement("img", {src: rightitem.icon, className: 'product-lib-icon', 'alt': rightitem.name, 'title': rightitem.name});
              
              var favorite_inactive = 'inactive';
              if(rightitem.favorite == 1){
                favorite_inactive = '';
              }
              
              return React.createElement("div", {className: 'item-group p-3 mr-5 mb-5 d-flex flex-column', 'data-key': ikey}, 
                React.createElement("h5", {className: 'lib-title text-center'}, rightitem.name),
                React.createElement("div", {className: 'd-flex'}, 
                  React.createElement("div", {className: 'item-left pr-3 pt-2'}, icon),
                  React.createElement("div", {className: 'item-right'}, rightitem.description),
                )//,
                //React.createElement('button', {type: 'button', className: 'icon-favo mt-auto '+favorite_inactive}, '')                
              );
            });           
            
            var rightPanel = React.createElement("div", {className: 'col-9 d-flex flex-row flex-wrap'},  right_panel_items);
                          
            return ( React.createElement("div", {className: 'row'}, leftPanel, rightPanel));
          }
        });
        
        React.render(
          React.createElement(AppProductsLibrary, 'div',{className:'x2'}), document.querySelector("#product-library"));
               
      }
    }
  }
})(jQuery, Drupal, drupalSettings);