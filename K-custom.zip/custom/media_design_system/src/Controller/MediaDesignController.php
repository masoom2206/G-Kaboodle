<?php
 
/**
* @file
* Contains \Drupal\media_design_system\Controller\MediaDesignController.php
*
*/
 
namespace Drupal\media_design_system\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\Core\Session\AccountInterface;
use Drupal\user\Entity\User;
use Drupal\taxonomy\TermInterface;

class MediaDesignController extends ControllerBase {
  
  /**
   * Returns a KMDS product list page.
   *
   * @return array
   *   A simple renderable array.
   */
	public function products(int $use_in_mds){
    global $base_url;
    $uid = \Drupal::currentUser()->id();
    $render_data = array();
    $render_data['theme_data'] = array(
      '#theme' => 'product_list_template',         
      '#attached' => [
        'library' =>  [
          'media_design_system/react.min',
          'media_design_system/react.dom.min',
          'media_design_system/axios',
          'media_design_system/kmds_design',
          'media_design_system/global',
        ],
      ],
    );
    $render_data['theme_data']['#attached']['drupalSettings']['media_base_url'] = $base_url;
    $render_data['theme_data']['#attached']['drupalSettings']['use_in_mds'] = $use_in_mds;
    $render_data['theme_data']['#attached']['drupalSettings']['uid'] = $uid;
    return $render_data;
	}
  
  /**
   * Returns a KMDS design tool to create new design.
   *
   * @return array
   *   A simple renderable array.
   */
	public function createDesign(){
    global $base_url;
    $uid = \Drupal::currentUser()->id();
		$user = User::load($uid);
		$name = $user->get('name')->value;
		$email = $user->get('mail')->value;
		if (!$user->user_picture->isEmpty()) {
      $avatar = file_create_url($user->user_picture->entity->getFileUri());
    }else{
      $avatar = 'https://s3.us-west-2.amazonaws.com/kaboodlemedia.com/s3fs_public/styles/thumbnail/public/default_images/default_person_picture.jpg';    
    }
    $render_data = array();
    $render_data['theme_data'] = array(
      '#theme' => 'kmds_design_tool_template',         
      '#attached' => [
        'library' =>  [
          //'media_design_system/react.min',
          //'media_design_system/react.dom.min',
          //'media_design_system/axios',
          'media_design_system/kmds_design_tool',
          'media_design_system/bootstrap_cdn',
        ],
      ],
    );
    $render_data['theme_data']['#attached']['drupalSettings']['media_base_url'] = $base_url;
    $render_data['theme_data']['#attached']['drupalSettings']['uid'] = $uid;
    $render_data['theme_data']['#attached']['drupalSettings']['name'] = $name;
    $render_data['theme_data']['#attached']['drupalSettings']['email'] = $email;
    $render_data['theme_data']['#attached']['drupalSettings']['avatar'] = $avatar;
    
    return $render_data;
	}
  
  /**
   * Returns a KMDS product library page.
   *
   * @return array
   *   A simple renderable array.
   */
	public function productLibrary(TermInterface $taxonomy_term){
    global $base_url;
    $uid = \Drupal::currentUser()->id();
    $term = \Drupal::routeMatch()->getParameter('taxonomy_term');   
    $render_data = array();    
    $render_data['theme_data'] = array(
      '#theme' => 'product_library_template',        
      '#attached' => [
        'library' =>  [
          'media_design_system/react.min',
          'media_design_system/react.dom.min',
          'media_design_system/axios',
          'media_design_system/kmds_library',
          'media_design_system/global',
        ],
      ],
    );
    $render_data['theme_data']['#attached']['drupalSettings']['media_base_url'] = $base_url;
    $render_data['theme_data']['#attached']['drupalSettings']['uid'] = $uid;
    $render_data['theme_data']['#attached']['drupalSettings']['tid'] = $term->get('tid')->value;
    return $render_data;
	}
  
  /**
   * Route title callback.
   *
   * @param \Drupal\taxonomy\TermInterface $taxonomy_term
   *   The taxonomy term.
   *
   * @return array
   *   The term label as a render array.
   */
  public function getTitle(TermInterface $taxonomy_term) {
    return ['#markup' => $taxonomy_term->getName() . ' Library', '#allowed_tags' => \Drupal\Component\Utility\Xss::getHtmlTagList()];
  }
  
  /*
   * Route product group callback.
   * return JSON response of product group vocabulary
  **/
  public function getAllProductgroups () {
    $data = \Drupal::database()->select('taxonomy_term_field_data', 't');
    $data->leftJoin('taxonomy_term__field_use_in_mds', 'mds', "t.tid = mds.entity_id");
    $data->condition('t.vid', 'product_group', '=');
    $data->condition('mds.field_use_in_mds_value', 1, '=');
    $data->fields('t', ['tid','name']);
    $data->fields('mds', ['field_use_in_mds_value']);
    $active_terms = $data->execute()->fetchAll();

    $response = $active_terms;
    
    return new JsonResponse($response);
  }
  
  /*
   * Route product group callback.
   * return JSON response of product group vocabulary
  **/
  public function getTermdata ($tid) {
    $data = \Drupal::database()->select('taxonomy_term_field_data', 't');
    $data->leftJoin('taxonomy_term__field_icon', 'ic', "t.tid = ic.entity_id");
    $data->leftJoin('taxonomy_term__field_active_', 'ac', "t.tid = ac.entity_id");
    $data->condition('t.tid', $tid, '=');
    $data->fields('t', ['tid','name']);
    $data->fields('ic', ['field_icon_target_id']);
    $data->fields('ac', ['field_active__target_id']);
    $result = $data->execute()->fetchAll();
    foreach ($result as $term) {
      $fid = $term->field_icon_target_id;
      $active_icon_fid = $term->field_active__target_id;
      if(!empty($fid)) {
        $file = \Drupal\file\Entity\File::load($fid);
        $image_uri = $file->getFileUri();
        $style = \Drupal\image\Entity\ImageStyle::load('media_library');
        // Get URI.
        $uri = $style->buildUri($image_uri);
        // Get URL.
        $url = $style->buildUrl($image_uri);
      }
      $active_url = 'null';
      if(!empty($active_icon_fid)) {
        $activefile = \Drupal\file\Entity\File::load($active_icon_fid);
        $active_image_uri = $activefile->getFileUri();
        $active_style = \Drupal\image\Entity\ImageStyle::load('media_library');
        // Get URI.
        $active_uri = $active_style->buildUri($active_image_uri);
        // Get URL.
        $active_url = $active_style->buildUrl($active_image_uri);
      }   
      $fresult[] = [
        'tid' => $term->tid,
        'name' => $term->name,
        'icon' => $url,
        'activeicon' => $active_url,
      ];
    }

    $response = $fresult;
    
    return new JsonResponse($response);
  }
  
  /*
   * Route product type callback.
   * @return JSON response
   *   The term fields as a serialized JSON.
   */
  public function getAllProductTypesOfGroup ($parent_term_id) {
    $data = \Drupal::database()->select('taxonomy_term_field_data', 't');
    $data->leftJoin('taxonomy_term__field_icon', 'ic', "t.tid = ic.entity_id");
    $data->leftJoin('taxonomy_term__field_product_group', 'pg', "t.tid = pg.entity_id");
    $data->condition('pg.field_product_group_target_id', $parent_term_id, '=');
    $data->condition('t.vid', 'product_type', '=');
    $data->condition('ic.bundle', 'product_type', '=');
    $data->fields('t', ['tid','name']);
    $data->fields('ic', ['field_icon_target_id']);
    $data->fields('pg', ['field_product_group_target_id']);
    $result = $data->execute()->fetchAll();

    $url = '';
    $fresult = [];
    foreach ($result as $term) {
      $fid = $term->field_icon_target_id;
      if(!empty($fid)) {
        $file = \Drupal\file\Entity\File::load($fid);
        $image_uri = $file->getFileUri();
        $style = \Drupal\image\Entity\ImageStyle::load('media_library');
        // Get URI.
        $uri = $style->buildUri($image_uri);
        // Get URL.
        $url = $style->buildUrl($image_uri);
      }   
      $fresult[] = [
        'tid' => $term->tid,
        'name' => $term->name,
        'group' => $term->field_product_group_target_id,
        'icon' => $url,
      ];
    }
    $response = $fresult;
    
    return new JsonResponse($response); 
  }
  
  /*
   * Route product library callback.
   * @return JSON response
   *   The term fields as a serialized JSON.
   */
  public function getAllProductLibrariesOfType ($product_type) {
    $data = \Drupal::database()->select('taxonomy_term_field_data', 't');
    $data->leftJoin('taxonomy_term__field_icon', 'ic', "t.tid = ic.entity_id");
    $data->leftJoin('taxonomy_term__field_product_type', 'pt', "t.tid = pt.entity_id");
    $data->leftJoin('taxonomy_term__field_favorite', 'ff', "t.tid = ff.entity_id");
    $data->condition('pt.field_product_type_target_id', $product_type, '=');
    $data->condition('t.vid', 'product_library', '=');
    $data->condition('ic.bundle', 'product_library', '=');
    $data->condition('ff.bundle', 'product_library', '=');
    $data->fields('t', ['tid','name','description__value','description__format']);
    $data->fields('ic', ['field_icon_target_id']);
    $data->fields('pt', ['field_product_type_target_id']);
    $data->fields('ff', ['field_favorite_value']);
    $result = $data->execute()->fetchAll();

    $url = '';
    $fresult = [];
    foreach ($result as $term) {
      $fid = $term->field_icon_target_id;
      if(!empty($fid)) {
        $file = \Drupal\file\Entity\File::load($fid);
        $image_uri = $file->getFileUri();
        $style = \Drupal\image\Entity\ImageStyle::load('media_library');
        // Get URI.
        $uri = $style->buildUri($image_uri);
        // Get URL.
        $url = $style->buildUrl($image_uri);
      }
      $plain_desc = preg_match_all("|<[^>]+>(.*)</[^>]+>|U",$term->description__value, $out, PREG_SET_ORDER);
      $description = $out[0][1];
      $fresult[] = [
        'tid' => $term->tid,
        'name' => $term->name,
        'description' => $description,
        'group' => $term->field_product_type_target_id,
        'icon' => $url,
        'favorite' => $term->field_favorite_value,
      ];
    }
    $response = $fresult;
    
    return new JsonResponse($response); 
  }
}